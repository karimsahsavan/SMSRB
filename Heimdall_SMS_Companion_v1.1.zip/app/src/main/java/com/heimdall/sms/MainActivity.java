package com.heimdall.sms;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Insets;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 42;
    private static final int REQ_CONTACT = 43;
    private static final int COLOR_TEXT = 0xFF334E68;
    private static final int COLOR_ERROR = 0xFFB42318;
    private static final int COLOR_OK = 0xFF1B7F4B;

    private EditText numberInput, messageInput;
    private Spinner simSpinner;
    private TextView status, counter;
    private CheckBox deliveryCheck;
    private Button settingsButton;
    private LinearLayout historyBox;
    private final List<Integer> subscriptionIds = new ArrayList<>();
    private boolean pendingSend = false;
    private long lastSentId = -1;
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US);

    // باید فیلد باشد تا SharedPreferences ارجاع ضعیف آن را از بین نبرد
    private final SharedPreferences.OnSharedPreferenceChangeListener historyListener =
        (prefs, key) -> onHistoryChanged();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        renderHistory();
        ensurePermissions();
    }

    @Override protected void onResume() {
        super.onResume();
        SmsHistory.prefs(this).registerOnSharedPreferenceChangeListener(historyListener);
        renderHistory();
        // برگشت از تنظیمات سیستم بعد از دادن مجوز
        if (hasSendPermission() && settingsButton.getVisibility() == View.VISIBLE) {
            settingsButton.setVisibility(View.GONE);
            loadSims();
            setStatus("آماده ارسال پیامک.", false);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        SmsHistory.prefs(this).unregisterOnSharedPreferenceChangeListener(historyListener);
    }

    // ───────────────────────── UI ─────────────────────────

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFFF3F6FA);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        page.setPadding(dp(22), dp(28), dp(22), dp(22));
        page.setBackgroundColor(0xFFF3F6FA);
        scroll.addView(page);

        // اندروید ۱۵+ نوار وضعیت و کیبورد را روی محتوا می‌اندازد؛ فاصله لازم را اضافه می‌کنیم
        if (Build.VERSION.SDK_INT >= 35) {
            scroll.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return WindowInsets.CONSUMED;
            });
        }

        TextView title = new TextView(this);
        title.setText("Heimdall • ارسال پیامک");
        title.setTextSize(24);
        title.setTextColor(0xFF102A43);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(12), 0, dp(8));
        page.addView(title, match());

        TextView subtitle = new TextView(this);
        subtitle.setText("ارسال مستقیم از سیم‌کارت گوشی");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF526477);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, dp(24));
        page.addView(subtitle, match());

        // شماره گیرنده + انتخاب از مخاطبین
        addLabel(page, "شماره گیرنده");
        LinearLayout numberRow = new LinearLayout(this);
        numberRow.setOrientation(LinearLayout.HORIZONTAL);
        numberInput = new EditText(this);
        numberInput.setSingleLine(true);
        numberInput.setHint("مثلاً 09123456789");
        numberInput.setInputType(InputType.TYPE_CLASS_PHONE);
        numberInput.setBackgroundColor(0xFFFFFFFF);
        numberRow.addView(numberInput, new LinearLayout.LayoutParams(0, -2, 1f));
        Button contactBtn = makeButton("مخاطبین", 0xFF1769AA, 0xFFFFFFFF);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
        cp.setMarginStart(dp(8));
        numberRow.addView(contactBtn, cp);
        contactBtn.setOnClickListener(v -> pickContact());
        LinearLayout.LayoutParams nrp = match();
        nrp.bottomMargin = dp(8);
        page.addView(numberRow, nrp);

        addLabel(page, "انتخاب سیم‌کارت");
        simSpinner = new Spinner(this);
        addField(page, simSpinner);

        addLabel(page, "متن پیامک");
        messageInput = new EditText(this);
        messageInput.setHint("متن پیام را بنویسید…");
        messageInput.setMinLines(4);
        messageInput.setGravity(Gravity.TOP | Gravity.START);
        messageInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        addField(page, messageInput);
        messageInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { updateCounter(); }
        });

        counter = new TextView(this);
        counter.setTextSize(12);
        counter.setTextColor(0xFF627D98);
        counter.setPadding(dp(4), 0, dp(4), dp(4));
        page.addView(counter, match());

        deliveryCheck = new CheckBox(this);
        deliveryCheck.setText("درخواست گزارش تحویل (ممکن است اپراتور پشتیبانی نکند)");
        deliveryCheck.setTextSize(13);
        deliveryCheck.setTextColor(0xFF243B53);
        page.addView(deliveryCheck, match());

        Button send = makeButton("ارسال پیامک", 0xFF1769AA, 0xFFFFFFFF);
        send.setTextSize(16);
        LinearLayout.LayoutParams bp = match();
        bp.topMargin = dp(14);
        page.addView(send, bp);
        send.setOnClickListener(v -> sendSms());

        status = new TextView(this);
        status.setText("برای ارسال، مجوزهای لازم را تأیید کنید.");
        status.setTextSize(14);
        status.setTextColor(COLOR_TEXT);
        status.setPadding(dp(4), dp(18), dp(4), dp(8));
        page.addView(status, match());

        settingsButton = makeButton("باز کردن تنظیمات برنامه", 0xFFE4ECF4, 0xFF102A43);
        settingsButton.setVisibility(View.GONE);
        settingsButton.setOnClickListener(v -> openAppSettings());
        page.addView(settingsButton, match());

        // تاریخچه
        LinearLayout historyHeader = new LinearLayout(this);
        historyHeader.setOrientation(LinearLayout.HORIZONTAL);
        historyHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView historyTitle = new TextView(this);
        historyTitle.setText("تاریخچه ارسال");
        historyTitle.setTextSize(16);
        historyTitle.setTextColor(0xFF102A43);
        historyHeader.addView(historyTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        Button clear = makeButton("پاک کردن", 0xFFE4ECF4, 0xFF102A43);
        clear.setOnClickListener(v -> confirmClearHistory());
        historyHeader.addView(clear, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams hp = match();
        hp.topMargin = dp(20);
        hp.bottomMargin = dp(6);
        page.addView(historyHeader, hp);

        historyBox = new LinearLayout(this);
        historyBox.setOrientation(LinearLayout.VERTICAL);
        page.addView(historyBox, match());

        TextView note = new TextView(this);
        note.setText("توجه: ارسال پیامک ممکن است هزینه اپراتور داشته باشد. پیامک‌های ارسالی از این برنامه در برنامه پیامک‌های سیستم دیده نمی‌شوند؛ تاریخچه همین‌جا و فقط روی همین گوشی نگهداری می‌شود.");
        note.setTextSize(12);
        note.setTextColor(0xFF627D98);
        note.setPadding(dp(4), dp(18), dp(4), 0);
        page.addView(note, match());

        setContentView(scroll);
        updateCounter();
    }

    private void addLabel(LinearLayout page, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(14);
        label.setTextColor(0xFF243B53);
        label.setPadding(dp(2), dp(12), dp(2), dp(5));
        page.addView(label, match());
    }

    private void addField(LinearLayout page, View view) {
        view.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams p = match();
        p.bottomMargin = dp(8);
        page.addView(view, p);
    }

    private Button makeButton(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(fg);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(bg);
        shape.setCornerRadius(dp(10));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33000000), shape, null));
        return b;
    }

    private void setStatus(String text, boolean error) {
        status.setTextColor(error ? COLOR_ERROR : COLOR_TEXT);
        status.setText(text);
    }

    private void updateCounter() {
        String body = messageInput.getText().toString();
        if (body.isEmpty()) {
            counter.setText("");
            return;
        }
        try {
            int[] info = SmsMessage.calculateLength(body, false);
            counter.setText(info[1] + " نویسه • " + info[0] + " پیامک • " + info[2] + " نویسه باقی‌مانده در این بخش");
        } catch (Exception e) {
            counter.setText(body.length() + " نویسه");
        }
    }

    // ───────────────────────── مجوزها و سیم‌کارت ─────────────────────────

    private boolean hasSendPermission() {
        return checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensurePermissions() {
        List<String> needed = new ArrayList<>();
        if (!hasSendPermission()) needed.add(Manifest.permission.SEND_SMS);
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.READ_PHONE_STATE);
        if (!needed.isEmpty()) {
            requestPermissions(needed.toArray(new String[0]), REQ_PERMS);
        } else {
            loadSims();
            setStatus(subscriptionIds.size() > 1 ? "دو سیم‌کارت فعال شناسایی شد." : "آماده ارسال پیامک.", false);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_PERMS) return;
        loadSims();
        if (hasSendPermission()) {
            settingsButton.setVisibility(View.GONE);
            setStatus(subscriptionIds.size() > 1 ? "دو سیم‌کارت فعال شناسایی شد." : "آماده ارسال پیامک.", false);
            if (pendingSend) {
                pendingSend = false;
                sendSms();
            }
        } else {
            pendingSend = false;
            setStatus("مجوز ارسال پیامک داده نشد. اگر گزینه مجوز غیرفعال یا خاکستری است (در نصب‌های خارج از فروشگاه رایج است): "
                + "تنظیمات برنامه ← منوی سه‌نقطه بالا ← «Allow restricted settings» (مجاز کردن تنظیمات محدودشده)، "
                + "سپس در بخش مجوزها، SMS را فعال کنید.", true);
            settingsButton.setVisibility(View.VISIBLE);
        }
    }

    private void openAppSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", getPackageName(), null)));
        } catch (Exception e) {
            setStatus("باز کردن تنظیمات ممکن نشد؛ آن را دستی از تنظیمات گوشی باز کنید.", true);
        }
    }

    private void loadSims() {
        subscriptionIds.clear();
        List<String> labels = new ArrayList<>();
        int defaultPos = 0;
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            try {
                SubscriptionManager sm = getSystemService(SubscriptionManager.class);
                List<SubscriptionInfo> active = sm == null ? null : sm.getActiveSubscriptionInfoList();
                int defaultSmsId = Build.VERSION.SDK_INT >= 24
                    ? SubscriptionManager.getDefaultSmsSubscriptionId() : -1;
                if (active != null) {
                    for (SubscriptionInfo info : active) {
                        subscriptionIds.add(info.getSubscriptionId());
                        if (info.getSubscriptionId() == defaultSmsId) defaultPos = subscriptionIds.size() - 1;
                        CharSequence name = info.getDisplayName();
                        if (TextUtils.isEmpty(name)) name = info.getCarrierName();
                        String label = TextUtils.isEmpty(name) ? "اپراتور" : name.toString();
                        labels.add("سیم‌کارت " + (info.getSimSlotIndex() + 1) + " • " + label);
                    }
                }
            } catch (SecurityException e) {
                setStatus("برای شناسایی سیم‌کارت‌ها، مجوز وضعیت تلفن لازم است.", true);
            }
        }
        if (labels.isEmpty()) labels.add("سیم‌کارت پیش‌فرض گوشی");
        simSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        if (defaultPos < labels.size()) simSpinner.setSelection(defaultPos);
    }

    private int selectedSubscriptionId() {
        if (subscriptionIds.isEmpty()) return -1;
        int pos = simSpinner.getSelectedItemPosition();
        if (pos < 0) pos = 0;
        return subscriptionIds.get(Math.min(pos, subscriptionIds.size() - 1));
    }

    private SmsManager obtainManager() {
        int subId = selectedSubscriptionId();
        if (subId >= 0) {
            if (Build.VERSION.SDK_INT >= 31) {
                return getSystemService(SmsManager.class).createForSubscriptionId(subId);
            }
            return SmsManager.getSmsManagerForSubscriptionId(subId);
        }
        return Build.VERSION.SDK_INT >= 31 ? getSystemService(SmsManager.class) : SmsManager.getDefault();
    }

    // ───────────────────────── مخاطبین ─────────────────────────

    private void pickContact() {
        try {
            startActivityForResult(
                new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI), REQ_CONTACT);
        } catch (Exception e) {
            setStatus("برنامه مخاطبین پیدا نشد؛ شماره را دستی وارد کنید.", true);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CONTACT || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        // انتخاب‌گر سیستم مجوز خواندن همان یک مخاطب را موقتاً می‌دهد؛ نیازی به READ_CONTACTS نیست
        try (Cursor c = getContentResolver().query(data.getData(),
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String raw = c.getString(0);
                if (raw != null) numberInput.setText(normalizeNumber(raw));
            }
        } catch (Exception e) {
            setStatus("خواندن شماره مخاطب ممکن نشد.", true);
        }
    }

    // ───────────────────────── ارسال ─────────────────────────

    /** ارقام فارسی/عربی را لاتین می‌کند، فاصله و خط‌تیره را حذف می‌کند و 0098 را به +98 تبدیل می‌کند. */
    static String normalizeNumber(String raw) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c >= '\u06F0' && c <= '\u06F9') sb.append((char) ('0' + (c - '\u06F0')));
            else if (c >= '\u0660' && c <= '\u0669') sb.append((char) ('0' + (c - '\u0660')));
            else if (c >= '0' && c <= '9') sb.append(c);
            else if (c == '+' && sb.length() == 0) sb.append(c);
        }
        String s = sb.toString();
        if (s.startsWith("00") && s.length() > 4) s = "+" + s.substring(2);
        return s;
    }

    private void sendSms() {
        String number = normalizeNumber(numberInput.getText().toString());
        String body = messageInput.getText().toString().trim();
        if (number.replace("+", "").length() < 3) {
            setStatus("شماره گیرنده معتبر نیست.", true);
            return;
        }
        if (body.isEmpty()) {
            setStatus("متن پیامک را وارد کنید.", true);
            return;
        }
        if (!hasSendPermission()) {
            pendingSend = true;
            ensurePermissions();
            return;
        }

        boolean wantDelivery = deliveryCheck.isChecked();
        long id = System.currentTimeMillis();
        boolean recorded = false;
        try {
            SmsManager manager = obtainManager();
            ArrayList<String> parts = manager.divideMessage(body);

            int sentFlags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
            // گزارش تحویل داده‌ی pdu را داخل intent می‌گذارد، پس باید قابل‌تغییر باشد
            int deliveredFlags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);

            ArrayList<PendingIntent> sentIntents = new ArrayList<>();
            ArrayList<PendingIntent> deliveredIntents = wantDelivery ? new ArrayList<>() : null;
            int base = (int) ((id % 1000000L) * 1000L);
            for (int i = 0; i < parts.size(); i++) {
                Intent si = new Intent(this, SmsSentReceiver.class)
                    .setAction(SmsSentReceiver.ACTION_SENT)
                    .putExtra(SmsSentReceiver.EXTRA_ID, id)
                    .putExtra(SmsSentReceiver.EXTRA_PART, i);
                sentIntents.add(PendingIntent.getBroadcast(this, base + i * 2, si, sentFlags));
                if (wantDelivery) {
                    Intent di = new Intent(this, SmsDeliveredReceiver.class)
                        .setAction(SmsDeliveredReceiver.ACTION_DELIVERED)
                        .putExtra(SmsSentReceiver.EXTRA_ID, id)
                        .putExtra(SmsSentReceiver.EXTRA_PART, i);
                    deliveredIntents.add(PendingIntent.getBroadcast(this, base + i * 2 + 1, di, deliveredFlags));
                }
            }

            SmsHistory.Item item = new SmsHistory.Item();
            item.id = id;
            item.number = number;
            item.body = body;
            item.total = parts.size();
            item.wantDelivery = wantDelivery;
            SmsHistory.add(this, item);
            recorded = true;
            lastSentId = id;

            manager.sendMultipartTextMessage(number, null, parts, sentIntents, deliveredIntents);
            messageInput.setText("");
            setStatus("درخواست ارسال ثبت شد؛ نتیجه پس از پاسخ اپراتور نمایش داده می‌شود.", false);
        } catch (Exception e) {
            if (recorded) SmsHistory.remove(this, id);
            setStatus("خطا در ارسال: " + e.getClass().getSimpleName() + " — " + e.getMessage(), true);
        }
    }

    // ───────────────────────── تاریخچه ─────────────────────────

    private void onHistoryChanged() {
        renderHistory();
        if (lastSentId < 0) return;
        SmsHistory.Item it = SmsHistory.find(this, lastSentId);
        if (it == null) return;
        switch (it.status()) {
            case SmsHistory.SENT:
                setStatus("پیامک به شبکه اپراتور تحویل داده شد. این به معنی رسیدن به گیرنده نیست.", false);
                break;
            case SmsHistory.DELIVERED:
                setStatus("رسیدن پیامک به گیرنده تأیید شد.", false);
                break;
            case SmsHistory.DELIVERY_FAILED:
                setStatus("گزارش تحویل: پیامک به گیرنده نرسید.", true);
                break;
            case SmsHistory.FAILED:
                setStatus("ارسال ناموفق: " + SmsSentReceiver.describe(it.lastError), true);
                break;
            default:
                break;
        }
    }

    private String statusLabel(SmsHistory.Item it) {
        switch (it.status()) {
            case SmsHistory.PENDING: return "در حال ارسال…";
            case SmsHistory.SENT: return it.wantDelivery ? "ارسال شد • منتظر گزارش تحویل" : "ارسال شد";
            case SmsHistory.DELIVERED: return "تحویل داده شد";
            case SmsHistory.DELIVERY_FAILED: return "تحویل نشد";
            default: return "ناموفق • " + SmsSentReceiver.describe(it.lastError);
        }
    }

    private int statusColor(SmsHistory.Item it) {
        switch (it.status()) {
            case SmsHistory.FAILED:
            case SmsHistory.DELIVERY_FAILED: return COLOR_ERROR;
            case SmsHistory.SENT:
            case SmsHistory.DELIVERED: return COLOR_OK;
            default: return 0xFF627D98;
        }
    }

    private void renderHistory() {
        if (historyBox == null) return;
        historyBox.removeAllViews();
        List<SmsHistory.Item> items = SmsHistory.all(this);
        if (items.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("هنوز پیامکی ارسال نشده است.");
            empty.setTextSize(13);
            empty.setTextColor(0xFF627D98);
            empty.setPadding(dp(4), dp(4), dp(4), dp(4));
            historyBox.addView(empty, match());
            return;
        }
        for (final SmsHistory.Item it : items) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundColor(0xFFFFFFFF);
            card.setPadding(dp(12), dp(10), dp(12), dp(10));

            TextView head = new TextView(this);
            head.setText(it.number);
            head.setTextSize(15);
            head.setTextColor(0xFF102A43);
            card.addView(head, match());

            TextView text = new TextView(this);
            text.setText(it.body);
            text.setTextSize(13);
            text.setTextColor(0xFF334E68);
            text.setMaxLines(2);
            text.setEllipsize(TextUtils.TruncateAt.END);
            card.addView(text, match());

            TextView meta = new TextView(this);
            meta.setText(timeFormat.format(new Date(it.id)) + " • " + statusLabel(it));
            meta.setTextSize(12);
            meta.setTextColor(statusColor(it));
            meta.setPadding(0, dp(4), 0, 0);
            card.addView(meta, match());

            // با لمس هر مورد، شماره و متن برای ارسال دوباره در فرم قرار می‌گیرد
            card.setOnClickListener(v -> {
                numberInput.setText(it.number);
                messageInput.setText(it.body);
                setStatus("پیام برای ارسال دوباره آماده شد.", false);
            });

            LinearLayout.LayoutParams lp = match();
            lp.bottomMargin = dp(8);
            historyBox.addView(card, lp);
        }
    }

    private void confirmClearHistory() {
        new AlertDialog.Builder(this)
            .setMessage("تاریخچه ارسال پاک شود؟")
            .setPositiveButton("پاک کن", (d, w) -> SmsHistory.clear(this))
            .setNegativeButton("انصراف", null)
            .show();
    }
}
