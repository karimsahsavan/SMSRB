package com.heimdall.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsMessage;

/** گزارش تحویل به گیرنده (اگر اپراتور پشتیبانی کند). */
public class SmsDeliveredReceiver extends BroadcastReceiver {
    public static final String ACTION_DELIVERED = "com.heimdall.sms.SMS_DELIVERED";

    @Override public void onReceive(Context context, Intent intent) {
        long id = intent.getLongExtra(SmsSentReceiver.EXTRA_ID, -1L);
        if (id < 0) return;

        boolean ok = true;
        try {
            byte[] pdu = intent.getByteArrayExtra("pdu");
            String format = intent.getStringExtra("format");
            if (pdu != null) {
                SmsMessage m = SmsMessage.createFromPdu(pdu, format);
                if (m != null) {
                    int st = m.getStatus();
                    if (st >= 32 && st < 64) return; // خطای موقت؛ هنوز نتیجه نهایی نیست
                    ok = st < 32;                    // 0 = تحویل شد، >=64 = شکست دائمی
                }
            }
        } catch (Exception ignored) {
        }
        SmsHistory.recordDelivery(context, id, ok);
    }
}
