package com.heimdall.sms;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** تاریخچه محلی پیامک‌های ارسالی (فقط روی همین گوشی ذخیره می‌شود). */
public final class SmsHistory {
    public static final String PREFS = "sms_history";
    private static final String KEY = "items";
    private static final int MAX_ITEMS = 50;

    public static final int PENDING = 0;
    public static final int SENT = 1;
    public static final int FAILED = 2;
    public static final int DELIVERED = 3;
    public static final int DELIVERY_FAILED = 4;

    public static final class Item {
        public long id;
        public String number = "";
        public String body = "";
        public int total = 1;
        public boolean wantDelivery;
        public int sentOk, sentFail, deliveredOk, deliveredFail, lastError;

        public int status() {
            if (sentFail > 0) return FAILED;
            if (sentOk < total) return PENDING;
            if (wantDelivery) {
                if (deliveredFail > 0) return DELIVERY_FAILED;
                if (deliveredOk >= total) return DELIVERED;
            }
            return SENT;
        }

        JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("n", number);
            o.put("b", body);
            o.put("tot", total);
            o.put("wd", wantDelivery);
            o.put("so", sentOk);
            o.put("sf", sentFail);
            o.put("do", deliveredOk);
            o.put("df", deliveredFail);
            o.put("le", lastError);
            return o;
        }

        static Item fromJson(JSONObject o) {
            Item it = new Item();
            it.id = o.optLong("id");
            it.number = o.optString("n");
            it.body = o.optString("b");
            it.total = o.optInt("tot", 1);
            it.wantDelivery = o.optBoolean("wd");
            it.sentOk = o.optInt("so");
            it.sentFail = o.optInt("sf");
            it.deliveredOk = o.optInt("do");
            it.deliveredFail = o.optInt("df");
            it.lastError = o.optInt("le");
            return it;
        }
    }

    private SmsHistory() {}

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized List<Item> all(Context c) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) out.add(Item.fromJson(arr.getJSONObject(i)));
        } catch (JSONException ignored) {
        }
        return out;
    }

    private static void save(Context c, List<Item> items) {
        JSONArray arr = new JSONArray();
        try {
            for (Item it : items) arr.put(it.toJson());
        } catch (JSONException e) {
            return;
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply();
    }

    public static synchronized void add(Context c, Item item) {
        List<Item> items = all(c);
        items.add(0, item);
        while (items.size() > MAX_ITEMS) items.remove(items.size() - 1);
        save(c, items);
    }

    public static synchronized Item find(Context c, long id) {
        for (Item it : all(c)) if (it.id == id) return it;
        return null;
    }

    public static synchronized void remove(Context c, long id) {
        List<Item> items = all(c);
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).id == id) {
                items.remove(i);
                save(c, items);
                return;
            }
        }
    }

    public static synchronized void clear(Context c) {
        prefs(c).edit().remove(KEY).apply();
    }

    public static synchronized void recordSent(Context c, long id, int resultCode) {
        List<Item> items = all(c);
        for (Item it : items) {
            if (it.id == id) {
                if (resultCode == Activity.RESULT_OK) {
                    it.sentOk++;
                } else {
                    it.sentFail++;
                    it.lastError = resultCode;
                }
                save(c, items);
                return;
            }
        }
    }

    public static synchronized void recordDelivery(Context c, long id, boolean ok) {
        List<Item> items = all(c);
        for (Item it : items) {
            if (it.id == id) {
                if (ok) it.deliveredOk++;
                else it.deliveredFail++;
                save(c, items);
                return;
            }
        }
    }
}
