package com.heimdall.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class SmsSentReceiver extends BroadcastReceiver {
    public static final String ACTION_SENT = "com.heimdall.sms.SMS_SENT";
    public static final String EXTRA_ID = "sms_id";
    public static final String EXTRA_PART = "sms_part";

    @Override public void onReceive(Context context, Intent intent) {
        long id = intent.getLongExtra(EXTRA_ID, -1L);
        int code = getResultCode();
        if (id < 0) return;

        SmsHistory.recordSent(context, id, code);
        SmsHistory.Item item = SmsHistory.find(context, id);
        // برای پیام چندبخشی فقط وقتی همه بخش‌ها جواب دادند یک پیام نشان بده
        if (item == null || item.sentOk + item.sentFail < item.total) return;

        String message = item.sentFail == 0
            ? "پیامک به شبکه اپراتور تحویل داده شد"
            : "ارسال پیامک ناموفق بود: " + describe(item.lastError);
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    /** توضیح فارسی کد خطای ارسال. */
    public static String describe(int code) {
        switch (code) {
            case 1: return "خطای عمومی (اعتبار، خط یا شبکه را بررسی کنید)";
            case 2: return "رادیو خاموش است (حالت پرواز؟)";
            case 3: return "قالب پیام نامعتبر است";
            case 4: return "گوشی آنتن‌دهی/سرویس شبکه ندارد";
            case 5: return "سقف ارسال پیامک سیستم پر شده است؛ کمی بعد دوباره تلاش کنید";
            case 6: return "شماره مجاز نیست (FDN)";
            case 7:
            case 8: return "ارسال به این شماره کوتاه توسط سیستم مسدود شده است";
            case 9: return "رادیو در دسترس نیست";
            case 10: return "شبکه پیام را رد کرد";
            case 17: return "خطای شبکه";
            default: return "کد خطا " + code;
        }
    }
}
