package com.heimdall.sms

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Resources
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import androidx.core.view.WindowCompat
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Telephony
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.*

const val M = -1
const val W = -2

class Theme(val name: String, val bg: String, val surf: String, val line: String, val accent: String,
            val text: String, val sub: String, val on: String, val light: Boolean = false)

object Themes {
    val list = listOf(
        Theme("کهربایی", "#121214", "#1C1C20", "#2E2E35", "#F5B81C", "#F2F2F2", "#9A9AA3", "#121214"),
        Theme("اقیانوس", "#0B1220", "#121C30", "#22304D", "#4CC3FF", "#EAF2FF", "#8EA3C4", "#06121F"),
        Theme("زمرد", "#0A1512", "#11221D", "#1F3A31", "#3DDC97", "#E8F7F0", "#86A79A", "#06130E"),
        Theme("یاقوت", "#170B10", "#241119", "#3E1F2B", "#FF5C8A", "#FBEAF0", "#B58A98", "#1F0710"),
        Theme("بنفش", "#100D1C", "#191530", "#2C2650", "#A98BFF", "#EFEBFF", "#9A93C2", "#140B2E"),
        Theme("روشن", "#F6F7FB", "#FFFFFF", "#E2E5EE", "#3B6CF6", "#14161C", "#6B7285", "#FFFFFF", true)
    )
}

object C {
    var BG = Color.parseColor("#121214")
    var SURF = Color.parseColor("#1C1C20")
    var LINE = Color.parseColor("#2E2E35")
    var AMBER = Color.parseColor("#F5B81C")
    var TEXT = Color.parseColor("#F2F2F2")
    var SUB = Color.parseColor("#9A9AA3")
    var ON = Color.parseColor("#121214")
    var LIGHT = false
    val RED = Color.parseColor("#FF5C5C")
    fun use(i: Int) {
        val t = Themes.list[i.coerceIn(0, Themes.list.size - 1)]
        BG = Color.parseColor(t.bg); SURF = Color.parseColor(t.surf); LINE = Color.parseColor(t.line)
        AMBER = Color.parseColor(t.accent); TEXT = Color.parseColor(t.text); SUB = Color.parseColor(t.sub)
        ON = Color.parseColor(t.on); LIGHT = t.light
    }
}

object Fonts {
    var reg: Typeface = Typeface.DEFAULT
    var bold: Typeface = Typeface.DEFAULT_BOLD
    private var done = false
    fun load(c: Context) {
        if (done) return
        done = true
        try { reg = Typeface.createFromAsset(c.assets, "fonts/Vazirmatn-Regular.ttf") } catch (e: Exception) {}
        bold = try { Typeface.createFromAsset(c.assets, "fonts/Vazirmatn-Bold.ttf") } catch (e: Exception) { Typeface.create(reg, Typeface.BOLD) }
    }
}

fun tint(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
fun ltr(a: String) = if (a.isNotEmpty() && (a[0] == '+' || a[0].isDigit() || a[0] in 'A'..'Z' || a[0] in 'a'..'z')) "\u202A$a\u202C" else a
fun Activity.themed() {
    Fonts.load(this)
    C.use(Prefs(this).theme)
    window.setBackgroundDrawable(ColorDrawable(C.BG))
    window.statusBarColor = C.BG; window.navigationBarColor = C.BG
    WindowCompat.getInsetsController(window, window.decorView).apply {
        isAppearanceLightStatusBars = C.LIGHT; isAppearanceLightNavigationBars = C.LIGHT
    }
}

fun dp(v: Int) = (v * Resources.getSystem().displayMetrics.density).toInt()
fun bg(color: Int, r: Int = 16, stroke: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
}
fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
fun tv(c: Context, t: String, size: Float, color: Int, bold: Boolean = false) = TextView(c).apply {
    text = t; textSize = size; setTextColor(color); typeface = if (bold) Fonts.bold else Fonts.reg
    textDirection = View.TEXT_DIRECTION_FIRST_STRONG_RTL
    textAlignment = View.TEXT_ALIGNMENT_VIEW_START
}
fun btn(c: Context, t: String, filled: Boolean = true, cb: () -> Unit) =
    tv(c, t, 14f, if (filled) C.ON else C.AMBER, true).apply {
        gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
        background = bg(if (filled) C.AMBER else Color.TRANSPARENT, 14, if (filled) 0 else C.AMBER)
        setPadding(dp(18), dp(12), dp(18), dp(12)); setOnClickListener { cb() }
    }
fun card(c: Context) = LinearLayout(c).apply {
    orientation = LinearLayout.VERTICAL; background = bg(C.SURF, 18, C.LINE)
    setPadding(dp(16), dp(16), dp(16), dp(16))
    layoutParams = LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(12) }
}
fun switchRow(c: Context, title: String, desc: String, on: Boolean, cb: (Boolean) -> Unit): LinearLayout {
    val r = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
    val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, W, 1f) }
    col.addView(tv(c, title, 16f, C.TEXT, true)); col.addView(tv(c, desc, 12f, C.SUB))
    val s = MaterialSwitch(c).apply {
        isChecked = on; setOnCheckedChangeListener { _, v -> cb(v) }
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(st, intArrayOf(C.ON, C.SUB))
        trackTintList = ColorStateList(st, intArrayOf(C.AMBER, C.LINE))
    }
    r.addView(col); r.addView(s); return r
}
fun EditText.onText(cb: (String) -> Unit) = addTextChangedListener(object : TextWatcher {
    override fun afterTextChanged(s: Editable?) { cb(s.toString()) }
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
})
fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

fun norm(s: String) = s.replace('ي', 'ی').replace('ك', 'ک').replace("\u200c", "").lowercase()
fun fmtTime(t: Long): String {
    val n = Calendar.getInstance(); val d = Calendar.getInstance().apply { timeInMillis = t }
    val same = n.get(Calendar.YEAR) == d.get(Calendar.YEAR) && n.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR)
    return SimpleDateFormat(if (same) "HH:mm" else "MM/dd", Locale.getDefault()).format(Date(t))
}

data class Msg(val id: Long, val addr: String, val body: String, val date: Long, val type: Int,
               val thread: Long, val spam: Boolean = false, val unread: Boolean = false)

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("p", 0)
    var enabled: Boolean get() = p.getBoolean("en", true); set(v) { p.edit().putBoolean("en", v).apply() }
    var showSpam: Boolean get() = p.getBoolean("show", false); set(v) { p.edit().putBoolean("show", v).apply() }
    var rules: List<String>
        get() = p.getString("rules", null)?.split("\n")?.filter { it.isNotBlank() }
            ?: listOf("تخفیف", "اقساط", "اعتبار اضطراری", "اسنپ", "ورود به بام", "قسطی", "رایتل", "دیجی\u200cپی")
        set(v) { p.edit().putString("rules", v.joinToString("\n")).apply() }
    var theme: Int get() = p.getInt("theme", 0); set(v) { p.edit().putInt("theme", v).apply() }
    fun isSpam(addr: String, body: String): Boolean {
        if (!enabled) return false
        val b = norm(body); val a = norm(addr); val bs = b.replace(" ", "")
        return rules.any {
            val r = norm(it); val rs = r.replace(" ", "")
            b.contains(r) || a.contains(r) || (rs.isNotEmpty() && bs.contains(rs))
        }
    }
}

class SpamDb(c: Context) : SQLiteOpenHelper(c, "spam.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE spam(id INTEGER PRIMARY KEY AUTOINCREMENT, addr TEXT, body TEXT, date INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    fun add(a: String, b: String, d: Long) {
        writableDatabase.insert("spam", null, ContentValues().apply { put("addr", a); put("body", b); put("date", d) })
    }
    fun all(): List<Msg> {
        val o = ArrayList<Msg>()
        readableDatabase.rawQuery("SELECT id,addr,body,date FROM spam ORDER BY date DESC", null).use {
            while (it.moveToNext()) o.add(Msg(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "", it.getLong(3), 1, -it.getLong(0), true))
        }
        return o
    }
    fun count() = DatabaseUtils.queryNumEntries(readableDatabase, "spam").toInt()
    fun delete(id: Long) { writableDatabase.delete("spam", "id=?", arrayOf(id.toString())) }
    fun clear() { writableDatabase.delete("spam", null, null) }
}

fun readSms(c: Context, sel: String?, args: Array<String>?, order: String): List<Msg> {
    val out = ArrayList<Msg>()
    try {
        c.contentResolver.query(Telephony.Sms.CONTENT_URI,
            arrayOf("_id", "address", "body", "date", "type", "thread_id", "read"), sel, args, order)?.use {
            while (it.moveToNext()) out.add(Msg(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "",
                it.getLong(3), it.getInt(4), it.getLong(5), false, it.getInt(6) == 0))
        }
    } catch (e: Exception) {}
    return out
}

object Names {
    private val m = HashMap<String, String>()
    fun get(c: Context, a: String): String = m.getOrPut(a) {
        try {
            val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(a))
            c.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: ltr(a)
        } catch (e: Exception) { ltr(a) }
    }
}

fun isDefault(c: Context): Boolean {
    if (Build.VERSION.SDK_INT >= 29) try {
        if (c.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_SMS)) return true
    } catch (e: Exception) {}
    return Telephony.Sms.getDefaultSmsPackage(c) == c.packageName
}
fun requestDefault(a: Activity) {
    if (Build.VERSION.SDK_INT >= 29) {
        val rm = a.getSystemService(RoleManager::class.java)
        a.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 2)
    } else a.startActivity(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
        .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, a.packageName))
}
fun ensurePerms(a: Activity) {
    val l = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE)
    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
    val miss = l.filter { a.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    if (miss.isNotEmpty()) a.requestPermissions(miss.toTypedArray(), 1)
}
fun restoreToInbox(c: Context, m: Msg): Boolean = try {
    c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
        put(Telephony.Sms.ADDRESS, m.addr); put(Telephony.Sms.BODY, m.body)
        put(Telephony.Sms.DATE, m.date); put(Telephony.Sms.READ, 0)
    }) != null
} catch (e: Exception) { false }
