package com.heimdall.sms

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Resources
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.LinearGradient
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import androidx.core.view.WindowCompat
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Telephony
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.*

const val M = -1
const val W = -2

class Theme(val name: String, val bg: String, val surf: String, val line: String, val accent: String,
            val text: String, val sub: String, val on: String, val light: Boolean = false)

object Themes {
    // All palettes are light; no dark/black backgrounds remain.
    val list = listOf(
        Theme("کهربایی", "#FFF9EC", "#FFFFFF", "#F1E3C5", "#D99A00", "#29251D", "#887B62", "#FFFFFF", true),
        Theme("اقیانوس", "#EFF8FF", "#FFFFFF", "#D5EAF8", "#1687C9", "#172B3A", "#6D8799", "#FFFFFF", true),
        Theme("زمرد", "#EFFAF4", "#FFFFFF", "#D5EBDD", "#159B68", "#19352A", "#6D8D7D", "#FFFFFF", true),
        Theme("یاقوت", "#FFF1F5", "#FFFFFF", "#F4D9E2", "#D94D79", "#3B202A", "#987481", "#FFFFFF", true),
        Theme("بنفش", "#F6F1FF", "#FFFFFF", "#E5DDF7", "#8056D9", "#2D2440", "#82769F", "#FFFFFF", true),
        Theme("روشن", "#F5F7FC", "#FFFFFF", "#E2E7F0", "#3B6CF6", "#171B25", "#697386", "#FFFFFF", true)
    )
}


// High-quality offline chat wallpapers bundled with the app.
data class ChatWallpaper(val name: String, val resId: Int)
object ChatWallpapers {
    val list = listOf(
        ChatWallpaper("قله مه‌آلود", R.drawable.wallpaper_00),
        ChatWallpaper("کوهستان بنفش", R.drawable.wallpaper_01),
        ChatWallpaper("غروب مخملی", R.drawable.wallpaper_02),
        ChatWallpaper("دره زمرد", R.drawable.wallpaper_03),
        ChatWallpaper("آبی عمیق", R.drawable.wallpaper_04),
        ChatWallpaper("موج‌های آرام", R.drawable.wallpaper_05),
        ChatWallpaper("اقیانوس یخی", R.drawable.wallpaper_06),
        ChatWallpaper("دریای نیلی", R.drawable.wallpaper_07),
        ChatWallpaper("موج مرجانی", R.drawable.wallpaper_08),
        ChatWallpaper("آب‌های فیروزه‌ای", R.drawable.wallpaper_09),
        ChatWallpaper("برگ‌های لطیف", R.drawable.wallpaper_10),
        ChatWallpaper("باغ بهاری", R.drawable.wallpaper_11),
        ChatWallpaper("شاخ‌وبرگ زمرد", R.drawable.wallpaper_12),
        ChatWallpaper("باغ شبانه", R.drawable.wallpaper_13),
        ChatWallpaper("گلبرگ یاسی", R.drawable.wallpaper_14),
        ChatWallpaper("ماه نقره‌ای", R.drawable.wallpaper_15),
        ChatWallpaper("آسمان کهکشانی", R.drawable.wallpaper_16),
        ChatWallpaper("شفق قطبی", R.drawable.wallpaper_17),
        ChatWallpaper("شب بنفش", R.drawable.wallpaper_18),
        ChatWallpaper("ستاره‌های دور", R.drawable.wallpaper_19),
        ChatWallpaper("روبان ابریشمی", R.drawable.wallpaper_20),
        ChatWallpaper("موج طلایی", R.drawable.wallpaper_21),
        ChatWallpaper("خطوط هنری", R.drawable.wallpaper_22),
        ChatWallpaper("قوس‌های مدرن", R.drawable.wallpaper_23),
        ChatWallpaper("طرح مینیمال", R.drawable.wallpaper_24),
        ChatWallpaper("هندسه آبی", R.drawable.wallpaper_25),
        ChatWallpaper("هندسه یاسی", R.drawable.wallpaper_26),
        ChatWallpaper("هندسه زمرد", R.drawable.wallpaper_27),
        ChatWallpaper("هنر انتزاعی", R.drawable.wallpaper_28),
        ChatWallpaper("موج‌های طلایی", R.drawable.wallpaper_29)
    )
}

object C {
    var BG = Color.parseColor("#FFF9EC")
    var SURF = Color.parseColor("#FFFFFF")
    var LINE = Color.parseColor("#F1E3C5")
    var AMBER = Color.parseColor("#F5B81C")
    var TEXT = Color.parseColor("#29251D")
    var SUB = Color.parseColor("#887B62")
    var ON = Color.parseColor("#FFFFFF")
    var LIGHT = true
    val RED = Color.parseColor("#FF5C5C")
    fun use(i: Int) {
        val t = Themes.list[i.coerceIn(0, Themes.list.size - 1)]
        BG = Color.parseColor(t.bg); SURF = Color.parseColor(t.surf); LINE = Color.parseColor(t.line)
        AMBER = Color.parseColor(t.accent); TEXT = Color.parseColor(t.text); SUB = Color.parseColor(t.sub)
        ON = Color.parseColor(t.on); LIGHT = t.light
    }
}

object Fonts {
    var reg: Typeface = Typeface.DEFAULT
    var bold: Typeface = Typeface.DEFAULT_BOLD
    private var done = false
    fun load(c: Context) {
        if (done) return
        done = true
        try { reg = Typeface.createFromAsset(c.assets, "fonts/Vazirmatn-Regular.ttf") } catch (e: Exception) {}
        bold = try { Typeface.createFromAsset(c.assets, "fonts/Vazirmatn-Bold.ttf") } catch (e: Exception) { Typeface.create(reg, Typeface.BOLD) }
    }
}

fun tint(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
fun ltr(a: String) = if (a.isNotEmpty() && (a[0] == '+' || a[0].isDigit() || a[0] in 'A'..'Z' || a[0] in 'a'..'z')) "\u202A$a\u202C" else a
fun Activity.themed() {
    Fonts.load(this)
    C.use(Prefs(this).theme)
    window.setBackgroundDrawable(ColorDrawable(C.BG))
    window.statusBarColor = C.BG; window.navigationBarColor = C.BG
    WindowCompat.getInsetsController(window, window.decorView).apply {
        isAppearanceLightStatusBars = C.LIGHT; isAppearanceLightNavigationBars = C.LIGHT
    }
}

fun dp(v: Int) = (v * Resources.getSystem().displayMetrics.density).toInt()
fun bg(color: Int, r: Int = 16, stroke: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
}
fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
fun tv(c: Context, t: String, size: Float, color: Int, bold: Boolean = false) = TextView(c).apply {
    text = t; textSize = size; setTextColor(color); typeface = if (bold) Fonts.bold else Fonts.reg
    textDirection = View.TEXT_DIRECTION_FIRST_STRONG_RTL
    textAlignment = View.TEXT_ALIGNMENT_VIEW_START
}
fun btn(c: Context, t: String, filled: Boolean = true, cb: () -> Unit) =
    tv(c, t, 14f, if (filled) C.ON else C.AMBER, true).apply {
        gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            if (filled) intArrayOf(tint(C.AMBER, 255), tint(C.AMBER, 205)) else intArrayOf(tint(C.SURF, 250), tint(C.BG, 245))).apply {
            cornerRadius = dp(18).toFloat(); setStroke(dp(1), if (filled) tint(C.ON, 100) else tint(C.AMBER, 110))
        }
        elevation = dp(if (filled) 5 else 2).toFloat()
        setPadding(dp(20), dp(13), dp(20), dp(13)); isAllCaps = false
        setOnClickListener { animate().scaleX(.97f).scaleY(.97f).setDuration(75).withEndAction { animate().scaleX(1f).scaleY(1f).setDuration(110).start(); cb() }.start() }
    }
fun card(c: Context) = LinearLayout(c).apply {
    orientation = LinearLayout.VERTICAL
    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.SURF, tint(C.BG, 245))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), C.LINE) }
    elevation = dp(3).toFloat(); setPadding(dp(16), dp(16), dp(16), dp(16))
    layoutParams = LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(12) }
}
fun switchRow(c: Context, title: String, desc: String, on: Boolean, cb: (Boolean) -> Unit): LinearLayout {
    val r = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
    val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, W, 1f) }
    col.addView(tv(c, title, 16f, C.TEXT, true)); col.addView(tv(c, desc, 12f, C.SUB))
    val s = MaterialSwitch(c).apply {
        isChecked = on; setOnCheckedChangeListener { _, v -> cb(v) }
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(st, intArrayOf(C.ON, C.SUB))
        trackTintList = ColorStateList(st, intArrayOf(C.AMBER, C.LINE))
    }
    r.addView(col); r.addView(s); return r
}
fun EditText.onText(cb: (String) -> Unit) = addTextChangedListener(object : TextWatcher {
    override fun afterTextChanged(s: Editable?) { cb(s.toString()) }
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
})
fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

fun norm(s: String) = s.replace('ي', 'ی').replace('ك', 'ک').replace("\u200c", "").lowercase()
fun fmtTime(t: Long): String {
    val n = Calendar.getInstance(); val d = Calendar.getInstance().apply { timeInMillis = t }
    val same = n.get(Calendar.YEAR) == d.get(Calendar.YEAR) && n.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR)
    return SimpleDateFormat(if (same) "HH:mm" else "MM/dd", Locale.getDefault()).format(Date(t))
}

data class Msg(val id: Long, val addr: String, val body: String, val date: Long, val type: Int,
               val thread: Long, val spam: Boolean = false, val unread: Boolean = false)

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("p", 0)
    var enabled: Boolean get() = p.getBoolean("en", true); set(v) { p.edit().putBoolean("en", v).apply() }
    var showSpam: Boolean get() = p.getBoolean("show", false); set(v) { p.edit().putBoolean("show", v).apply() }
    var rules: List<String>
        get() = p.getString("rules", null)?.split("\n")?.filter { it.isNotBlank() }
            ?: listOf("تخفیف", "اقساط", "اعتبار اضطراری", "اسنپ", "ورود به بام", "قسطی", "رایتل", "دیجی\u200cپی")
        set(v) { p.edit().putString("rules", v.joinToString("\n")).apply() }
    var theme: Int get() = p.getInt("theme", 0); set(v) { p.edit().putInt("theme", v).apply() }
    var chatWallpaper: Int get() = p.getInt("chat_wallpaper", -1).coerceIn(-1, ChatWallpapers.list.size - 1); set(v) { p.edit().putInt("chat_wallpaper", v.coerceIn(-1, ChatWallpapers.list.size - 1)).apply() }
    var showWisdom: Boolean get() = p.getBoolean("wisdom", true); set(v) { p.edit().putBoolean("wisdom", v).apply() }
    var showNeon: Boolean get() = p.getBoolean("neon", true); set(v) { p.edit().putBoolean("neon", v).apply() }
    var flashOnSms: Boolean get() = p.getBoolean("flash_sms", false); set(v) { p.edit().putBoolean("flash_sms", v).apply() }
    var notificationSound: String get() = p.getString("notification_sound", "") ?: ""; set(v) { p.edit().putString("notification_sound", v).apply() }
    var blockedNumbers: Set<String>
        get() = p.getStringSet("blocked_numbers", emptySet())?.toSet() ?: emptySet()
        set(v) { p.edit().putStringSet("blocked_numbers", v.toSet()).apply() }
    fun isBlocked(addr: String): Boolean {
        val a = norm(addr).filter { it.isDigit() }
        return a.isNotEmpty() && blockedNumbers.any { norm(it).filter { ch -> ch.isDigit() }.let { b -> b.isNotEmpty() && (a.endsWith(b) || b.endsWith(a)) } }
    }
    fun isSpam(addr: String, body: String): Boolean {
        if (!enabled) return false
        val b = norm(body); val a = norm(addr); val bs = b.replace(" ", "")
        return rules.any {
            val r = norm(it); val rs = r.replace(" ", "")
            b.contains(r) || a.contains(r) || (rs.isNotEmpty() && bs.contains(rs))
        }
    }
}

class SpamDb(c: Context) : SQLiteOpenHelper(c, "spam.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE spam(id INTEGER PRIMARY KEY AUTOINCREMENT, addr TEXT, body TEXT, date INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    fun add(a: String, b: String, d: Long): Long {
        return writableDatabase.insert("spam", null, ContentValues().apply { put("addr", a); put("body", b); put("date", d) })
    }
    fun all(): List<Msg> {
        purgeExpired()
        val o = ArrayList<Msg>()
        readableDatabase.rawQuery("SELECT id,addr,body,date FROM spam ORDER BY date DESC", null).use {
            while (it.moveToNext()) o.add(Msg(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "", it.getLong(3), 1, -it.getLong(0), true))
        }
        return o
    }
    fun count(): Int { purgeExpired(); return DatabaseUtils.queryNumEntries(readableDatabase, "spam").toInt() }
    fun purgeExpired() { writableDatabase.delete("spam", "date <= ?", arrayOf((System.currentTimeMillis() - 5L * 60L * 60L * 1000L).toString())) }
    fun delete(id: Long) { writableDatabase.delete("spam", "id=?", arrayOf(id.toString())) }
    fun clear() { writableDatabase.delete("spam", null, null) }
}

fun readSms(c: Context, sel: String?, args: Array<String>?, order: String): List<Msg> {
    val out = ArrayList<Msg>()
    try {
        c.contentResolver.query(Telephony.Sms.CONTENT_URI,
            arrayOf("_id", "address", "body", "date", "type", "thread_id", "read"), sel, args, order)?.use {
            while (it.moveToNext()) out.add(Msg(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "",
                it.getLong(3), it.getInt(4), it.getLong(5), false, it.getInt(6) == 0))
        }
    } catch (e: Exception) {}
    return out
}

object Names {
    private val m = HashMap<String, String>()
    fun get(c: Context, a: String): String = m.getOrPut(a) {
        try {
            val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(a))
            c.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: ltr(a)
        } catch (e: Exception) { ltr(a) }
    }
}

fun isDefault(c: Context): Boolean {
    if (Build.VERSION.SDK_INT >= 29) try {
        if (c.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_SMS)) return true
    } catch (e: Exception) {}
    return Telephony.Sms.getDefaultSmsPackage(c) == c.packageName
}
fun requestDefault(a: Activity) {
    if (isDefault(a)) { toast(a, "کیان هم‌اکنون پیام‌رسان پیش‌فرض است"); return }
    try {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = a.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_SMS))
                a.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 2)
            else toast(a, "امکان انتخاب پیام‌رسان پیش‌فرض در این دستگاه در دسترس نیست")
        } else a.startActivityForResult(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, a.packageName), 2)
    } catch (e: Exception) { toast(a, "باز کردن تنظیمات پیام‌رسان پیش‌فرض ممکن نشد") }
}
fun ensurePerms(a: Activity) {
    val l = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE)
    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
    val miss = l.filter { a.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    if (miss.isNotEmpty()) a.requestPermissions(miss.toTypedArray(), 1)
}
fun restoreToInbox(c: Context, m: Msg): Boolean = try {
    c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
        put(Telephony.Sms.ADDRESS, m.addr); put(Telephony.Sms.BODY, m.body)
        put(Telephony.Sms.DATE, m.date); put(Telephony.Sms.READ, 0)
    }) != null
} catch (e: Exception) { false }
