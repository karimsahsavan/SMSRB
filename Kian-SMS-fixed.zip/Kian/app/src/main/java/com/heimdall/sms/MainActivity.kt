package com.heimdall.sms

import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton

class RowAdapter(val onClick: (Msg) -> Unit, val onLong: (Msg) -> Unit, val onSelection: (Msg, Boolean) -> Unit) : RecyclerView.Adapter<RowAdapter.VH>() {
    var items: List<Msg> = emptyList()
    var mode = 0
    var selectedIds: Set<Long> = emptySet()
    var selectionMode: Boolean = false
    private fun key(m: Msg) = if (mode == 0) m.thread else m.id
    class VH(val v: LinearLayout, val av: Avatar, val name: TextView, val body: TextView,
             val time: TextView, val badge: TextView, val check: CheckBox) : RecyclerView.ViewHolder(v)

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val c = p.context
        val row = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(13), dp(16), dp(13))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.SURF, tint(C.BG, 250))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), C.LINE) }
            elevation = dp(2).toFloat()
            layoutParams = RecyclerView.LayoutParams(M, W).apply { setMargins(dp(12), dp(5), dp(12), dp(5)) }
        }
        val av = Avatar(c).apply { layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)) }
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(12); marginEnd = dp(12) }
        }
        val name = tv(c, "", 16f, C.TEXT, true).apply { maxLines = 1 }
        val body = tv(c, "", 13f, C.SUB).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        col.addView(name); col.addView(body)
        val right = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        val time = tv(c, "", 11f, C.SUB)
        val badge = tv(c, "", 11f, C.AMBER, true)
        right.addView(time); right.addView(badge)
        val check = CheckBox(c).apply { buttonTintList = ColorStateList.valueOf(C.AMBER) }
        right.addView(check)
        row.addView(av); row.addView(col); row.addView(right)
        return VH(row, av, name, body, time, badge, check)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val m = items[i]; val n = Names.get(h.v.context, m.addr)
        h.av.set(m.addr, m.spam)
        h.name.text = n
        h.body.text = (if (m.type == 2 && mode == 0) "شما: " else "") + m.body.replace("
", " ")
        h.body.setTextColor(if (m.unread) C.TEXT else C.SUB)
        h.time.text = fmtTime(m.date)
        h.badge.visibility = if (m.spam || m.unread) View.VISIBLE else View.GONE
        h.badge.text = if (m.spam) "مزاحم" else "●"
        h.badge.setTextColor(if (m.spam) C.RED else C.AMBER)
        h.check.setOnCheckedChangeListener(null)
        h.check.visibility = if (selectionMode) View.VISIBLE else View.GONE
        h.check.isChecked = key(m) in selectedIds
        h.check.setOnCheckedChangeListener { _, checked -> onSelection(m, checked) }
        h.v.setOnClickListener { if (selectionMode) onSelection(m, key(m) !in selectedIds) else onClick(m) }
        h.v.setOnLongClickListener { onLong(m); true }
    }
}

class MainActivity : AppCompatActivity() {
    lateinit var prefs: Prefs
    lateinit var db: SpamDb
    lateinit var ad: RowAdapter
    lateinit var tabs: List<TextView>
    lateinit var banner: TextView
    lateinit var wisdomBanner: WisdomBanner
    lateinit var neonBar: NeonBar
    lateinit var empty: TextView
    var tab = 0
    var applied = -1
    var all: List<Msg> = emptyList()
    var query = ""
    val selectedIds = linkedSetOf<Long>()
    lateinit var selectionAction: TextView
    val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { refresh() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); themed()
        window.enterTransition = android.transition.Fade().apply { duration = 220 }
        window.exitTransition = android.transition.Fade().apply { duration = 180 }
        prefs = Prefs(this); db = SpamDb(this); applied = prefs.theme
        ad = RowAdapter({ m ->
            if (m.spam) spamDialog(m) else startActivity(Intent(this, ConversationActivity::class.java)
                .putExtra("addr", m.addr).putExtra("thread", m.thread))
        }, { m -> toggleSelection(m, true) }, { m, checked -> toggleSelection(m, checked) })

        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.BG, tint(C.AMBER, 20), C.BG))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, 0) }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(5), dp(12), dp(5))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(tint(C.SURF, 245), tint(C.BG, 220))).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), C.LINE) }
            elevation = dp(3).toFloat(); layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(12), dp(4), dp(12), dp(8)) }
        }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo); layoutParams = LinearLayout.LayoutParams(dp(54), dp(54)) })
        head.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
        selectionAction = tv(this, "حذف انتخاب‌شده‌ها", 12f, C.RED, true).apply {
            background = bg(tint(C.RED, 20), 14, tint(C.RED, 100)); setPadding(dp(12), dp(9), dp(12), dp(9)); visibility = View.GONE
            setOnClickListener { confirmDeleteSelected() }
        }
        head.addView(selectionAction)
        head.addView(tv(this, "⚙", 24f, C.TEXT).apply {
            background = bg(tint(C.AMBER, 25), 14, tint(C.AMBER, 80)); setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        banner = tv(this, "برای فعال‌سازی کامل پیامک، اینجا بزنید", 13f, C.ON, true).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(tint(C.AMBER, 250), tint(C.AMBER, 195))).apply { cornerRadius = dp(16).toFloat(); setStroke(dp(1), tint(C.ON, 100)) }
            elevation = dp(3).toFloat(); setPadding(dp(14), dp(12), dp(14), dp(12)); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(16), dp(4), dp(16), dp(8)) }
            setOnClickListener { requestDefault(this@MainActivity) }
        }
        val tr = LinearLayout(this).apply {
            setPadding(dp(8), dp(5), dp(8), dp(5))
            background = bg(tint(C.SURF, 190), 18, C.LINE)
            layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(14), dp(3), dp(14), dp(9)) }
        }
        tabs = listOf("ورودی", "ارسالی", "مزاحم").mapIndexed { i, n ->
            tv(this, n, 14f, C.TEXT, true).apply {
                gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; setPadding(dp(8), dp(12), dp(8), dp(12))
                layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
                setOnClickListener { tab = i; selectedIds.clear(); updateSelectionUi(); refresh() }
            }
        }
        tabs.forEach { tr.addView(it) }
        val search = EditText(this).apply { typeface = Fonts.reg; textAlignment = View.TEXT_ALIGNMENT_VIEW_START;
            hint = "جستجو در پیامک‌ها…"; setHintTextColor(C.SUB); setTextColor(C.TEXT); textSize = 14f
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.SURF, tint(C.BG, 245))).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), C.LINE) }
            elevation = dp(2).toFloat(); setPadding(dp(17), dp(13), dp(17), dp(13)); isSingleLine = true
            layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(14), 0, dp(14), dp(9)) }
            onText { query = it; show() }
        }
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity); adapter = ad
            itemAnimator = androidx.recyclerview.widget.DefaultItemAnimator().apply { addDuration = 220; removeDuration = 280; moveDuration = 220; changeDuration = 180 }
            clipToPadding = false; setPadding(0, 0, 0, dp(96))
            layoutParams = LinearLayout.LayoutParams(M, 0, 1f)
        }
        neonBar = NeonBar(this).apply { layoutParams = LinearLayout.LayoutParams(M, dp(32)) }
        wisdomBanner = WisdomBanner(this).apply { layoutParams = LinearLayout.LayoutParams(M, dp(104)).apply { setMargins(dp(14), dp(2), dp(14), dp(8)) } }
        col.addView(neonBar)
        col.addView(head); col.addView(wisdomBanner); col.addView(banner); col.addView(tr); col.addView(search); col.addView(rv)
        empty = tv(this, "پیامی وجود ندارد", 15f, C.SUB).apply {
            layoutParams = FrameLayout.LayoutParams(W, W, Gravity.CENTER)
        }
        val fab = ExtendedFloatingActionButton(this).apply {
            text = "✦  پیام جدید"; typeface = Fonts.bold; setTextColor(C.ON); backgroundTintList = ColorStateList.valueOf(C.AMBER)
            elevation = dp(10).toFloat(); cornerRadius = dp(24)
            layoutParams = FrameLayout.LayoutParams(W, W, Gravity.BOTTOM or Gravity.END).apply { setMargins(dp(20), dp(20), dp(20), dp(24)) }
            setOnClickListener { startActivity(Intent(this@MainActivity, ConversationActivity::class.java)) }
        }
        root.addView(col, FrameLayout.LayoutParams(M, M)); root.addView(empty); root.addView(fab)
        setContentView(root)
        ensurePerms(this)
    }

    override fun onStart() {
        super.onStart(); contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs)
    }
    override fun onStop() { super.onStop(); contentResolver.unregisterContentObserver(obs) }
    override fun onResume() {
        super.onResume()
        SpamDb(this).purgeExpired()
        if (Prefs(this).theme != applied) { recreate(); return }
        checkDefault(); applyDisplayOptions(); refresh()
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); refresh()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (selectedIds.isNotEmpty()) {
            selectedIds.clear(); updateSelectionUi(); refresh()
        } else super.onBackPressed()
    }

    fun applyDisplayOptions() {
        val p = Prefs(this)
        wisdomBanner.visibility = if (p.showWisdom) View.VISIBLE else View.GONE
        neonBar.visibility = if (p.showNeon) View.VISIBLE else View.GONE
    }

    fun checkDefault() { banner.visibility = if (isDefault(this)) View.GONE else View.VISIBLE }
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        Handler(Looper.getMainLooper()).postDelayed({ checkDefault(); refresh() }, 250)
    }

    fun refresh() {
        Thread {
            val list: List<Msg> = when (tab) {
                0 -> {
                    val m = readSms(this, null, null, "date DESC")
                    val unreadT = m.filter { it.unread }.map { it.thread }.toSet()
                    val seen = HashSet<Long>()
                    val l = m.filter { seen.add(it.thread) }.map { it.copy(unread = it.thread in unreadT) }
                    if (prefs.showSpam) (l + db.all()).sortedByDescending { it.date } else l
                }
                1 -> readSms(this, "type=2", null, "date DESC")
                else -> db.all()
            }
            list.map { it.addr }.distinct().forEach { Names.get(this, it) }
            val sc = db.count()
            runOnUiThread { all = list; tabs[2].text = "مزاحم ($sc)"; show() }
        }.start()
    }

    fun show() {
        val q = norm(query)
        val l = if (q.isEmpty()) all else all.filter {
            norm(it.body).contains(q) || norm(Names.get(this, it.addr)).contains(q) || it.addr.contains(q)
        }
        ad.items = l; ad.mode = tab; ad.selectedIds = selectedIds; ad.selectionMode = selectedIds.isNotEmpty(); ad.notifyDataSetChanged()
        empty.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
        tabs.forEachIndexed { i, t ->
            val on = i == tab
            t.background = if (on) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tint(C.AMBER, 255), tint(C.AMBER, 205))).apply { cornerRadius = dp(15).toFloat(); setStroke(dp(1), tint(C.ON, 90)) } else bg(Color.TRANSPARENT, 15)
            t.setTextColor(if (on) C.ON else C.SUB); t.elevation = if (on) dp(3).toFloat() else 0f
        }
    }


    private fun selectionKey(m: Msg) = if (tab == 0) m.thread else m.id

    fun toggleSelection(m: Msg, checked: Boolean) {
        val key = selectionKey(m)
        if (checked) selectedIds.add(key) else selectedIds.remove(key)
        ad.selectionMode = selectedIds.isNotEmpty()
        updateSelectionUi()
        ad.selectedIds = selectedIds
        ad.notifyDataSetChanged()
    }

    fun updateSelectionUi() {
        selectionAction.visibility = if (selectedIds.isEmpty()) View.GONE else View.VISIBLE
        selectionAction.text = "حذف ${selectedIds.size} مورد انتخاب‌شده"
        if (::ad.isInitialized) { ad.selectionMode = selectedIds.isNotEmpty(); ad.selectedIds = selectedIds; ad.notifyDataSetChanged() }
    }

    fun confirmDeleteSelected() {
        if (selectedIds.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("حذف چندتایی")
            .setMessage("${selectedIds.size} مورد انتخاب شده است. همه حذف شوند؟")
            .setPositiveButton("حذف همه") { _, _ ->
                val chosen = all.filter { selectionKey(it) in selectedIds }
                try {
                    if (tab == 2) {
                        chosen.forEach { db.delete(it.id) }
                    } else if (tab == 0) {
                        chosen.forEach { m ->
                            if (m.spam) db.delete(m.id)
                            else contentResolver.delete(Uri.parse("content://sms/conversations/${m.thread}"), null, null)
                        }
                    } else {
                        chosen.forEach { m -> contentResolver.delete(Uri.parse("content://sms/${m.id}"), null, null) }
                    }
                    selectedIds.clear(); updateSelectionUi(); refresh()
                } catch (e: Exception) {
                    toast(this, "برای حذف پیامک‌ها، کیان باید برنامه پیامک پیش‌فرض باشد")
                }
            }
            .setNegativeButton("انصراف", null).show()
    }

    fun spamDialog(m: Msg) {
        AlertDialog.Builder(this).setTitle(m.addr).setMessage(m.body)
            .setPositiveButton("بازگردانی به ورودی") { _, _ ->
                if (restoreToInbox(this, m)) { db.delete(m.id); refresh() } else toast(this, "ابتدا برنامه را پیش‌فرض کنید")
            }
            .setNegativeButton("حذف") { _, _ -> db.delete(m.id); refresh() }
            .setNeutralButton("بستن", null).show()
    }

    fun confirmDelete(m: Msg) {
        AlertDialog.Builder(this).setTitle(if (tab == 0) "حذف گفتگو؟" else "حذف پیام؟")
            .setPositiveButton("حذف") { _, _ ->
                try {
                    contentResolver.delete(Uri.parse(if (tab == 0) "content://sms/conversations/${m.thread}" else "content://sms/${m.id}"), null, null)
                } catch (e: Exception) { toast(this, "ابتدا برنامه را پیش‌فرض کنید") }
                refresh()
            }.setNegativeButton("لغو", null).show()
    }
}
