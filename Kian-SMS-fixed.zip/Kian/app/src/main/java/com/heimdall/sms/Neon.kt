package com.heimdall.sms

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator

/** Colored neon streaks that sweep across the top at different speeds and directions. */
class NeonBar(c: Context) : View(c) {
    private val colors = listOf("#00E5FF", "#FF2BD6", "#7CFF4F", "#FFC53D", "#8C6BFF").map { Color.parseColor(it) }
    private val speeds = floatArrayOf(0.55f, 0.95f, 0.35f, 1.35f, 0.7f)
    private val phase = floatArrayOf(0f, 0.35f, 0.6f, 0.15f, 0.8f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private var core: List<LinearGradient> = emptyList()
    private var glow: List<LinearGradient> = emptyList()
    private var seg = 0f
    private val m = Matrix()
    private var t0 = 0L
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        seg = w * 0.4f
        fun mk(a: Int, col: Int) = LinearGradient(0f, 0f, seg, 0f,
            intArrayOf(Color.TRANSPARENT, Color.argb(a, Color.red(col), Color.green(col), Color.blue(col)), Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        core = colors.map { mk(255, it) }
        glow = colors.map { mk(80, it) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); t0 = SystemClock.uptimeMillis(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        if (core.isEmpty()) return
        val w = width.toFloat(); val h = height.toFloat()
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val n = colors.size
        for (i in 0 until n) {
            val y = h * (i + 1) / (n + 1)
            val pos = (t * speeds[i] + phase[i]) % 1f
            val x = -seg + pos * (w + seg)
            val xx = if (i % 2 == 0) x else w - x - seg
            m.setTranslate(xx, 0f)
            p.shader = null; p.color = Color.argb(28, 255, 255, 255); p.strokeWidth = dp(1).toFloat()
            cv.drawLine(0f, y, w, y, p)
            glow[i].setLocalMatrix(m); core[i].setLocalMatrix(m)
            p.shader = glow[i]; p.strokeWidth = dp(5).toFloat(); cv.drawLine(xx, y, xx + seg, y, p)
            p.shader = core[i]; p.strokeWidth = dp(1).toFloat() + 1.2f
            cv.drawLine(xx, y, xx + seg, y, p)
        }
    }
}
