package com.heimdall.sms

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import androidx.core.app.NotificationCompat

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val addr = parts[0].originatingAddress ?: ""
        val body = parts.joinToString("") { it.messageBody ?: "" }
        val date = System.currentTimeMillis()

        // Keep the receiver alive while the torch performs its short blink sequence.
        if (Prefs(c).flashOnSms && c.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            blinkFlash(c, goAsync())
        }

        if (Prefs(c).let { it.isBlocked(addr) || it.isSpam(addr, body) }) {
            val rowId = SpamDb(c).add(addr, body, date)
            scheduleQuarantineExpiry(c, rowId, date + 5L * 60L * 60L * 1000L)
        } else {
            restoreToInbox(c, Msg(0, addr, body, date, 1, 0))
            val otp = extractOtpCode(body)
            if (otp != null && Prefs(c).autoCopyOtp) copyToClipboard(c, otp)
            notifyMsg(c, addr, body, otp)
        }
    }
}

class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }
class RespondService : Service() { override fun onBind(i: Intent?): IBinder? = null }

private fun blinkFlash(c: Context, pending: BroadcastReceiver.PendingResult) {
    Thread {
        var camera: CameraManager? = null
        var id: String? = null
        try {
            val cm = c.getSystemService(CameraManager::class.java)
            camera = cm
            val cameraId = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            id = cameraId
            if (cameraId != null) {
                repeat(6) {
                    cm.setTorchMode(cameraId, true)
                    Thread.sleep(260)
                    cm.setTorchMode(cameraId, false)
                    Thread.sleep(240)
                }
            }
        } catch (_: Exception) {
            try {
                val cmSafe = camera
                val idSafe = id
                if (cmSafe != null && idSafe != null) cmSafe.setTorchMode(idSafe, false)
            } catch (_: Exception) {}
        } finally {
            pending.finish()
        }
    }.start()
}

fun notifyMsg(c: Context, addr: String, body: String, otpCode: String? = null) {
    val nm = c.getSystemService(NotificationManager::class.java)
    val pref = Prefs(c).notificationSound
    val soundUri: Uri? = when (pref) {
        "silent" -> null
        "" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        else -> try { Uri.parse(pref) } catch (_: Exception) { RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) }
    }
    val channelId = "msg_${(pref.ifEmpty { "default" }).hashCode()}"
    if (Build.VERSION.SDK_INT >= 26) {
        val channel = NotificationChannel(channelId, "پیامک دریافتی", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "اعلان پیامک‌های جدید کیان"
            enableVibration(true)
            setSound(soundUri, AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        }
        nm.createNotificationChannel(channel)
    }
    val pi = PendingIntent.getActivity(c, addr.hashCode(),
        Intent(c, ConversationActivity::class.java).putExtra("addr", addr),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    val builder = NotificationCompat.Builder(c, channelId)
        .setSmallIcon(android.R.drawable.ic_dialog_email)
        .setContentTitle(Names.get(c, addr)).setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setAutoCancel(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH)
    if (Build.VERSION.SDK_INT < 26) builder.setSound(soundUri)
    if (!otpCode.isNullOrBlank()) {
        val copyIntent = Intent(c, CopyOtpReceiver::class.java).putExtra("otp_code", otpCode).putExtra("notification_id", addr.hashCode())
        val copyPi = PendingIntent.getBroadcast(c, (addr.hashCode() xor 0x4F5450), copyIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        builder.addAction(android.R.drawable.ic_menu_save, "کپی رمز یکبارمصرف", copyPi)
    }
    try { nm.notify(addr.hashCode(), builder.build()) } catch (_: SecurityException) {}
}

fun copyToClipboard(c: Context, code: String) {
    val clipboard = c.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("رمز یکبارمصرف", code))
}

class CopyOtpReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val code = i.getStringExtra("otp_code")?.takeIf { it.matches(Regex("[0-9]{4,8}")) } ?: return
        copyToClipboard(c, code)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.cancel(i.getIntExtra("notification_id", 0))
        android.widget.Toast.makeText(c, "رمز یکبارمصرف کپی شد", android.widget.Toast.LENGTH_SHORT).show()
    }
}

private fun scheduleQuarantineExpiry(c: Context, rowId: Long, whenAt: Long) {
    val alarm = c.getSystemService(AlarmManager::class.java)
    val intent = Intent(c, QuarantineExpiryReceiver::class.java).putExtra("row_id", rowId)
    val pi = PendingIntent.getBroadcast(c, rowId.toInt(), intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    try {
        if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt, pi)
        else alarm.set(AlarmManager.RTC_WAKEUP, whenAt, pi)
    } catch (_: Exception) {}
}

class QuarantineExpiryReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        SpamDb(c).purgeExpired()
    }
}
