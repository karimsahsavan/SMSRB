package com.heimdall.sms

import android.app.AlertDialog
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.content.res.ColorStateList
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch

class SettingsActivity : AppCompatActivity() {
    lateinit var prefs: Prefs
    lateinit var db: SpamDb
    lateinit var chips: ChipGroup
    lateinit var ruleHead: TextView
    lateinit var purge: TextView
    lateinit var soundLabel: TextView
    lateinit var flashSwitch: MaterialSwitch
    private val ringtoneRequest = 73
    private val cameraRequest = 74

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); themed()
        prefs = Prefs(this); db = SpamDb(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(C.BG); layoutDirection = View.LAYOUT_DIRECTION_RTL; addView(col) })
        col.addView(tv(this, "←  تنظیمات", 22f, C.TEXT, true).apply {
            setPadding(0, dp(8), 0, dp(16)); setOnClickListener { finish() }
        })

        col.addView(card(this).apply {
            addView(switchRow(this@SettingsActivity, "فایروال پیامک", "فیلتر خودکار پیام‌های ورودی با کلمات مزاحم", prefs.enabled) { prefs.enabled = it })
        })

        col.addView(card(this).apply {
            addView(tv(this@SettingsActivity, "تشخیص هوشمند رمز بانکی", 16f, C.TEXT, true))
            addView(tv(this@SettingsActivity, "رمزهای ۴ تا ۸ رقمی را کنار واژه‌هایی مثل رمز، کد و OTP تشخیص می‌دهد و دکمه کپی به اعلان و صفحه گفتگو اضافه می‌کند.", 12f, C.SUB))
            addView(View(this@SettingsActivity).apply { layoutParams = LinearLayout.LayoutParams(M, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(12) }; setBackgroundColor(C.LINE) })
            addView(switchRow(this@SettingsActivity, "کپی خودکار رمز به حافظه", "با فعال‌سازی، رمز تشخیص‌داده‌شده هنگام دریافت پیامک در کلیپ‌بورد قرار می‌گیرد. در اندروید ممکن است محدودیت اجرای پس‌زمینه وجود داشته باشد.", prefs.autoCopyOtp) { prefs.autoCopyOtp = it })
        })
        val blockedInput = EditText(this).apply {
            hint = "شماره‌ها را با ویرگول جدا کن"
            setText(prefs.blockedNumbers.joinToString(", "))
            setTextColor(C.TEXT); setHintTextColor(C.SUB); textSize = 13f
            background = bg(C.BG, 12, C.LINE); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val blockedList = ChipGroup(this).apply {
            isSingleLine = false
            chipSpacingHorizontal = dp(6); chipSpacingVertical = dp(6)
        }
        val blockedEmpty = tv(this, "هنوز شماره‌ای مسدود نشده است", 12f, C.SUB)
        val blockedCountLabel = tv(this, "فهرست شماره‌های مسدود (${prefs.blockedNumbers.size})", 14f, C.TEXT, true)
        fun renderBlockedNumbers() {
            blockedList.removeAllViews()
            val numbers = prefs.blockedNumbers.sorted()
            blockedCountLabel.text = "فهرست شماره‌های مسدود (${numbers.size})"
            blockedEmpty.visibility = if (numbers.isEmpty()) View.VISIBLE else View.GONE
            numbers.forEach { number ->
                blockedList.addView(Chip(this).apply {
                    text = number
                    typeface = Fonts.reg
                    setTextColor(C.TEXT)
                    chipBackgroundColor = ColorStateList.valueOf(C.BG)
                    chipStrokeColor = ColorStateList.valueOf(C.LINE)
                    chipStrokeWidth = dp(1).toFloat()
                    isCloseIconVisible = true
                    closeIconTint = ColorStateList.valueOf(C.RED)
                    setOnCloseIconClickListener {
                        prefs.blockedNumbers = prefs.blockedNumbers - number
                        blockedInput.setText(prefs.blockedNumbers.joinToString(", "))
                        renderBlockedNumbers()
                        toast(this@SettingsActivity, "شماره از فهرست مسدودها برداشته شد")
                    }
                })
            }
        }
        col.addView(card(this).apply {
            addView(tv(this@SettingsActivity, "شماره‌های مسدودشده", 16f, C.TEXT, true))
            addView(tv(this@SettingsActivity, "شماره‌های این فهرست همیشه در همین بخش قابل مشاهده‌اند؛ پیامک آن‌ها وارد قرنطینه می‌شود و پس از ۵ ساعت خودکار حذف خواهد شد.", 12f, C.SUB).apply { setPadding(0, dp(4), 0, dp(8)) })
            addView(blockedInput)
            addView(btn(this@SettingsActivity, "ذخیره شماره‌های مسدود", true) {
                val numbers = blockedInput.text.toString().split(",", "،", "\n", ";", "؛")
                    .map { it.trim().filter { ch -> ch.isDigit() || ch == '+' } }
                    .filter { it.any(Char::isDigit) }.toSet()
                prefs.blockedNumbers = numbers
                blockedInput.setText(numbers.joinToString(", "))
                renderBlockedNumbers()
                toast(this@SettingsActivity, "${numbers.size} شماره در فهرست مسدودها ذخیره شد")
            }.apply { layoutParams = LinearLayout.LayoutParams(M, W).apply { topMargin = dp(8) } })
            addView(View(this@SettingsActivity).apply { layoutParams = LinearLayout.LayoutParams(M, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(10) }; setBackgroundColor(C.LINE) })
            addView(blockedCountLabel)
            addView(blockedEmpty)
            addView(blockedList)
        })
        renderBlockedNumbers()

        soundLabel = tv(this, currentSoundLabel(), 13f, C.SUB)
        col.addView(card(this).apply {
            addView(tv(this@SettingsActivity, "صدای اعلان پیامک", 16f, C.TEXT, true))
            addView(tv(this@SettingsActivity, "صدای دلخواه اعلان پیام‌های دریافتی را از آهنگ‌های گوشی انتخاب کن.", 12f, C.SUB).apply { setPadding(0, dp(4), 0, dp(8)) })
            addView(soundLabel)
            addView(btn(this@SettingsActivity, "انتخاب صدای اعلان", true) { chooseNotificationSound() }.apply {
                layoutParams = LinearLayout.LayoutParams(M, W).apply { topMargin = dp(10) }
            })
        })

        val flashRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val flashText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, W, 1f) }
        flashText.addView(tv(this, "چشمک چراغ‌قوه هنگام دریافت پیامک", 15f, C.TEXT, true))
        flashText.addView(tv(this, "هنگام رسیدن پیامک جدید، چراغ‌قوه چند بار چشمک می‌زند.", 12f, C.SUB))
        flashSwitch = MaterialSwitch(this).apply {
            isChecked = prefs.flashOnSms
            setOnCheckedChangeListener { _, checked ->
                if (checked && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    isChecked = false
                    requestPermissions(arrayOf(Manifest.permission.CAMERA), cameraRequest)
                } else prefs.flashOnSms = checked
            }
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(C.ON, C.SUB))
            trackTintList = ColorStateList(states, intArrayOf(C.AMBER, C.LINE))
        }
        flashRow.addView(flashText); flashRow.addView(flashSwitch)
        col.addView(card(this).apply { addView(flashRow) })

        col.addView(card(this).apply {
            addView(switchRow(this@SettingsActivity, "نمایش حکمت امام علی (ع)",
                "هر ۱۰ دقیقه یک سخن تازه نمایش داده می‌شود", prefs.showWisdom) { prefs.showWisdom = it })
            addView(View(this@SettingsActivity).apply { layoutParams = LinearLayout.LayoutParams(M, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(12) }; setBackgroundColor(C.LINE) })
            addView(switchRow(this@SettingsActivity, "افکت نئون",
                "روشن یا خاموش‌کردن نورهای رنگی بالای صفحه", prefs.showNeon) { prefs.showNeon = it })
        })

        val wallpaperRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        // The first tile restores the plain app background.
        val defaultPreview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(4), dp(5), dp(4))
            setOnClickListener { prefs.chatWallpaper = -1; recreate() }
        }
        val defaultTile = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(C.BG, C.SURF, C.LINE)).apply { cornerRadius = dp(14).toFloat() }
            foreground = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat(); setColor(Color.TRANSPARENT)
                setStroke(dp(if (prefs.chatWallpaper == -1) 3 else 1),
                    if (prefs.chatWallpaper == -1) C.AMBER else Color.WHITE)
            }
            layoutParams = LinearLayout.LayoutParams(dp(68), dp(82))
        }
        defaultPreview.addView(defaultTile)
        defaultPreview.addView(tv(this, "پیش‌فرض", 10f, if (prefs.chatWallpaper == -1) C.TEXT else C.SUB, prefs.chatWallpaper == -1).apply {
            gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
        })
        wallpaperRow.addView(defaultPreview)

        ChatWallpapers.list.forEachIndexed { i, wallpaper ->
            val preview = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(5), dp(4), dp(5), dp(4))
                setOnClickListener { prefs.chatWallpaper = i; recreate() }
            }
            val tile = View(this).apply {
                background = getDrawable(wallpaper.resId)
                clipToOutline = true
                foreground = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(if (i == prefs.chatWallpaper) 3 else 1), if (i == prefs.chatWallpaper) C.AMBER else Color.WHITE)
                }
                layoutParams = LinearLayout.LayoutParams(dp(68), dp(82))
            }
            preview.addView(tile)
            preview.addView(tv(this, wallpaper.name, 10f, if (i == prefs.chatWallpaper) C.TEXT else C.SUB, i == prefs.chatWallpaper).apply {
                gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
            })
            wallpaperRow.addView(preview)
        }
        col.addView(card(this).apply {
            addView(tv(this@SettingsActivity, "تصویر زمینه گفتگو", 16f, C.TEXT, true).apply { setPadding(0, 0, 0, dp(4)) })
            addView(tv(this@SettingsActivity, "پس‌زمینه دلخواهت را برای صفحه چت انتخاب کن.", 12f, C.SUB).apply { setPadding(0, 0, 0, dp(8)) })
            addView(HorizontalScrollView(this@SettingsActivity).apply {
                isHorizontalScrollBarEnabled = false
                addView(wallpaperRow)
            })
        })

        val sw = LinearLayout(this)
        Themes.list.forEachIndexed { i, th ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(8), dp(4), dp(8), dp(4))
                setOnClickListener { prefs.theme = i; recreate() }
            }
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(Color.parseColor(th.accent))
                    if (i == prefs.theme) setStroke(dp(3), C.TEXT) else setStroke(dp(2), Color.parseColor(th.line))
                }
                layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
            }
            item.addView(dot); item.addView(tv(this, th.name, 11f, if (i == prefs.theme) C.TEXT else C.SUB).apply { textAlignment = View.TEXT_ALIGNMENT_CENTER })
            sw.addView(item)
        }
        col.addView(card(this).apply {
            addView(tv(this@SettingsActivity, "تم برنامه", 16f, C.TEXT, true).apply { setPadding(0, 0, 0, dp(10)) })
            addView(HorizontalScrollView(this@SettingsActivity).apply { isHorizontalScrollBarEnabled = false; addView(sw) })
        })

        ruleHead = tv(this, "", 13f, C.AMBER, true)
        chips = ChipGroup(this)
        val input = EditText(this).apply { typeface = Fonts.reg; textAlignment = View.TEXT_ALIGNMENT_VIEW_START;
            hint = "مثلاً: وام، شانس، برنده"; setHintTextColor(C.SUB); setTextColor(C.TEXT); textSize = 14f
            isSingleLine = true; background = bg(C.BG, 12, C.LINE); setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { marginEnd = dp(8) }
        }
        val addRow = LinearLayout(this).apply { setPadding(0, dp(12), 0, dp(8)) }
        addRow.addView(input)
        addRow.addView(btn(this, "افزودن") {
            val parts = input.text.toString().split(",", "،", "\n").map { it.trim() }.filter { it.isNotEmpty() }
            prefs.rules = (prefs.rules + parts).distinct(); input.setText(""); render()
        })
        col.addView(card(this).apply {
            addView(ruleHead); addView(addRow); addView(chips)
            addView(btn(this@SettingsActivity, "اسکن صندوق ورودی و انتقال مزاحم‌ها", false) { scan() }
                .apply { layoutParams = LinearLayout.LayoutParams(M, W).apply { topMargin = dp(12) } })
        })

        col.addView(card(this).apply {
            addView(switchRow(this@SettingsActivity, "نمایش مزاحم‌ها در صندوق ورودی",
                "به‌صورت پیش‌فرض مزاحم‌ها از ورودی مخفی هستند", prefs.showSpam) { prefs.showSpam = it })
        })

        purge = tv(this, "", 15f, C.AMBER, true).apply {
            gravity = android.view.Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; background = bg(tint(C.AMBER, 40), 14, C.AMBER)
            setPadding(dp(16), dp(16), dp(16), dp(16)); layoutParams = LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(12) }
            setOnClickListener {
                AlertDialog.Builder(this@SettingsActivity).setTitle("حذف همه پیام‌های مزاحم؟")
                    .setPositiveButton("حذف") { _, _ -> db.clear(); updatePurge() }
                    .setNegativeButton("لغو", null).show()
            }
        }
        col.addView(purge)
        render(); updatePurge()
    }

    private fun chooseNotificationSound() {
        val current = prefs.notificationSound
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "صدای اعلان پیامک")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            if (current.isNotEmpty() && current != "silent") putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(current))
        }
        startActivityForResult(intent, ringtoneRequest)
    }

    @Suppress("DEPRECATION")
    private fun getPickedRingtone(data: Intent?): Uri? = if (Build.VERSION.SDK_INT >= 33)
        data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
    else data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)

    private fun currentSoundLabel(): String {
        val value = prefs.notificationSound
        if (value == "silent") return "صدای فعلی: بی‌صدا"
        val uri = if (value.isEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(value)
        return try { "صدای فعلی: ${RingtoneManager.getRingtone(this, uri)?.getTitle(this) ?: "پیش‌فرض گوشی"}" }
        catch (e: Exception) { "صدای فعلی: پیش‌فرض گوشی" }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ringtoneRequest && resultCode == RESULT_OK) {
            val picked = getPickedRingtone(data)
            prefs.notificationSound = if (picked == null) "silent" else picked.toString()
            soundLabel.text = currentSoundLabel()
        }
        if (requestCode == 2) {
            if (isDefault(this)) { toast(this, "کیان پیام‌رسان پیش‌فرض شد"); finish() }
            else toast(this, "کیان به‌عنوان پیام‌رسان پیش‌فرض انتخاب نشد")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == cameraRequest) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            prefs.flashOnSms = granted
            flashSwitch.isChecked = granted
            if (!granted) toast(this, "برای چشمک چراغ‌قوه باید اجازه دوربین را بدهی")
        }
    }

    fun updatePurge() { purge.text = "حذف همه مزاحم‌ها (${db.count()})" }

    fun render() {
        chips.removeAllViews()
        prefs.rules.forEach { r ->
            chips.addView(Chip(this).apply {
                text = r; typeface = Fonts.reg; isCloseIconVisible = true; setTextColor(C.TEXT)
                chipBackgroundColor = ColorStateList.valueOf(C.BG)
                chipStrokeColor = ColorStateList.valueOf(C.LINE); chipStrokeWidth = dp(1).toFloat()
                closeIconTint = ColorStateList.valueOf(C.SUB)
                setOnCloseIconClickListener { prefs.rules = prefs.rules - r; render() }
            })
        }
        ruleHead.text = "قوانین مزاحم  [ ${prefs.rules.size} فعال ]"
    }

    fun scan() {
        if (!isDefault(this)) { toast(this, "ابتدا برنامه را پیش‌فرض کنید"); return }
        Thread {
            val m = readSms(this, "type=1", null, "date DESC").filter { prefs.isSpam(it.addr, it.body) }
            m.forEach {
                db.add(it.addr, it.body, it.date)
                try { contentResolver.delete(Uri.parse("content://sms/${it.id}"), null, null) } catch (e: Exception) {}
            }
            runOnUiThread { toast(this, "${m.size} پیام منتقل شد"); updatePurge() }
        }.start()
    }
}
