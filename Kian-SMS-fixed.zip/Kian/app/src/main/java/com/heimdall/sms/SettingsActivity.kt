package com.heimdall.sms

import android.app.AlertDialog
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class SettingsActivity : AppCompatActivity() {
    lateinit var prefs: Prefs
    lateinit var db: SpamDb
    lateinit var chips: ChipGroup
    lateinit var ruleHead: TextView
    lateinit var purge: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); themed()
        prefs = Prefs(this); db = SpamDb(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(C.BG); layoutDirection = View.LAYOUT_DIRECTION_RTL; addView(col) })
        col.addView(tv(this, "←  تنظیمات", 22f, C.TEXT, true).apply {
            setPadding(0, dp(8), 0, dp(16)); setOnClickListener { finish() }
        })

        col.addView(card(this).apply {
            addView(switchRow(this@SettingsActivity, "فایروال پیامک", "فیلتر خودکار پیام‌های ورودی با کلمات مزاحم", prefs.enabled) { prefs.enabled = it })
        })

        val sw = LinearLayout(this)
        Themes.list.forEachIndexed { i, th ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(8), dp(4), dp(8), dp(4))
                setOnClickListener { prefs.theme = i; recreate() }
            }
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(Color.parseColor(th.accent))
                    if (i == prefs.theme) setStroke(dp(3), C.TEXT) else setStroke(dp(2), Color.parseColor(th.line))
                }
                layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
            }
            item.addView(dot); item.addView(tv(this, th.name, 11f, if (i == prefs.theme) C.TEXT else C.SUB).apply { textAlignment = View.TEXT_ALIGNMENT_CENTER })
            sw.addView(item)
        }
        col.addView(card(this).apply {
            addView(tv(this@SettingsActivity, "تم برنامه", 16f, C.TEXT, true).apply { setPadding(0, 0, 0, dp(10)) })
            addView(HorizontalScrollView(this@SettingsActivity).apply { isHorizontalScrollBarEnabled = false; addView(sw) })
        })

        ruleHead = tv(this, "", 13f, C.AMBER, true)
        chips = ChipGroup(this)
        val input = EditText(this).apply { typeface = Fonts.reg; textAlignment = View.TEXT_ALIGNMENT_VIEW_START;
            hint = "مثلاً: وام، شانس، برنده"; setHintTextColor(C.SUB); setTextColor(C.TEXT); textSize = 14f
            isSingleLine = true; background = bg(C.BG, 12, C.LINE); setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { marginEnd = dp(8) }
        }
        val addRow = LinearLayout(this).apply { setPadding(0, dp(12), 0, dp(8)) }
        addRow.addView(input)
        addRow.addView(btn(this, "افزودن") {
            val parts = input.text.toString().split(",", "،", "\n").map { it.trim() }.filter { it.isNotEmpty() }
            prefs.rules = (prefs.rules + parts).distinct(); input.setText(""); render()
        })
        col.addView(card(this).apply {
            addView(ruleHead); addView(addRow); addView(chips)
            addView(btn(this@SettingsActivity, "اسکن صندوق ورودی و انتقال مزاحم‌ها", false) { scan() }
                .apply { layoutParams = LinearLayout.LayoutParams(M, W).apply { topMargin = dp(12) } })
        })

        col.addView(card(this).apply {
            addView(switchRow(this@SettingsActivity, "نمایش مزاحم‌ها در صندوق ورودی",
                "به‌صورت پیش‌فرض مزاحم‌ها از ورودی مخفی هستند", prefs.showSpam) { prefs.showSpam = it })
        })

        purge = tv(this, "", 15f, C.AMBER, true).apply {
            gravity = android.view.Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; background = bg(tint(C.AMBER, 40), 14, C.AMBER)
            setPadding(dp(16), dp(16), dp(16), dp(16)); layoutParams = LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(12) }
            setOnClickListener {
                AlertDialog.Builder(this@SettingsActivity).setTitle("حذف همه پیام‌های مزاحم؟")
                    .setPositiveButton("حذف") { _, _ -> db.clear(); updatePurge() }
                    .setNegativeButton("لغو", null).show()
            }
        }
        col.addView(purge)
        col.addView(btn(this, "پیش‌فرض کردن کیان برای پیامک", false) { requestDefault(this) })
        render(); updatePurge()
    }

    fun updatePurge() { purge.text = "حذف همه مزاحم‌ها (${db.count()})" }

    fun render() {
        chips.removeAllViews()
        prefs.rules.forEach { r ->
            chips.addView(Chip(this).apply {
                text = r; typeface = Fonts.reg; isCloseIconVisible = true; setTextColor(C.TEXT)
                chipBackgroundColor = ColorStateList.valueOf(C.BG)
                chipStrokeColor = ColorStateList.valueOf(C.LINE); chipStrokeWidth = dp(1).toFloat()
                closeIconTint = ColorStateList.valueOf(C.SUB)
                setOnCloseIconClickListener { prefs.rules = prefs.rules - r; render() }
            })
        }
        ruleHead.text = "قوانین مزاحم  [ ${prefs.rules.size} فعال ]"
    }

    fun scan() {
        if (!isDefault(this)) { toast(this, "ابتدا برنامه را پیش‌فرض کنید"); return }
        Thread {
            val m = readSms(this, "type=1", null, "date DESC").filter { prefs.isSpam(it.addr, it.body) }
            m.forEach {
                db.add(it.addr, it.body, it.date)
                try { contentResolver.delete(Uri.parse("content://sms/${it.id}"), null, null) } catch (e: Exception) {}
            }
            runOnUiThread { toast(this, "${m.size} پیام منتقل شد"); updatePurge() }
        }.start()
    }
}
