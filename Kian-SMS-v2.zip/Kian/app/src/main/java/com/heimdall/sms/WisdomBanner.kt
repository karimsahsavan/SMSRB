package com.heimdall.sms

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** Rotating collection of 50 distinct short wisdoms from Nahj al-Balagha, Hikmah 1–50. */
class WisdomBanner(c: Context) : LinearLayout(c) {
    private data class Saying(val arabic: String, val meaning: String)
    private val sayings = listOf(
        Saying("كُنْ فِي الْفِتْنَةِ كَابْنِ اللَّبُونِ", "در فتنه چنان باش که نه پشتت برای سواری دادن آماده باشد و نه شیری برای دوشیدن داشته باشی."),
        Saying("مَنِ اسْتَشْعَرَ الطَّمَعَ أَزْرَى بِنَفْسِهِ", "آن‌که طمع را پیشه کند، خود را خوار می‌سازد."),
        Saying("الْبُخْلُ عَارٌ وَالْجُبْنُ مَنْقَصَةٌ", "بخل ننگ است و ترس، کاستی و نقصان."),
        Saying("الصَّبْرُ شَجَاعَةٌ وَالزُّهْدُ ثَرْوَةٌ", "شکیبایی شجاعت است و زهد، ثروت."),
        Saying("الْعِلْمُ وِرَاثَةٌ كَرِيمَةٌ", "دانش میراثی گران‌بهاست."),
        Saying("صَدْرُ الْعَاقِلِ صُنْدُوقُ سِرِّهِ", "سینه خردمند صندوق راز اوست."),
        Saying("الصَّدَقَةُ دَوَاءٌ مُنْجِحٌ", "صدقه دارویی سودمند و اثرگذار است."),
        Saying("اِعْجَبُوا لِهذَا الْإِنْسَانِ", "در آفرینش انسان و شگفتی‌های وجود او بیندیشید."),
        Saying("إِذَا أَقْبَلَتِ الدُّنْيَا أَعَارَتْ مَحَاسِنَ غَيْرِهِمْ", "وقتی دنیا به گروهی روی آورد، خوبی‌های دیگران را به آنان نسبت می‌دهد."),
        Saying("خَالِطُوا النَّاسَ مُخَالَطَةً حَسَنَةً", "با مردم چنان معاشرت کنید که پس از شما از شما به نیکی یاد کنند."),
        Saying("إِذَا قَدَرْتَ عَلَى عَدُوِّكَ فَاجْعَلِ الْعَفْوَ", "هنگام توانایی بر دشمن، گذشت را سپاسِ قدرت خود قرار بده."),
        Saying("أَعْجَزُ النَّاسِ مَنْ عَجَزَ عَنْ اكْتِسَابِ الْإِخْوَانِ", "ناتوان‌ترین مردم کسی است که از یافتن دوستان ناتوان باشد."),
        Saying("لَا تُنَفِّرُوا أَقْصَى النِّعَمِ بِقِلَّةِ الشُّكْرِ", "با کم‌سپاسی، نعمت‌های بزرگ‌تر را از خود دور نکنید."),
        Saying("مَنْ ضَيَّعَهُ الْأَقْرَبُ أُتِيحَ لَهُ الْأَبْعَدُ", "اگر نزدیکان کسی را رها کنند، گاه دورترها به یاری‌اش می‌آیند."),
        Saying("مَا كُلُّ مَفْتُونٍ يُعَاتَبُ", "هر گرفتار و آزموده‌ای سزاوار سرزنش نیست."),
        Saying("تَذِلُّ الْأُمُورُ لِلْمَقَادِيرِ", "کارها در برابر تقدیرها گاه دگرگون و رام می‌شوند."),
        Saying("فَأَمَّا الْآنَ فَامْرُؤٌ وَمَا اخْتَارَ", "اکنون انسان در انتخاب خویش اختیار دارد."),
        Saying("خَذَلُوا الْحَقَّ وَلَمْ يَنْصُرُوا الْبَاطِلَ", "حق را یاری نکردند، اما به باطل نیز نپیوستند."),
        Saying("مَنْ جَرَى فِي عِنَانِ أَمَلِهِ عَثَرَ بِأَجَلِهِ", "آن‌که بی‌مهار در پی آرزوهایش رود، مرگ را از یاد می‌برد."),
        Saying("أَقِيلُوا ذَوِي الْمُرُوءَاتِ عَثَرَاتِهِمْ", "از لغزش‌های انسان‌های بزرگوار درگذرید."),
        Saying("الْفُرْصَةُ تَمُرُّ مَرَّ السَّحَابِ", "فرصت مانند ابر می‌گذرد؛ فرصت‌های نیک را غنیمت بشمارید."),
        Saying("مَنْ أَبْطَأَ بِهِ عَمَلُهُ لَمْ يُسْرِعْ بِهِ نَسَبُهُ", "کسی را که کردارش عقب نگه دارد، نسب و خاندان پیش نمی‌برد."),
        Saying("إِغَاثَةُ الْمَلْهُوفِ مِنْ كَفَّارَاتِ الذُّنُوبِ", "به فریاد ستمدیده رسیدن، از جبران‌کننده‌های گناهان بزرگ است."),
        Saying("إِذَا رَأَيْتَ رَبَّكَ يُتَابِعُ عَلَيْكَ نِعَمَهُ فَاحْذَرْهُ", "اگر نعمت پی‌درپی می‌رسد و نافرمانی می‌کنی، از غفلت بترس."),
        Saying("مَا أَضْمَرَ أَحَدٌ شَيْئًا إِلَّا ظَهَرَ فِي فَلَتَاتِ لِسَانِهِ", "آنچه در دل پنهان شود، گاه در لغزش زبان آشکار می‌شود."),
        Saying("اِمْشِ بِدَائِكَ مَا مَشَى بِكَ", "تا وقتی بیماری با تو مدارا می‌کند، تو نیز با آن مدارا کن."),
        Saying("أَفْضَلُ الزُّهْدِ إِخْفَاءُ الزُّهْدِ", "برترین زهد، پنهان داشتن زهد است."),
        Saying("إِذَا كُنْتَ فِي إِدْبَارٍ وَالْمَوْتُ فِي إِقْبَالٍ", "وقتی عمر رو به پایان است و مرگ نزدیک می‌شود، دیدار چقدر زود فرا می‌رسد."),
        Saying("الْحَذَرَ الْحَذَرَ", "هشیار باشید؛ فریب پرده‌پوشی و مهلت را نخورید."),
        Saying("الْإِيمَانُ عَلَى أَرْبَعِ دَعَائِمَ", "ایمان بر چهار پایه استوار است: شکیبایی، یقین، عدالت و تلاش در راه حق."),
        Saying("فَاعِلُ الْخَيْرِ خَيْرٌ مِنْهُ", "ارزش نیکی‌کننده از خود کار نیک نیز فراتر است."),
        Saying("كُنْ سَمْحًا وَلَا تَكُنْ مُبَذِّرًا", "بخشنده باش، اما اسراف‌کار نباش."),
        Saying("أَشْرَفُ الْغِنَى تَرْكُ الْمُنَى", "ارجمندترین بی‌نیازی، دل نبستن به آرزوهای بی‌پایان است."),
        Saying("مَنْ أَسْرَعَ إِلَى النَّاسِ بِمَا يَكْرَهُونَ", "آن‌که رفتار ناخوشایند پیش گیرد، سخنان نادرست مردم را درباره خود می‌شنود."),
        Saying("مَنْ أَطَالَ الْأَمَلَ أَسَاءَ الْعَمَلَ", "هرکه آرزوهایش را دراز کند، کردار خود را تباه می‌سازد."),
        Saying("أَغْنَى الْغِنَى الْعَقْلُ", "بزرگ‌ترین بی‌نیازی، خرد است."),
        Saying("أَكْبَرَ الْفَقْرِ الْحُمْقُ", "بزرگ‌ترین فقر، نادانی و بی‌خردی است."),
        Saying("أَكْرَمَ الْحَسَبِ حُسْنُ الْخُلُقِ", "گرامی‌ترین افتخار، خوش‌خویی است."),
        Saying("لِسَانُ الْعَاقِلِ وَرَاءَ قَلْبِهِ", "زبان خردمند پشتِ دل اوست؛ نخست می‌اندیشد، سپس سخن می‌گوید."),
        Saying("قَلْبُ الْأَحْمَقِ فِي فِيهِ", "دل نادان در دهان اوست؛ بی‌درنگ سخن می‌گوید."),
        Saying("جَعَلَ اللَّهُ مَرَضَكَ حَطًّا لِسَيِّئَاتِكَ", "خداوند رنج بیماری را سبب پاک شدن گناهانت قرار دهد."),
        Saying("قَنِعَ بِالْكَفَافِ وَرَضِيَ عَنِ اللَّهِ", "به اندازه نیاز قانع باش و از خدا خشنود بمان."),
        Saying("طُوبَى لِمَنْ ذَكَرَ الْمَعَادَ", "خوشا به حال کسی که آخرت را به یاد دارد و برای حساب آماده می‌شود."),
        Saying("سَيِّئَةٌ تَسُوءُكَ خَيْرٌ مِنْ حَسَنَةٍ تُعْجِبُكَ", "بدی‌ای که تو را پشیمان کند، بهتر از خوبی‌ای است که تو را مغرور سازد."),
        Saying("قَدْرُ الرَّجُلِ عَلَى قَدْرِ هِمَّتِهِ", "ارزش انسان به اندازه همت اوست."),
        Saying("الظَّفَرُ بِالْحَزْمِ", "پیروزی با دوراندیشی و استواری به دست می‌آید."),
        Saying("السَّخَاءُ مَا كَانَ ابْتِدَاءً", "بخشش واقعی آن است که بی‌درخواست انجام شود."),
        Saying("لَا غِنَى كَالْعَقْلِ وَلَا فَقْرَ كَالْجَهْلِ", "هیچ ثروتی چون خرد و هیچ فقری چون نادانی نیست."),
        Saying("الصَّبْرُ صَبْرَانِ", "صبر دو گونه است: شکیبایی بر آنچه ناخوشایند است و خویشتن‌داری از آنچه دوست داری."),
        Saying("قُلُوبُ الرِّجَالِ وَحْشِيَّةٌ", "دل‌ها با مهربانی و الفت به سوی انسان جذب می‌شوند.")
    )
    private var index = 0
    private val arabic = TextView(c)
    private val meaning = TextView(c)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#FFF1D6"), Color.parseColor("#FFF9EF"), Color.parseColor("#FCEBFA"))
        ).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.parseColor("#EEDDBD")) }
        val content = LinearLayout(c).apply {
            orientation = VERTICAL; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        val label = TextView(c).apply {
            text = "✦  سخنی از امام علی (ع)  ✦"; textSize = 11f
            setTextColor(Color.parseColor("#A66B13")); typeface = Fonts.bold; gravity = Gravity.CENTER
        }
        arabic.apply {
            textSize = 14f; setTextColor(Color.parseColor("#49351E")); typeface = Fonts.bold
            gravity = Gravity.CENTER; maxLines = 1
        }
        meaning.apply {
            textSize = 11.5f; setTextColor(Color.parseColor("#77634B")); typeface = Fonts.reg
            gravity = Gravity.CENTER; maxLines = 2
        }
        val source = TextView(c).apply {
            text = "نهج‌البلاغه"; textSize = 9f
            setTextColor(Color.parseColor("#A28C70")); gravity = Gravity.CENTER
        }
        content.addView(label)
        content.addView(arabic, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(3) })
        content.addView(meaning, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        content.addView(source, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(1) })
        addView(flower("🌸"), LinearLayout.LayoutParams(dp(34), LinearLayout.LayoutParams.MATCH_PARENT))
        addView(content)
        addView(flower("✿"), LinearLayout.LayoutParams(dp(34), LinearLayout.LayoutParams.MATCH_PARENT))
        advance(true)
    }

    private fun flower(symbol: String): TextView = TextView(context).apply {
        text = symbol; textSize = 22f; gravity = Gravity.CENTER; alpha = 0.6f
    }

    /** Moves to the next saying; called on every app open (and not more often than every 60 s otherwise). */
    fun advance(force: Boolean = false) {
        val p = Prefs(context)
        val now = System.currentTimeMillis()
        if (!force && now - p.wisdomTs < 60_000L) return
        val next = if (p.wisdomIndex < 0) (now % sayings.size).toInt() else (p.wisdomIndex + 1) % sayings.size
        p.wisdomIndex = next; p.wisdomTs = now
        index = next
        showSaying()
    }

    private fun showSaying() {
        arabic.text = sayings[index].arabic
        meaning.text = sayings[index].meaning
        arabic.alpha = 1f; meaning.alpha = 1f
    }
}
