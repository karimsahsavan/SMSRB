package com.heimdall.sms

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Resources
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.LinearGradient
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import androidx.core.view.WindowCompat
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Telephony
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.*

const val M = -1
const val W = -2

class Theme(val name: String, val bg: String, val surf: String, val line: String, val accent: String,
            val text: String, val sub: String, val on: String, val light: Boolean = false)

object Themes {
    // All palettes are light; no dark/black backgrounds remain.
    val list = listOf(
        Theme("کهربایی", "#FFF9EC", "#FFFFFF", "#F1E3C5", "#D99A00", "#29251D", "#887B62", "#FFFFFF", true),
        Theme("اقیانوس", "#EFF8FF", "#FFFFFF", "#D5EAF8", "#1687C9", "#172B3A", "#6D8799", "#FFFFFF", true),
        Theme("زمرد", "#EFFAF4", "#FFFFFF", "#D5EBDD", "#159B68", "#19352A", "#6D8D7D", "#FFFFFF", true),
        Theme("یاقوت", "#FFF1F5", "#FFFFFF", "#F4D9E2", "#D94D79", "#3B202A", "#987481", "#FFFFFF", true),
        Theme("بنفش", "#F6F1FF", "#FFFFFF", "#E5DDF7", "#8056D9", "#2D2440", "#82769F", "#FFFFFF", true),
        Theme("روشن", "#F5F7FC", "#FFFFFF", "#E2E7F0", "#3B6CF6", "#171B25", "#697386", "#FFFFFF", true)
    )
}


// High-quality offline chat wallpapers bundled with the app.
data class ChatWallpaper(val name: String, val resId: Int)
object ChatWallpapers {
    val list = listOf(
        ChatWallpaper("قله مه‌آلود", R.drawable.wallpaper_00),
        ChatWallpaper("کوهستان بنفش", R.drawable.wallpaper_01),
        ChatWallpaper("غروب مخملی", R.drawable.wallpaper_02),
        ChatWallpaper("دره زمرد", R.drawable.wallpaper_03),
        ChatWallpaper("آبی عمیق", R.drawable.wallpaper_04),
        ChatWallpaper("موج‌های آرام", R.drawable.wallpaper_05),
        ChatWallpaper("اقیانوس یخی", R.drawable.wallpaper_06),
        ChatWallpaper("دریای نیلی", R.drawable.wallpaper_07),
        ChatWallpaper("موج مرجانی", R.drawable.wallpaper_08),
        ChatWallpaper("آب‌های فیروزه‌ای", R.drawable.wallpaper_09),
        ChatWallpaper("برگ‌های لطیف", R.drawable.wallpaper_10),
        ChatWallpaper("باغ بهاری", R.drawable.wallpaper_11),
        ChatWallpaper("شاخ‌وبرگ زمرد", R.drawable.wallpaper_12),
        ChatWallpaper("باغ شبانه", R.drawable.wallpaper_13),
        ChatWallpaper("گلبرگ یاسی", R.drawable.wallpaper_14),
        ChatWallpaper("ماه نقره‌ای", R.drawable.wallpaper_15),
        ChatWallpaper("آسمان کهکشانی", R.drawable.wallpaper_16),
        ChatWallpaper("شفق قطبی", R.drawable.wallpaper_17),
        ChatWallpaper("شب بنفش", R.drawable.wallpaper_18),
        ChatWallpaper("ستاره‌های دور", R.drawable.wallpaper_19),
        ChatWallpaper("روبان ابریشمی", R.drawable.wallpaper_20),
        ChatWallpaper("موج طلایی", R.drawable.wallpaper_21),
        ChatWallpaper("خطوط هنری", R.drawable.wallpaper_22),
        ChatWallpaper("قوس‌های مدرن", R.drawable.wallpaper_23),
        ChatWallpaper("طرح مینیمال", R.drawable.wallpaper_24),
        ChatWallpaper("هندسه آبی", R.drawable.wallpaper_25),
        ChatWallpaper("هندسه یاسی", R.drawable.wallpaper_26),
        ChatWallpaper("هندسه زمرد", R.drawable.wallpaper_27),
        ChatWallpaper("هنر انتزاعی", R.drawable.wallpaper_28),
        ChatWallpaper("موج‌های طلایی", R.drawable.wallpaper_29)
    )
}

object C {
    var BG = Color.parseColor("#FFF9EC")
    var SURF = Color.parseColor("#FFFFFF")
    var LINE = Color.parseColor("#F1E3C5")
    var AMBER = Color.parseColor("#F5B81C")
    var TEXT = Color.parseColor("#29251D")
    var SUB = Color.parseColor("#887B62")
    var ON = Color.parseColor("#FFFFFF")
    var LIGHT = true
    val RED = Color.parseColor("#FF5C5C")
    fun use(i: Int) {
        val t = Themes.list[i.coerceIn(0, Themes.list.size - 1)]
        BG = Color.parseColor(t.bg); SURF = Color.parseColor(t.surf); LINE = Color.parseColor(t.line)
        AMBER = Color.parseColor(t.accent); TEXT = Color.parseColor(t.text); SUB = Color.parseColor(t.sub)
        ON = Color.parseColor(t.on); LIGHT = t.light
    }
}

object Fonts {
    var reg: Typeface = Typeface.DEFAULT
    var bold: Typeface = Typeface.DEFAULT_BOLD
    private var done = false
    fun load(c: Context) {
        if (done) return
        done = true
        try { reg = Typeface.createFromAsset(c.assets, "fonts/Vazirmatn-Regular.ttf") } catch (e: Exception) {}
        bold = try { Typeface.createFromAsset(c.assets, "fonts/Vazirmatn-Bold.ttf") } catch (e: Exception) { Typeface.create(reg, Typeface.BOLD) }
    }
}

fun tint(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
fun ltr(a: String) = if (a.isNotEmpty() && (a[0] == '+' || a[0].isDigit() || a[0] in 'A'..'Z' || a[0] in 'a'..'z')) "\u202A$a\u202C" else a
fun Activity.themed() {
    Fonts.load(this)
    C.use(Prefs(this).theme)
    window.setBackgroundDrawable(ColorDrawable(C.BG))
    window.statusBarColor = C.BG; window.navigationBarColor = C.BG
    WindowCompat.getInsetsController(window, window.decorView).apply {
        isAppearanceLightStatusBars = C.LIGHT; isAppearanceLightNavigationBars = C.LIGHT
    }
}

fun dp(v: Int) = (v * Resources.getSystem().displayMetrics.density).toInt()
fun bg(color: Int, r: Int = 16, stroke: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
}
fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
fun tv(c: Context, t: String, size: Float, color: Int, bold: Boolean = false) = TextView(c).apply {
    text = t; textSize = size; setTextColor(color); typeface = if (bold) Fonts.bold else Fonts.reg
    textDirection = View.TEXT_DIRECTION_FIRST_STRONG_RTL
    textAlignment = View.TEXT_ALIGNMENT_VIEW_START
}
fun btn(c: Context, t: String, filled: Boolean = true, cb: () -> Unit) =
    tv(c, t, 14f, if (filled) C.ON else C.AMBER, true).apply {
        gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            if (filled) intArrayOf(tint(C.AMBER, 255), tint(C.AMBER, 205)) else intArrayOf(tint(C.SURF, 250), tint(C.BG, 245))).apply {
            cornerRadius = dp(18).toFloat(); setStroke(dp(1), if (filled) tint(C.ON, 100) else tint(C.AMBER, 110))
        }
        elevation = dp(if (filled) 5 else 2).toFloat()
        setPadding(dp(20), dp(13), dp(20), dp(13)); isAllCaps = false
        setOnClickListener { animate().scaleX(.97f).scaleY(.97f).setDuration(75).withEndAction { animate().scaleX(1f).scaleY(1f).setDuration(110).start(); cb() }.start() }
    }
fun card(c: Context) = LinearLayout(c).apply {
    orientation = LinearLayout.VERTICAL
    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.SURF, tint(C.BG, 245))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), C.LINE) }
    elevation = dp(3).toFloat(); setPadding(dp(16), dp(16), dp(16), dp(16))
    layoutParams = LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(12) }
}
fun switchRow(c: Context, title: String, desc: String, on: Boolean, cb: (Boolean) -> Unit): LinearLayout {
    val r = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
    val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, W, 1f) }
    col.addView(tv(c, title, 16f, C.TEXT, true)); col.addView(tv(c, desc, 12f, C.SUB))
    val s = MaterialSwitch(c).apply {
        isChecked = on; setOnCheckedChangeListener { _, v -> cb(v) }
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        thumbTintList = ColorStateList(st, intArrayOf(C.ON, C.SUB))
        trackTintList = ColorStateList(st, intArrayOf(C.AMBER, C.LINE))
    }
    r.addView(col); r.addView(s); return r
}
fun EditText.onText(cb: (String) -> Unit) = addTextChangedListener(object : TextWatcher {
    override fun afterTextChanged(s: Editable?) { cb(s.toString()) }
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
})
fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

fun norm(s: String) = s.replace('ي', 'ی').replace('ك', 'ک').replace("\u200c", "").lowercase()
fun fmtTime(t: Long): String {
    val n = Calendar.getInstance(); val d = Calendar.getInstance().apply { timeInMillis = t }
    val same = n.get(Calendar.YEAR) == d.get(Calendar.YEAR) && n.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR)
    return SimpleDateFormat(if (same) "HH:mm" else "MM/dd", Locale.getDefault()).format(Date(t))
}

data class Msg(val id: Long, val addr: String, val body: String, val date: Long, val type: Int,
               val thread: Long, val spam: Boolean = false, val unread: Boolean = false, val count: Int = 1)

private const val OTP_KW = "code|otp|pin|passcode|password|verification|one[- ]?time|کد|رمز|پسورد|گذرواژه|یکبار\\s*مصرف|احراز|تایید|تأیید|تاييد"
private val OTP_LABELLED = Regex("(?i)(?:$OTP_KW)[^\\n\\d]{0,40}?[:：=＝]\\s*([A-Za-z0-9]{4,10})(?![A-Za-z0-9])")
private val OTP_AFTER_KW = Regex("(?i)(?:$OTP_KW)[^\\n\\d]{0,40}?(?<![0-9])([0-9]{4,8})(?![0-9])")
private val OTP_BEFORE_KW = Regex("(?i)(?<![0-9])([0-9]{4,8})(?![0-9])[^\\n\\d]{0,30}?(?:$OTP_KW)")
private val OTP_ANY_KW = Regex("(?i)(?:$OTP_KW)")
private val OTP_NUMBER = Regex("(?<![0-9])([0-9]{4,8})(?![0-9])")
private val OTP_BANK = Regex("مبلغ|موجودی|مانده|واریز|برداشت|تراکنش|خرید")
private val OTP_MONEY_AFTER = Regex("^\\s*(?:تومان|ریال|rial|irr|usd|\\$)", RegexOption.IGNORE_CASE)

private fun okOtp(code: String): Boolean {
    if (code.all { it in '0'..'9' }) return code.length in 4..8
    return code.length in 4..10 && (code.any { it in '0'..'9' } || code.all { it in 'A'..'Z' })
}

/**
 * Finds one-time / verification / discount codes in many SMS styles, e.g.
 * "code: 242057", "کد احراز هویت شما: 313192", "کد: UEKPJN", "123456 کد تایید شماست".
 */
fun extractOtpCode(message: String): String? {
    val text = buildString {
        message.forEach { ch ->
            val d = Character.digit(ch, 10)
            append(if (ch !in '0'..'9' && d >= 0) ('0' + d) else ch)
        }
    }
    OTP_LABELLED.findAll(text).forEach { m -> m.groupValues[1].let { if (okOtp(it)) return it } }
    OTP_AFTER_KW.findAll(text).forEach { m -> m.groupValues[1].let { if (okOtp(it)) return it } }
    OTP_BEFORE_KW.findAll(text).forEach { m -> m.groupValues[1].let { if (okOtp(it)) return it } }
    // Fallback: short message with an OTP-like word and exactly one standalone number.
    if (text.length <= 220 && OTP_ANY_KW.containsMatchIn(text) && !OTP_BANK.containsMatchIn(text)) {
        val nums = OTP_NUMBER.findAll(text).filter { m ->
            val before = text.getOrNull(m.range.first - 1)
            val after = text.substring(m.range.last + 1)
            before != '/' && before != ':' && before != '.' && before != '-' &&
                !after.startsWith("/") && !after.startsWith(".") && !OTP_MONEY_AFTER.containsMatchIn(after)
        }.toList()
        if (nums.size == 1) return nums[0].groupValues[1]
    }
    return null
}

/** Digits only, with Persian/Arabic-Indic digits converted to ASCII. */
fun normNum(s: String): String = buildString { s.forEach { val d = Character.digit(it, 10); if (d >= 0) append(d) } }

/** True when two sender addresses are the same number (or the same alphanumeric sender ID). */
fun sameAddr(a: String, b: String): Boolean {
    if (a.any { it.isLetter() } || b.any { it.isLetter() }) return a.trim().equals(b.trim(), true)
    val da = normNum(a); val db = normNum(b)
    if (da.isEmpty() || db.isEmpty()) return false
    return if (minOf(da.length, db.length) < 7) da == db else (da.endsWith(db) || db.endsWith(da))
}

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("p", 0)
    var showSpam: Boolean get() = p.getBoolean("show", false); set(v) { p.edit().putBoolean("show", v).apply() }
    var theme: Int get() = p.getInt("theme", 0); set(v) { p.edit().putInt("theme", v).apply() }
    var chatWallpaper: Int get() = p.getInt("chat_wallpaper", -1).coerceIn(-1, ChatWallpapers.list.size - 1); set(v) { p.edit().putInt("chat_wallpaper", v.coerceIn(-1, ChatWallpapers.list.size - 1)).apply() }
    var showWisdom: Boolean get() = p.getBoolean("wisdom", true); set(v) { p.edit().putBoolean("wisdom", v).apply() }
    var showPopup: Boolean get() = p.getBoolean("popup", true); set(v) { p.edit().putBoolean("popup", v).apply() }
    var wisdomIndex: Int get() = p.getInt("wisdom_idx", -1); set(v) { p.edit().putInt("wisdom_idx", v).apply() }
    var wisdomTs: Long get() = p.getLong("wisdom_ts", 0L); set(v) { p.edit().putLong("wisdom_ts", v).apply() }
    var notifAddr: String get() = p.getString("notif_addr", "") ?: ""; set(v) { p.edit().putString("notif_addr", v).apply() }
    var showNeon: Boolean get() = p.getBoolean("neon", true); set(v) { p.edit().putBoolean("neon", v).apply() }
    var autoCopyOtp: Boolean get() = p.getBoolean("auto_copy_otp", false); set(v) { p.edit().putBoolean("auto_copy_otp", v).apply() }
    var notificationSound: String get() = p.getString("notification_sound", "") ?: ""; set(v) { p.edit().putString("notification_sound", v).apply() }
    var blockedNumbers: Set<String>
        get() = p.getStringSet("blocked_numbers", emptySet())?.toSet() ?: emptySet()
        set(v) { p.edit().putStringSet("blocked_numbers", v.toSet()).apply() }
    var quarantineNumbers: Set<String>
        get() = p.getStringSet("quarantine_numbers", emptySet())?.toSet() ?: emptySet()
        set(v) { p.edit().putStringSet("quarantine_numbers", v.toSet()).apply() }
    fun isQuarantined(addr: String) = quarantineNumbers.any { sameAddr(addr, it) }
    fun isBlocked(addr: String) = blockedNumbers.any { sameAddr(addr, it) }
}

class SpamDb(c: Context) : SQLiteOpenHelper(c, "spam.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE spam(id INTEGER PRIMARY KEY AUTOINCREMENT, addr TEXT, body TEXT, date INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    fun add(a: String, b: String, d: Long): Long {
        return writableDatabase.insert("spam", null, ContentValues().apply { put("addr", a); put("body", b); put("date", d) })
    }
    fun all(): List<Msg> {
        purgeExpired()
        val o = ArrayList<Msg>()
        readableDatabase.rawQuery("SELECT id,addr,body,date FROM spam ORDER BY date DESC", null).use {
            while (it.moveToNext()) o.add(Msg(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "", it.getLong(3), 1, -it.getLong(0), true))
        }
        return o
    }
    fun count(): Int { purgeExpired(); return DatabaseUtils.queryNumEntries(readableDatabase, "spam").toInt() }
    fun purgeExpired() { writableDatabase.delete("spam", "date <= ?", arrayOf((System.currentTimeMillis() - 5L * 60L * 60L * 1000L).toString())) }
    fun delete(id: Long) { writableDatabase.delete("spam", "id=?", arrayOf(id.toString())) }
    fun clear() { writableDatabase.delete("spam", null, null) }
    /** Deletes every quarantined message from [addr]; returns how many were removed. */
    fun deleteByAddr(addr: String): Int {
        var n = 0
        val ids = ArrayList<Long>()
        readableDatabase.rawQuery("SELECT id,addr FROM spam", null).use {
            while (it.moveToNext()) if (sameAddr(addr, it.getString(1) ?: "")) ids.add(it.getLong(0))
        }
        ids.forEach { n += writableDatabase.delete("spam", "id=?", arrayOf(it.toString())) }
        return n
    }
}

fun readSms(c: Context, sel: String?, args: Array<String>?, order: String): List<Msg> {
    val out = ArrayList<Msg>()
    try {
        c.contentResolver.query(Telephony.Sms.CONTENT_URI,
            arrayOf("_id", "address", "body", "date", "type", "thread_id", "read"), sel, args, order)?.use {
            while (it.moveToNext()) out.add(Msg(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "",
                it.getLong(3), it.getInt(4), it.getLong(5), false, it.getInt(6) == 0))
        }
    } catch (e: Exception) {}
    return out
}

object Names {
    private val m = HashMap<String, String>()
    fun get(c: Context, a: String): String = m.getOrPut(a) {
        try {
            val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(a))
            c.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: ltr(a)
        } catch (e: Exception) { ltr(a) }
    }
}

fun isDefault(c: Context): Boolean {
    if (Build.VERSION.SDK_INT >= 29) try {
        if (c.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_SMS)) return true
    } catch (e: Exception) {}
    return Telephony.Sms.getDefaultSmsPackage(c) == c.packageName
}
fun requestDefault(a: Activity) {
    if (isDefault(a)) { toast(a, "کیان هم‌اکنون پیام‌رسان پیش‌فرض است"); return }
    try {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = a.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_SMS))
                a.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 2)
            else toast(a, "امکان انتخاب پیام‌رسان پیش‌فرض در این دستگاه در دسترس نیست")
        } else a.startActivityForResult(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, a.packageName), 2)
    } catch (e: Exception) { toast(a, "باز کردن تنظیمات پیام‌رسان پیش‌فرض ممکن نشد") }
}
fun ensurePerms(a: Activity) {
    val l = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE)
    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
    val miss = l.filter { a.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    if (miss.isNotEmpty()) a.requestPermissions(miss.toTypedArray(), 1)
}
fun restoreToInbox(c: Context, m: Msg): Boolean = try {
    c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
        put(Telephony.Sms.ADDRESS, m.addr); put(Telephony.Sms.BODY, m.body)
        put(Telephony.Sms.DATE, m.date); put(Telephony.Sms.READ, 0)
    }) != null
} catch (e: Exception) { false }

/** "مسدود کلی": block the number, delete all its messages now and drop every future message. */
fun blockEverywhere(c: Context, addr: String): Int {
    val p = Prefs(c)
    if (p.blockedNumbers.none { sameAddr(addr, it) }) p.blockedNumbers = p.blockedNumbers + addr
    p.quarantineNumbers = p.quarantineNumbers.filterNot { sameAddr(addr, it) }.toSet()
    var removed = SpamDb(c).deleteByAddr(addr)
    readSms(c, "type=1", null, "date DESC").filter { sameAddr(addr, it.addr) }.forEach {
        try { if (c.contentResolver.delete(Uri.parse("content://sms/${it.id}"), null, null) > 0) removed++ } catch (_: Exception) {}
    }
    return removed
}
