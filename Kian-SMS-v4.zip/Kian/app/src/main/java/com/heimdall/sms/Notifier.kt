package com.heimdall.sms

import android.animation.ObjectAnimator
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.os.VibrationEffect
import android.os.Vibrator
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Telephony
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.core.app.NotificationCompat

/**
 * One notification slot for incoming SMS:
 *  - a new message replaces the previous one immediately;
 *  - it stays in the status bar until the user touches it (read);
 *  - 30 seconds after it was read it is removed.
 */
object Notifier {
    const val ID = 4100
    const val ACT_READ = "com.heimdall.sms.ACT_READ"
    const val ACT_CANCEL = "com.heimdall.sms.ACT_CANCEL"
    const val ACT_POPUP_OFF = "com.heimdall.sms.ACT_POPUP_OFF"
    const val CANCEL_DELAY = 30_000L
    const val POPUP_MS = 120_000L
    private const val REQ_OPEN = 11
    private const val REQ_READ = 12
    private const val REQ_CANCEL = 13
    private const val REQ_OTP = 14

    private val h = Handler(Looper.getMainLooper())
    private var ring: Ringtone? = null
    private var appCtx: Context? = null
    private val cancelRun = Runnable { appCtx?.let { cancelNow(it) } }

    private fun actionPi(c: Context, action: String, req: Int): PendingIntent =
        PendingIntent.getBroadcast(c, req, Intent(c, NotifActionReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun show(c: Context, addr: String, body: String, date: Long, otp: String?) {
        val app = c.applicationContext; appCtx = app
        Fonts.load(app)
        val prefs = Prefs(app)
        C.use(prefs.theme)
        cancelPending(app)                       // a new SMS replaces the old one right away
        prefs.notifAddr = addr
        val name = Names.get(app, addr)
        val time = fmtTime(date)
        val nm = app.getSystemService(NotificationManager::class.java)

        val pref = prefs.notificationSound
        val soundUri: Uri? = when (pref) {
            "silent" -> null
            "" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            else -> try { Uri.parse(pref) } catch (_: Exception) { RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) }
        }
        if (prefs.showPopup && OverlayPopup.canDraw(app)) {
            // The on-screen card replaces the status-bar notification.
            try { nm.cancel(ID) } catch (_: Exception) {}
            playAlert(app, soundUri)
            OverlayPopup.show(app, addr, name, body, date, otp)
            return
        }
        val channelId = "msg_v2_${(pref.ifEmpty { "default" }).hashCode()}"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "پیامک دریافتی", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "اعلان پیامک‌های جدید کیان"
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                setSound(soundUri, AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            }
            nm.createNotificationChannel(ch)
        }

        val open = PendingIntent.getActivity(app, REQ_OPEN,
            Intent(app, ConversationActivity::class.java).putExtra("addr", addr).putExtra("from_notif", true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val b = NotificationCompat.Builder(app, channelId)
            .setSmallIcon(R.drawable.ic_notif)
            .setLargeIcon(avatarBitmap(name))
            .setColor(C.AMBER)
            .setContentTitle(name)
            .setContentText(body)
            .setSubText("پیام جدید  •  $time")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body).setBigContentTitle(name))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setWhen(date).setShowWhen(true)
            .setOnlyAlertOnce(false)
            .setAutoCancel(false)
            .setOngoing(true)                    // stays until the user touches it
            .setContentIntent(open)
            .addAction(0, "✓ خوانده شد", actionPi(app, ACT_READ, REQ_READ))
        if (Build.VERSION.SDK_INT < 26) b.setSound(soundUri)
        if (!otp.isNullOrBlank()) {
            val copy = PendingIntent.getBroadcast(app, REQ_OTP,
                Intent(app, CopyOtpReceiver::class.java).putExtra("otp_code", otp),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            b.addAction(0, "کپی رمز  $otp", copy)
        }
        try { nm.notify(ID, b.build()) } catch (_: SecurityException) {}

    }

    private fun playAlert(c: Context, uri: Uri?) {
        try {
            val mode = c.getSystemService(AudioManager::class.java).ringerMode
            if (mode == AudioManager.RINGER_MODE_NORMAL && uri != null) {
                ring?.stop()
                ring = RingtoneManager.getRingtone(c, uri)
                ring?.play()
            }
            if (mode != AudioManager.RINGER_MODE_SILENT) {
                val v = c.getSystemService(Vibrator::class.java)
                val pattern = longArrayOf(0, 120, 80, 120)
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1))
                else v.vibrate(pattern, -1)
            }
        } catch (_: Exception) {}
    }

    /** The user touched the notification / opened the chat / pressed "read". */
    fun userRead(c: Context, addr: String, force: Boolean = false) {
        val app = c.applicationContext; appCtx = app
        val p = Prefs(app)
        val cur = p.notifAddr
        if (cur.isEmpty()) return
        if (!force && (addr.isEmpty() || !sameAddr(addr, cur))) return
        try {
            app.contentResolver.update(Telephony.Sms.Inbox.CONTENT_URI,
                ContentValues().apply { put("read", 1); put("seen", 1) },
                "address=? AND read=0", arrayOf(cur))
        } catch (_: Exception) {}
        OverlayPopup.dismiss(true)
        scheduleCancel(app)
    }

    private fun scheduleCancel(c: Context) {
        h.removeCallbacks(cancelRun); h.postDelayed(cancelRun, CANCEL_DELAY)
        try {   // backup in case the process is frozen
            val am = c.getSystemService(AlarmManager::class.java)
            val pi = actionPi(c, ACT_CANCEL, REQ_CANCEL)
            val at = System.currentTimeMillis() + CANCEL_DELAY
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.set(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: Exception) {}
    }

    private fun cancelPending(c: Context) {
        h.removeCallbacks(cancelRun)
        try { c.getSystemService(AlarmManager::class.java).cancel(actionPi(c, ACT_CANCEL, REQ_CANCEL)) } catch (_: Exception) {}
    }

    fun cancelNow(c: Context) {
        val app = c.applicationContext
        cancelPending(app)
        Prefs(app).notifAddr = ""
        try { app.getSystemService(NotificationManager::class.java).cancel(ID) } catch (_: Exception) {}
    }

    private fun avatarBitmap(name: String): Bitmap {
        val s = 128
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = C.AMBER
        cv.drawCircle(s / 2f, s / 2f, s / 2f, p)
        val first = name.trim().firstOrNull { it.isLetter() }?.uppercaseChar()?.toString() ?: "✉"
        p.color = C.ON; p.textSize = 64f; p.textAlign = Paint.Align.CENTER; p.typeface = Fonts.bold
        cv.drawText(first, s / 2f, s / 2f - (p.descent() + p.ascent()) / 2f, p)
        return bmp
    }
}

/** Floating card with the full message; fades out after 2 minutes. */
object OverlayPopup {
    private var view: View? = null
    private var wm: WindowManager? = null
    private var timer: ObjectAnimator? = null
    private val h = Handler(Looper.getMainLooper())
    private val fadeRun = Runnable { dismiss(true) }

    fun canDraw(c: Context) = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)

    fun show(c: Context, addr: String, name: String, body: String, date: Long, otp: String?) {
        if (!canDraw(c)) return
        dismiss(false)
        try {
            val manager = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm = manager
            val root = FrameLayout(c).apply {
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(16), 0, dp(16), 0)
            }
            val card = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                background = bg(C.SURF, 18, tint(C.AMBER, 140))
                elevation = dp(8).toFloat(); setPadding(dp(12), dp(10), dp(12), dp(8))
            }
            val head = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
            head.addView(Avatar(c).apply { set(addr, false); layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)) })
            val col = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8); marginEnd = dp(8) }
            }
            col.addView(tv(c, name, 14f, C.TEXT, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            col.addView(tv(c, fmtTime(date), 10.5f, C.SUB))
            head.addView(col)
            head.addView(tv(c, "✕", 16f, C.SUB, true).apply {
                setPadding(dp(8), dp(2), dp(4), dp(2)); contentDescription = "بستن"
                setOnClickListener { dismiss(true) }
            })
            card.addView(head)
            card.addView(tv(c, body, 13f, C.TEXT).apply {
                maxLines = 5; ellipsize = TextUtils.TruncateAt.END; setLineSpacing(0f, 1.1f)
                setPadding(0, dp(8), 0, dp(8))
            })
            fun small(text: String, filled: Boolean, cb: () -> Unit) = tv(c, text, 12f, if (filled) C.ON else C.AMBER, true).apply {
                gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; maxLines = 1
                background = bg(if (filled) C.AMBER else Color.TRANSPARENT, 12, if (filled) C.AMBER else tint(C.AMBER, 120))
                setPadding(dp(10), dp(7), dp(10), dp(7))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) }
                setOnClickListener { cb() }
            }
            val buttons = LinearLayout(c)
            if (otp != null) buttons.addView(small("کپی  $otp", true) { copyToClipboard(c, otp); toast(c, "کپی شد") })
            buttons.addView(small("باز کردن", otp == null) {
                try {
                    c.startActivity(Intent(c, ConversationActivity::class.java).putExtra("addr", addr)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
                dismiss(true)
            })
            buttons.addView(small("خوانده شد", false) { Notifier.userRead(c, "", true) })
            card.addView(buttons)
            val bar = View(c).apply {
                setBackgroundColor(tint(C.AMBER, 160))
                layoutParams = LinearLayout.LayoutParams(-1, dp(2)).apply { topMargin = dp(8) }
                addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ -> v.pivotX = v.width.toFloat() }
            }
            card.addView(bar)
            root.addView(card, FrameLayout.LayoutParams(-1, -2))

            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(-1, -2, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP; y = dp(24) }
            root.alpha = 0f; root.translationY = -dp(24).toFloat()
            manager.addView(root, lp)
            view = root
            root.animate().alpha(1f).translationY(0f).setDuration(300).start()
            timer = ObjectAnimator.ofFloat(bar, View.SCALE_X, 1f, 0f).apply {
                duration = Notifier.POPUP_MS; interpolator = LinearInterpolator(); start()
            }
            h.removeCallbacks(fadeRun); h.postDelayed(fadeRun, Notifier.POPUP_MS)
            try {   // backup in case the process is frozen
                val am = c.getSystemService(AlarmManager::class.java)
                val pi = PendingIntent.getBroadcast(c, 15,
                    Intent(c, NotifActionReceiver::class.java).setAction(Notifier.ACT_POPUP_OFF),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val at = System.currentTimeMillis() + Notifier.POPUP_MS
                if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.set(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (_: Exception) {}
        } catch (_: Exception) { view = null }
    }

    fun dismiss(animate: Boolean) {
        h.removeCallbacks(fadeRun)
        timer?.cancel(); timer = null
        val v = view ?: return
        view = null
        val remove = { try { wm?.removeView(v) } catch (_: Exception) {} }
        if (animate) v.animate().alpha(0f).translationY(-dp(16).toFloat()).setDuration(700).withEndAction { remove() }.start()
        else remove()
    }
}
