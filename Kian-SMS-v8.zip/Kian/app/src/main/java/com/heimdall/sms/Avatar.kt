package com.heimdall.sms

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import android.animation.ValueAnimator
import android.os.Handler
import android.os.Looper
import android.view.animation.AccelerateDecelerateInterpolator
import java.util.Random

class Avatar(c: Context) : View(c) {
    private var seed = 0
    private var spam = false
    private var robot = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bgs = listOf("#FFD36B", "#7FD1FF", "#8FE3B0", "#FFB38A", "#C9A8FF", "#FF9BB5").map { Color.parseColor(it) }
    private val skins = listOf("#FFDDBF", "#F3C09A", "#D9A074", "#B97C50", "#8D5A36").map { Color.parseColor(it) }
    private val hairs = listOf("#2B2330", "#4A2F22", "#8A5A2B", "#C9A04A", "#7A3B3B", "#3B4A6B").map { Color.parseColor(it) }
    private val shirts = listOf("#F5B81C", "#4C8DFF", "#3DDC97", "#FF5C8A", "#A98BFF", "#FF8A4C").map { Color.parseColor(it) }
    private val dark = Color.parseColor("#2B2330")
    private val handler = Handler(Looper.getMainLooper())
    private var blink = 0f
    private var smile = 0f
    private val blinkTask = object : Runnable {
        override fun run() {
            val anim = ValueAnimator.ofFloat(0f, 1f, 0f).apply {
                duration = 190; interpolator = AccelerateDecelerateInterpolator()
                addUpdateListener { blink = it.animatedValue as Float; invalidate() }
            }
            anim.start()
            if (Random().nextInt(4) == 0) smile = 1f else smile = 0f
            handler.postDelayed(this, 2600L + Random().nextInt(2600))
        }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); handler.removeCallbacks(blinkTask); handler.postDelayed(blinkTask, 900) }
    override fun onDetachedFromWindow() { handler.removeCallbacks(blinkTask); super.onDetachedFromWindow() }

    fun set(addr: String, isSpam: Boolean) {
        seed = addr.hashCode(); spam = isSpam
        robot = addr.any { it in 'A'..'Z' || it in 'a'..'z' }
        invalidate()
    }

    private fun fill(c: Int) { p.style = Paint.Style.FILL; p.color = c }
    private fun stroke(c: Int, w: Float) { p.style = Paint.Style.STROKE; p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND; p.color = c }

    override fun onDraw(cv: Canvas) {
        val s = width / 100f
        cv.save(); cv.scale(s, s)
        val r = Random(seed.toLong() * 31 + 7)
        fill(if (spam) Color.parseColor("#FF8A8A") else bgs[r.nextInt(bgs.size)])
        cv.drawCircle(50f, 50f, 50f, p)
        cv.save()
        cv.clipPath(Path().apply { addCircle(50f, 50f, 50f, Path.Direction.CW) })
        if (robot) drawRobot(cv) else drawPerson(cv, r)
        cv.restore(); cv.restore()
    }

    private fun drawPerson(cv: Canvas, r: Random) {
        val skin = skins[r.nextInt(skins.size)]; val hair = hairs[r.nextInt(hairs.size)]
        val shirt = shirts[r.nextInt(shirts.size)]; val style = r.nextInt(4)
        if (style == 1) { fill(hair); cv.drawRoundRect(RectF(21f, 18f, 79f, 88f), 26f, 26f, p) }
        fill(shirt); cv.drawOval(RectF(16f, 76f, 84f, 130f), p)
        fill(skin); cv.drawRect(43f, 62f, 57f, 82f, p)
        cv.drawCircle(26f, 48f, 4f, p); cv.drawCircle(74f, 48f, 4f, p)
        cv.drawOval(RectF(26f, 22f, 74f, 72f), p)
        when (style) {
            0 -> { fill(hair); cv.drawArc(RectF(24f, 14f, 76f, 56f), 180f, 180f, true, p) }
            1 -> { fill(hair); cv.drawArc(RectF(24f, 14f, 76f, 60f), 180f, 180f, true, p) }
            2 -> { fill(hair); cv.drawCircle(50f, 15f, 9f, p); cv.drawArc(RectF(24f, 16f, 76f, 58f), 180f, 180f, true, p) }
            else -> {
                fill(shirt); cv.drawArc(RectF(24f, 12f, 76f, 54f), 180f, 180f, true, p)
                cv.drawRoundRect(RectF(26f, 34f, 82f, 41f), 3.5f, 3.5f, p)
            }
        }
        val ey = 50f
        if (blink > 0.55f) {
            stroke(dark, 2.6f); cv.drawLine(35f, ey, 45f, ey, p); cv.drawLine(55f, ey, 65f, ey, p)
        } else {
            fill(dark); cv.drawCircle(40f, ey, 3.4f, p); cv.drawCircle(60f, ey, 3.4f, p)
            fill(Color.WHITE); cv.drawCircle(41f, ey - 1.2f, 1.1f, p); cv.drawCircle(61f, ey - 1.2f, 1.1f, p)
        }
        fill(Color.argb(70, 255, 90, 120)); cv.drawCircle(34f, 58f, 4f, p); cv.drawCircle(66f, 58f, 4f, p)
        stroke(dark, 2f)
        if (spam) {
            cv.drawLine(34f, 42f, 45f, 45f, p); cv.drawLine(66f, 42f, 55f, 45f, p)
            cv.drawArc(RectF(42f, 61f, 58f, 71f), 200f, 140f, false, p)
        } else {
            cv.drawLine(35f, 43f, 45f, 42f, p); cv.drawLine(55f, 42f, 65f, 43f, p)
            when (if (smile > 0f) 1 else r.nextInt(3)) {
                0 -> cv.drawArc(RectF(41f, 53f, 59f, 67f), 20f, 140f, false, p)
                1 -> { fill(dark); cv.drawArc(RectF(43f, 57f, 57f, 69f), 0f, 180f, true, p) }
                else -> cv.drawArc(RectF(43f, 56f, 59f, 66f), 10f, 120f, false, p)
            }
        }
        if (r.nextInt(4) == 0) {
            stroke(dark, 1.6f)
            cv.drawCircle(40f, ey, 7.5f, p); cv.drawCircle(60f, ey, 7.5f, p); cv.drawLine(47.5f, ey, 52.5f, ey, p)
        }
    }

    private fun drawRobot(cv: Canvas) {
        val body = Color.parseColor("#E9EDF5"); val glow = if (spam) C.RED else Color.parseColor("#27C8A0")
        fill(body); cv.drawRoundRect(RectF(22f, 78f, 78f, 125f), 14f, 14f, p)
        fill(dark); cv.drawRoundRect(RectF(19f, 46f, 27f, 60f), 3f, 3f, p); cv.drawRoundRect(RectF(73f, 46f, 81f, 60f), 3f, 3f, p)
        stroke(body, 3f); cv.drawLine(50f, 32f, 50f, 22f, p)
        fill(glow); cv.drawCircle(50f, 19f, 4.5f, p)
        fill(body); cv.drawRoundRect(RectF(26f, 32f, 74f, 74f), 12f, 12f, p)
        fill(dark); cv.drawRoundRect(RectF(32f, 40f, 68f, 66f), 8f, 8f, p)
        fill(glow); cv.drawRoundRect(RectF(38f, 47f, 45f, 55f), 2f, 2f, p); cv.drawRoundRect(RectF(55f, 47f, 62f, 55f), 2f, 2f, p)
        stroke(glow, 2f); cv.drawLine(43f, 61f, 57f, 61f, p)
    }
}
