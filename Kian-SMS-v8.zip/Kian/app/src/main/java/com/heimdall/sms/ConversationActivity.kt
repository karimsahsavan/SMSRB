package com.heimdall.sms

import android.content.*
import android.graphics.drawable.GradientDrawable
import android.graphics.Color
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.text.InputType
import android.text.util.Linkify
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Bubbles(val ctx: Context) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var items: List<Msg> = emptyList()
    override fun getItemCount() = items.size
    override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; layoutParams = RecyclerView.LayoutParams(M, W)
            setPadding(dp(12), dp(3), dp(12), dp(3))
        }
        return object : RecyclerView.ViewHolder(col) {}
    }
    override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
        val m = items[i]; val col = h.itemView as LinearLayout; col.removeAllViews()
        val sent = m.type != 1
        val g = if (sent) Gravity.RIGHT else Gravity.LEFT
        val b = tv(ctx, m.body, 15f, if (sent) C.ON else C.TEXT).apply {
            // Sent: theme-coloured gradient bubble; received: clean white bubble with a hairline border. Small "tail" corner on the sender's side.
            background = GradientDrawable(
                if (sent) GradientDrawable.Orientation.TL_BR else GradientDrawable.Orientation.TL_BR,
                if (sent) intArrayOf(shade(C.AMBER, 1.08f), shade(C.AMBER, 0.86f))
                else intArrayOf(C.SURF, C.SURF)
            ).apply {
                val big = dp(22).toFloat(); val small = dp(6).toFloat()
                cornerRadii = if (sent) floatArrayOf(big, big, big, big, small, small, big, big)
                    else floatArrayOf(big, big, big, big, big, big, small, small)
                if (!sent) setStroke(dp(1), C.LINE)
            }
            setLineSpacing(0f, 1.18f)
            elevation = dp(3).toFloat(); setPadding(dp(16), dp(11), dp(16), dp(11)); maxWidth = dp(300)
            autoLinkMask = Linkify.WEB_URLS or Linkify.EMAIL_ADDRESSES
            linksClickable = true
            setLinkTextColor(if (sent) Color.WHITE else C.AMBER)
            movementMethod = android.text.method.LinkMovementMethod.getInstance()
            layoutParams = LinearLayout.LayoutParams(W, W).apply { gravity = g }
            setOnLongClickListener {
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("sms", m.body))
                toast(ctx, "کپی شد"); true
            }
        }
        val t = tv(ctx, fmtJalaliFull(m.date) + (if (m.type == 5) "  ✕ ناموفق" else ""), 11f, C.SUB).apply {
            layoutParams = LinearLayout.LayoutParams(W, W).apply { gravity = g; topMargin = dp(2) }
        }
        col.addView(b)
        val otp = if (!sent) extractOtpCode(m.body) else null
        if (otp != null) {
            val copy = tv(ctx, "کپی رمز  •  $otp", 12f, C.AMBER, true).apply {
                gravity = g; setPadding(dp(10), dp(7), dp(10), dp(7))
                setOnClickListener { copyToClipboard(ctx, otp); toast(ctx, "رمز یکبارمصرف کپی شد") }
                layoutParams = LinearLayout.LayoutParams(W, W).apply { gravity = g; topMargin = dp(3) }
            }
            col.addView(copy)
        }
        col.addView(t)
    }
}

class ConversationActivity : AppCompatActivity() {
    var addr = ""
    var thread = 0L
    lateinit var list: RecyclerView
    lateinit var chatRoot: LinearLayout
    lateinit var bubbles: Bubbles
    lateinit var input: EditText
    lateinit var addrInput: EditText
    lateinit var addrRow: LinearLayout
    lateinit var title: TextView
    lateinit var av: Avatar
    lateinit var simChip: TextView
    lateinit var saveChip: TextView
    var subs: List<Pair<Int, String>> = emptyList()
    var subIdx = 0
    val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { load() }
    }
    val pick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.data?.let { u ->
            contentResolver.query(u, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use {
                if (it.moveToFirst()) addrInput.setText(it.getString(0))
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); themed()
        window.enterTransition = android.transition.Fade().apply { duration = 220 }
        window.exitTransition = android.transition.Fade().apply { duration = 180 }
        addr = intent.getStringExtra("addr")
            ?: intent.data?.schemeSpecificPart?.substringBefore("?")?.let { Uri.decode(it) } ?: ""
        thread = intent.getLongExtra("thread", 0)
        if (addr.isNotEmpty()) Notifier.userRead(this, addr)
        ensurePerms(this)
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED)
                subs = (getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList ?: emptyList())
                    .map { it.subscriptionId to "SIM ${it.simSlotIndex + 1} • ${it.carrierName}" }
        } catch (e: Exception) {}

        chatRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val root = chatRoot
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(16), dp(13))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.SURF, tint(C.BG, 235))).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), C.LINE) }
            elevation = dp(5).toFloat(); layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(10), dp(8), dp(10), dp(8)) }
        }
        head.addView(tv(this, "←", 24f, C.AMBER, true).apply { setPadding(dp(8), 0, dp(14), 0); setOnClickListener { finish() } })
        av = Avatar(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) }
            visibility = if (addr.isEmpty()) View.GONE else View.VISIBLE; set(addr, false)
        }
        head.addView(av)
        title = tv(this, if (addr.isEmpty()) "پیام جدید" else Names.get(this, addr), 18f, C.TEXT, true)
            .apply { layoutParams = LinearLayout.LayoutParams(0, W, 1f) }
        simChip = tv(this, "", 12f, C.AMBER, true).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(tint(C.AMBER, 38), tint(C.AMBER, 18))).apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), tint(C.AMBER, 100)) }
            setPadding(dp(12), dp(8), dp(12), dp(8))
            visibility = if (subs.size > 1) View.VISIBLE else View.GONE
            setOnClickListener { subIdx = (subIdx + 1) % subs.size; updateSim() }
        }
        saveChip = tv(this, "＋ ذخیره", 12f, C.GREEN, true).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(tint(C.GREEN, 38), tint(C.GREEN, 18))).apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), tint(C.GREEN, 110)) }
            setPadding(dp(12), dp(8), dp(12), dp(8)); visibility = View.GONE
            setOnClickListener { askName() }
        }
        head.addView(title); head.addView(saveChip); head.addView(simChip); updateSim()
        root.addView(head)

        addrInput = EditText(this).apply { typeface = Fonts.reg; textAlignment = View.TEXT_ALIGNMENT_VIEW_START;
            hint = "شماره گیرنده"; setHintTextColor(C.SUB); setTextColor(C.TEXT); textSize = 15f
            inputType = InputType.TYPE_CLASS_PHONE
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.SURF, tint(C.BG, 240))).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), C.LINE) }
            setPadding(dp(16), dp(13), dp(16), dp(13)); layoutParams = LinearLayout.LayoutParams(0, W, 1f)
        }
        addrRow = LinearLayout(this).apply { setPadding(dp(12), dp(10), dp(12), dp(4)); gravity = Gravity.CENTER_VERTICAL }
        addrRow.addView(addrInput)
        addrRow.addView(btn(this, "مخاطبین") {
            pick.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
        }.apply { layoutParams = LinearLayout.LayoutParams(W, W).apply { marginStart = dp(8) } })
        addrRow.visibility = if (addr.isEmpty()) View.VISIBLE else View.GONE
        root.addView(addrRow)

        bubbles = Bubbles(this)
        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@ConversationActivity); adapter = bubbles
            clipToPadding = false; setPadding(0, dp(10), 0, dp(14))
            background = null
            layoutParams = LinearLayout.LayoutParams(M, 0, 1f)
        }
        root.addView(list)

        val bar = LinearLayout(this).apply {
            gravity = Gravity.BOTTOM; setPadding(dp(11), dp(11), dp(11), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.SURF, tint(C.BG, 235))).apply { cornerRadii = floatArrayOf(dp(22).toFloat(),dp(22).toFloat(),dp(22).toFloat(),dp(22).toFloat(),0f,0f,0f,0f); setStroke(dp(1), C.LINE) }
            elevation = dp(8).toFloat()
        }
        input = EditText(this).apply { typeface = Fonts.reg; textAlignment = View.TEXT_ALIGNMENT_VIEW_START;
            hint = "پیام…"; setHintTextColor(C.SUB); setTextColor(C.TEXT); textSize = 15f; maxLines = 5
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.SURF, tint(C.BG, 245))).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), tint(C.AMBER, 95)) }
            elevation = dp(2).toFloat(); setPadding(dp(17), dp(13), dp(17), dp(13))
            layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { marginEnd = dp(8) }
            setText(intent.getStringExtra("sms_body") ?: "")
        }
        val send = tv(this, "➤", 20f, C.ON, true).apply {
            gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tint(C.AMBER, 255), tint(C.AMBER, 190))).apply { shape = GradientDrawable.OVAL; setStroke(dp(1), tint(C.ON, 150)) }
            elevation = dp(7).toFloat(); layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)); setOnClickListener { animate().scaleX(.92f).scaleY(.92f).setDuration(70).withEndAction { animate().scaleX(1f).scaleY(1f).setDuration(100).start(); send() }.start() }
        }
        bar.addView(input); bar.addView(send); root.addView(bar)
        setContentView(root)
        applyChatWallpaper()
    }

    private fun applyChatWallpaper() {
        if (!::chatRoot.isInitialized || !::list.isInitialized) return
        val index = Prefs(this).chatWallpaper
        val drawable = if (index >= 0) getDrawable(ChatWallpapers.list[index].resId)
            else android.graphics.drawable.ColorDrawable(C.BG)
        chatRoot.background = drawable
        list.background = null
        chatRoot.invalidate()
        list.invalidate()
    }

    override fun onResume() {
        super.onResume()
        if (::chatRoot.isInitialized) applyChatWallpaper()
        refreshName()
    }

    /** Shows the saved contact name, or a "save" chip when this number is not a contact yet. */
    fun refreshName() {
        if (!::saveChip.isInitialized || addr.isEmpty()) return
        Names.clear()
        Thread {
            val known = Names.saved(this, addr)
            val nm = Names.get(this, addr)
            runOnUiThread { title.text = nm; saveChip.visibility = if (known) View.GONE else View.VISIBLE }
        }.start()
    }

    /** Asks for a name, then opens the system contact editor with the name and number filled in. */
    fun askName() {
        val et = EditText(this).apply {
            typeface = Fonts.reg; hint = "نام مخاطب"; setSingleLine(true); setPadding(dp(20), dp(14), dp(20), dp(14))
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("ذخیره شماره " + addr)
            .setView(et)
            .setPositiveButton("ذخیره") { _, _ ->
                val name = et.text.toString().trim()
                try {
                    startActivity(Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
                        type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
                        putExtra(ContactsContract.Intents.Insert.PHONE, addr)
                        if (name.isNotEmpty()) putExtra(ContactsContract.Intents.Insert.NAME, name)
                    })
                } catch (e: Exception) { toast(this, "برنامهٔ مخاطبین پیدا نشد") }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    fun updateSim() { if (subs.isNotEmpty()) simChip.text = subs[subIdx].second }

    override fun onStart() { super.onStart(); contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs); load() }
    override fun onStop() { super.onStop(); contentResolver.unregisterContentObserver(obs) }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); load()
    }

    fun load() {
        Thread {
            if (thread == 0L && addr.isNotEmpty()) thread = try { Telephony.Threads.getOrCreateThreadId(this, addr) } catch (e: Exception) { 0L }
            val m = if (thread != 0L) readSms(this, "thread_id=?", arrayOf(thread.toString()), "date ASC") else emptyList()
            runOnUiThread {
                bubbles.items = m; bubbles.notifyDataSetChanged()
                if (m.isNotEmpty()) list.scrollToPosition(m.size - 1)
            }
            if (m.any { it.unread } && isDefault(this)) try {
                contentResolver.update(Telephony.Sms.CONTENT_URI, ContentValues().apply { put("read", 1) },
                    "thread_id=? AND read=0", arrayOf(thread.toString()))
            } catch (e: Exception) {}
        }.start()
    }

    fun send() {
        val text = input.text.toString().trim()
        val to = if (addr.isEmpty()) addrInput.text.toString().trim() else addr
        if (text.isEmpty() || to.isEmpty()) { toast(this, "شماره و متن را وارد کنید"); return }
        if (checkSelfPermission(android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ensurePerms(this); return
        }
        try {
            val sid = subs.getOrNull(subIdx)?.first ?: -1
            @Suppress("DEPRECATION")
            val sm = if (sid >= 0) SmsManager.getSmsManagerForSubscriptionId(sid) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null)
            if (isDefault(this)) contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
                put(Telephony.Sms.ADDRESS, to); put(Telephony.Sms.BODY, text)
                put(Telephony.Sms.DATE, System.currentTimeMillis()); put(Telephony.Sms.READ, 1)
            })
            input.setText("")
            if (addr.isEmpty()) { addr = to; thread = 0; addrRow.visibility = View.GONE; title.text = Names.get(this, to); av.set(to, false); av.visibility = View.VISIBLE; refreshName() }
            load()
        } catch (e: Exception) { toast(this, "ارسال ناموفق: ${e.message}") }
    }
}
