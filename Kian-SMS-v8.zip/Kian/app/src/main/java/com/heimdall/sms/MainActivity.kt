package com.heimdall.sms

import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.EditText
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HeaderAdapter(val v: View) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun onCreateViewHolder(p: ViewGroup, t: Int) = object : RecyclerView.ViewHolder(v) {}
    override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {}
    override fun getItemCount() = 1
}

class RowAdapter(val onClick: (Msg) -> Unit, val onLong: (Msg) -> Unit, val onSelection: (Msg, Boolean) -> Unit, val onMenu: (View, Msg) -> Unit) : RecyclerView.Adapter<RowAdapter.VH>() {
    var items: List<Msg> = emptyList()
    var mode = 0
    var selectedIds: Set<Long> = emptySet()
    var selectionMode: Boolean = false
    private fun key(m: Msg) = if (mode == 0 || mode == 1) m.thread else m.id
    class VH(val v: LinearLayout, val av: Avatar, val name: TextView, val body: TextView,
             val time: TextView, val date: TextView, val badge: TextView, val check: CheckBox, val menu: TextView,
             val dot: View) : RecyclerView.ViewHolder(v) {
        var blinkOn = false
        private var anim: android.animation.ObjectAnimator? = null
        fun setBlink(on: Boolean) { blinkOn = on; restart() }
        private var dotAnim: android.animation.ObjectAnimator? = null
        fun restart() {
            anim?.cancel(); anim = null; v.alpha = 1f
            dotAnim?.cancel(); dotAnim = null; dot.scaleX = 1f; dot.scaleY = 1f
            if (blinkOn) {
                anim = android.animation.ObjectAnimator.ofFloat(v, "alpha", 1f, 0.45f).apply {
                    duration = 600; repeatMode = android.animation.ValueAnimator.REVERSE
                    repeatCount = android.animation.ValueAnimator.INFINITE; start()
                }
                dotAnim = android.animation.ObjectAnimator.ofPropertyValuesHolder(dot,
                    android.animation.PropertyValuesHolder.ofFloat("scaleX", 1f, 1.4f),
                    android.animation.PropertyValuesHolder.ofFloat("scaleY", 1f, 1.4f)).apply {
                    duration = 600; repeatMode = android.animation.ValueAnimator.REVERSE
                    repeatCount = android.animation.ValueAnimator.INFINITE; start()
                }
            }
        }
        fun stop() { anim?.cancel(); anim = null; v.alpha = 1f; dotAnim?.cancel(); dotAnim = null; dot.scaleX = 1f; dot.scaleY = 1f }
    }

    override fun onViewAttachedToWindow(h: VH) { super.onViewAttachedToWindow(h); h.restart() }
    override fun onViewDetachedFromWindow(h: VH) { super.onViewDetachedFromWindow(h); h.stop() }

    private fun pill(c: android.content.Context, size: Float, color: Int, bold: Boolean, fill: Int, stroke: Int) =
        tv(c, "", size, color, bold).apply {
            background = bg(fill, 12, stroke); setPadding(dp(10), dp(3), dp(10), dp(3)); gravity = Gravity.CENTER
        }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val c = p.context
        // Flat, tidy row: avatar · (name + time / preview + badge) · menu, with a thin inset divider underneath.
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(M, W).apply { setMargins(dp(10), dp(1), dp(10), dp(1)) }
            foreground = android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(tint(C.AMBER, 50)), null,
                android.graphics.drawable.ColorDrawable(Color.WHITE))
        }
        val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(11), dp(4), dp(11)) }
        val av = Avatar(c).apply { layoutParams = FrameLayout.LayoutParams(dp(52), dp(52)) }
        val dot = View(c).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.GREEN); setStroke(dp(2), C.SURF) }
            layoutParams = FrameLayout.LayoutParams(dp(15), dp(15), Gravity.BOTTOM or Gravity.END)
            visibility = View.GONE
        }
        val avBox = FrameLayout(c).apply { layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)); addView(av); addView(dot) }

        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(12); marginEnd = dp(6) }
        }
        val top = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        val name = tv(c, "", 15.5f, C.TEXT, true).apply {
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { marginEnd = dp(8) }
        }
        val time = tv(c, "", 11.5f, C.SUB)
        top.addView(name); top.addView(time)
        val bottom = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(M, W).apply { topMargin = dp(4) }
        }
        val body = tv(c, "", 13.5f, C.SUB).apply {
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { marginEnd = dp(8) }
        }
        val badge = tv(c, "", 10.5f, C.AMBER, true).apply {
            gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
            background = bg(tint(C.AMBER, 26), 10); setPadding(dp(8), dp(1), dp(8), dp(1))
        }
        bottom.addView(body); bottom.addView(badge)
        col.addView(top); col.addView(bottom)

        val right = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val menu = tv(c, "⋮", 20f, C.SUB, true).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(2), dp(6), dp(2)); contentDescription = "گزینه‌های پیام" }
        val check = CheckBox(c).apply { buttonTintList = ColorStateList.valueOf(C.AMBER) }
        right.addView(menu); right.addView(check)
        row.addView(avBox); row.addView(col); row.addView(right)

        val divider = View(c).apply { setBackgroundColor(tint(C.LINE, 200)) }
        root.addView(row)
        root.addView(divider, LinearLayout.LayoutParams(M, dp(1)).apply { marginStart = dp(76); marginEnd = dp(6) })
        return VH(root, av, name, body, time, TextView(c), badge, check, menu, dot)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val m = items[i]; val n = Names.get(h.v.context, m.addr)
        val unread = m.unread && !m.spam && mode == 0
        h.av.set(m.addr, m.spam)
        h.name.text = n
        h.body.text = (if (m.type == 2 && mode == 0) "شما: " else "") + m.body.replace("\n", " ")
        h.body.setTextColor(if (unread) C.TEXT else C.SUB)
        val full = fmtJalaliPretty(m.date)
        h.time.text = when {
            full.startsWith("امروز") -> fmtClock(m.date)
            full.startsWith("دیروز") -> "دیروز"
            else -> full.substringAfter("•").trim()
        }
        h.time.setTextColor(if (unread) C.GREEN else C.SUB)
        // Unread chats: green outline, green dot on the avatar and a gentle blink until opened.
        h.v.background = if (unread) GradientDrawable().apply {
            setColor(tint(C.GREEN, 20)); cornerRadius = dp(20).toFloat(); setStroke(dp(2), C.GREEN)
        } else null
        h.dot.visibility = if (unread) View.VISIBLE else View.GONE
        h.setBlink(unread && Prefs(h.v.context).blinkNew)
        val sentGroup = mode == 1 && m.count > 1
        h.badge.visibility = if (m.spam || unread || sentGroup) View.VISIBLE else View.GONE
        when {
            m.spam -> {
                h.badge.text = if (m.count > 1) "مزاحم ${faDigits(m.count.toString())}" else "مزاحم"
                h.badge.setTextColor(C.RED); h.badge.background = bg(tint(C.RED, 24), 10)
            }
            unread -> {
                h.badge.text = "جدید"
                h.badge.setTextColor(Color.WHITE); h.badge.background = bg(C.GREEN, 10)
            }
            else -> {
                h.badge.text = faDigits(m.count.toString())
                h.badge.setTextColor(C.SUB); h.badge.background = bg(tint(C.LINE, 120), 10)
            }
        }
        h.check.setOnCheckedChangeListener(null)
        h.check.visibility = if (selectionMode) View.VISIBLE else View.GONE
        h.check.isChecked = key(m) in selectedIds
        h.check.setOnCheckedChangeListener { _, checked -> onSelection(m, checked) }
        h.menu.visibility = if (selectionMode) View.GONE else View.VISIBLE
        h.menu.setOnClickListener { onMenu(it, m) }
        h.v.setOnClickListener { if (selectionMode) onSelection(m, key(m) !in selectedIds) else onClick(m) }
        h.v.setOnLongClickListener { onLong(m); true }
    }
}

open class MainActivity : AppCompatActivity() {
    /** True for the spam screen opened from Settings. */
    open val spamMode: Boolean get() = false
    lateinit var prefs: Prefs
    lateinit var db: SpamDb
    lateinit var ad: RowAdapter
    lateinit var tabs: List<TextView>
    lateinit var banner: TextView
    lateinit var welcome: WelcomeBanner
    var unreadCount = 0
    lateinit var navBoxes: List<LinearLayout>
    lateinit var tabIcons: List<NavIcon>
    lateinit var spamTitle: TextView
    lateinit var empty: TextView
    var tab = 0
    var applied = -1
    var all: List<Msg> = emptyList()
    var query = ""
    val selectedIds = linkedSetOf<Long>()
    lateinit var selectionAction: TextView
    val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { refresh() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); themed()
        window.enterTransition = android.transition.Fade().apply { duration = 220 }
        window.exitTransition = android.transition.Fade().apply { duration = 180 }
        prefs = Prefs(this); db = SpamDb(this); applied = prefs.theme
        ad = RowAdapter({ m ->
            if (m.spam) spamDialog(m) else startActivity(Intent(this, ConversationActivity::class.java)
                .putExtra("addr", m.addr).putExtra("thread", m.thread))
        }, { m -> if (m.spam) spamActions(m) else toggleSelection(m, true) }, { m, checked -> toggleSelection(m, checked) }, { v, m -> messageMenu(v, m) })

        val root = FrameLayout(this).apply {
            setBackgroundColor(C.BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, 0) }
        selectionAction = tv(this, "حذف انتخاب‌شده‌ها", 13f, C.RED, true).apply {
            background = bg(C.BG, 20, tint(C.RED, 120)); elevation = dp(8).toFloat()
            setPadding(dp(18), dp(11), dp(18), dp(11)); visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(W, W, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(104) }
            setOnClickListener { confirmDeleteSelected() }
        }
        banner = tv(this, "برای فعال‌سازی کامل پیامک، اینجا بزنید", 13f, C.ON, true).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(tint(C.AMBER, 250), tint(C.AMBER, 195))).apply { cornerRadius = dp(16).toFloat() }
            elevation = dp(3).toFloat(); setPadding(dp(14), dp(12), dp(14), dp(12)); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(16), dp(4), dp(16), dp(8)) }
            setOnClickListener { requestDefault(this@MainActivity) }
        }
        val search = EditText(this).apply { typeface = Fonts.reg; textAlignment = View.TEXT_ALIGNMENT_VIEW_START;
            hint = "جستجو در پیامک‌ها…"; setHintTextColor(C.SUB); setTextColor(C.TEXT); textSize = 14f
            background = bg(C.SURF, 18, C.LINE)
            setPadding(dp(17), dp(12), dp(17), dp(12)); isSingleLine = true
            layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(14), 0, dp(14), dp(8)) }
            onText { query = it; show() }
        }
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity); adapter = ad
            itemAnimator = androidx.recyclerview.widget.DefaultItemAnimator().apply { addDuration = 220; removeDuration = 280; moveDuration = 220; changeDuration = 180 }
            clipToPadding = false; setPadding(0, 0, 0, dp(if (spamMode) 24 else 150))
            layoutParams = LinearLayout.LayoutParams(M, 0, 1f)
        }
        empty = tv(this, "پیامی وجود ندارد", 15f, C.SUB).apply {
            layoutParams = FrameLayout.LayoutParams(W, W, Gravity.CENTER)
        }
        if (spamMode) {
            tab = 2
            val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(6), dp(14), dp(10)) }
            bar.addView(tv(this, "→", 26f, C.TEXT, true).apply {
                setPadding(dp(8), dp(2), dp(14), dp(2)); contentDescription = "بازگشت"
                setOnClickListener { finish() }
            })
            spamTitle = tv(this, "پیامک‌های مزاحم", 19f, C.TEXT, true)
            bar.addView(spamTitle)
            col.addView(bar); col.addView(search); col.addView(rv)
            root.addView(col, FrameLayout.LayoutParams(M, M)); root.addView(empty); root.addView(selectionAction)
        } else {
            welcome = WelcomeBanner(this).apply { layoutParams = RecyclerView.LayoutParams(M, W).apply { setMargins(dp(14), dp(2), dp(14), dp(6)) } }
            // The animated welcome card lives inside the list as its header: it scrolls away, so messages always get the full screen.
            rv.adapter = androidx.recyclerview.widget.ConcatAdapter(HeaderAdapter(welcome), ad)
            col.addView(banner); col.addView(search); col.addView(rv)

            // Floating bottom navigation bar: inbox / sent / settings.
            val nav = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
                background = bg(C.BG, 30, C.LINE); elevation = dp(14).toFloat()
                layoutParams = FrameLayout.LayoutParams(M, W, Gravity.BOTTOM).apply { setMargins(dp(16), 0, dp(16), dp(14)) }
            }
            val boxes = ArrayList<LinearLayout>(); val icons = ArrayList<NavIcon>(); val labels = ArrayList<TextView>()
            listOf(Triple(0, "ورودی", 0), Triple(1, "ارسالی", 1), Triple(2, "تنظیمات", -1)).forEach { (kind, name, idx) ->
                val ic = NavIcon(this, kind).apply { layoutParams = LinearLayout.LayoutParams(dp(26), dp(26)) }
                val lb = tv(this, name, 11.5f, C.SUB, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER }
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                    setPadding(dp(6), dp(8), dp(6), dp(8))
                    layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
                    setOnClickListener {
                        if (idx < 0) startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                        else { tab = idx; selectedIds.clear(); updateSelectionUi(); refresh() }
                    }
                }
                box.addView(ic); box.addView(lb); nav.addView(box)
                boxes.add(box); icons.add(ic); labels.add(lb)
            }
            navBoxes = boxes; tabIcons = icons; tabs = labels

            // Round compact "new message" button.
            val fab = TextView(this).apply {
                text = "✎"; textSize = 24f; setTextColor(C.ON); gravity = Gravity.CENTER; includeFontPadding = false
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.AMBER, tint(C.AMBER, 200))).apply {
                    shape = GradientDrawable.OVAL; setStroke(dp(2), tint(C.ON, 200))
                }
                elevation = dp(10).toFloat(); contentDescription = "پیام جدید"
                // Perfect circle: the outline (shadow, ripple, touch area) is clipped to an oval, not just the painted background.
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: android.graphics.Outline) { outline.setOval(0, 0, view.width, view.height) }
                }
                clipToOutline = true
                layoutParams = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END).apply { setMargins(dp(20), dp(20), dp(20), dp(104)) }
                setOnClickListener {
                    animate().scaleX(.9f).scaleY(.9f).setDuration(70).withEndAction {
                        animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                        startActivity(Intent(this@MainActivity, ConversationActivity::class.java))
                    }.start()
                }
            }
            root.addView(col, FrameLayout.LayoutParams(M, M)); root.addView(empty); root.addView(nav); root.addView(fab); root.addView(selectionAction)
        }
        setContentView(root)
        if (!spamMode) { ensurePerms(this); askOverlayPermission() }
    }

    private fun askOverlayPermission() {
        if (!prefs.showPopup || OverlayPopup.canDraw(this)) return
        AlertDialog.Builder(this).setTitle("نمایش کارت پیام روی صفحه")
            .setMessage("برای اینکه کارت زیبای پیام روی صفحه نشان داده شود، مجوز «نمایش روی برنامه‌های دیگر» را فعال کن. بدون آن فقط اعلان معمولی می‌آید.")
            .setPositiveButton("فعال‌سازی") { _, _ ->
                try { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            }
            .setNegativeButton("بعداً", null).show()
    }

    override fun onStart() {
        super.onStart(); contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs)
        if (!spamMode) { Reminder.foreground++; Reminder.onAppOpen(this) }
        if (!spamMode && ::welcome.isInitialized) welcome.restart()
    }
    override fun onStop() {
        super.onStop(); contentResolver.unregisterContentObserver(obs)
        if (!spamMode && Reminder.foreground > 0) { Reminder.foreground--; Reminder.schedule(this) }
    }
    override fun onResume() {
        super.onResume()
        SpamDb(this).purgeExpired()
        if (Prefs(this).theme != applied) { recreate(); return }
        checkDefault(); applyDisplayOptions(); refresh()
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); refresh()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (selectedIds.isNotEmpty()) {
            selectedIds.clear(); updateSelectionUi(); refresh()
        } else super.onBackPressed()
    }

    fun applyDisplayOptions() {
        val p = Prefs(this)
        if (!spamMode) welcome.visibility = if (p.showWelcome) View.VISIBLE else View.GONE
    }

    fun checkDefault() { banner.visibility = if (isDefault(this)) View.GONE else View.VISIBLE }
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        Handler(Looper.getMainLooper()).postDelayed({ checkDefault(); refresh() }, 250)
    }

    fun refresh() {
        Thread {
            val list: List<Msg> = when (tab) {
                0 -> {
                    val m = readSms(this, null, null, "date DESC")
                    val unreadT = m.filter { it.unread }.map { it.thread }.toSet()
                    val seen = HashSet<Long>()
                    val l = m.filter { seen.add(it.thread) }.map { it.copy(unread = it.thread in unreadT) }
                    if (prefs.showSpam) (l + db.all()).sortedByDescending { it.date } else l
                }
                1 -> readSms(this, "type=2", null, "date DESC")
                    .groupBy { it.thread }.values.map { g -> g.first().copy(count = g.size) }   // one row per chat
                else -> db.all().groupBy { it.addr }.values.map { g -> g.first().copy(count = g.size) }
            }
            list.map { it.addr }.distinct().forEach { Names.get(this, it) }
            val sc = db.count()
            runOnUiThread {
                if (!spamMode && tab == 0 && ::welcome.isInitialized) {
                    unreadCount = list.count { it.unread && !it.spam }; welcome.setUnread(unreadCount)
                    // the stickman plays with the newest unread message's sender name
                    val latest = list.firstOrNull { it.unread && !it.spam }
                    if (latest != null) welcome.setMessage(Names.get(this, latest.addr), latest.body) else welcome.setMessage(null, null)
                }
                all = list; if (spamMode && ::spamTitle.isInitialized) spamTitle.text = "پیامک‌های مزاحم ($sc)"; show()
            }
        }.start()
    }

    fun show() {
        val q = norm(query)
        val l = if (q.isEmpty()) all else all.filter {
            norm(it.body).contains(q) || norm(Names.get(this, it.addr)).contains(q) || it.addr.contains(q)
        }
        ad.items = l; ad.mode = tab; ad.selectedIds = selectedIds; ad.selectionMode = selectedIds.isNotEmpty(); ad.notifyDataSetChanged()
        empty.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
        if (!spamMode) navBoxes.forEachIndexed { i, box ->
            val on = i == tab
            box.background = if (on) bg(tint(C.AMBER, 30), 22, tint(C.AMBER, 90)) else bg(Color.TRANSPARENT, 22)
            val colr = if (on) C.AMBER else C.SUB
            tabIcons[i].color = colr; tabs[i].setTextColor(colr)
        }
    }


    private fun selectionKey(m: Msg) = if (tab == 0 || tab == 1) m.thread else m.id

    fun toggleSelection(m: Msg, checked: Boolean) {
        val key = selectionKey(m)
        if (checked) selectedIds.add(key) else selectedIds.remove(key)
        ad.selectionMode = selectedIds.isNotEmpty()
        updateSelectionUi()
        ad.selectedIds = selectedIds
        ad.notifyDataSetChanged()
    }

    fun updateSelectionUi() {
        selectionAction.visibility = if (selectedIds.isEmpty()) View.GONE else View.VISIBLE
        selectionAction.text = "حذف ${selectedIds.size} مورد انتخاب‌شده"
        if (::ad.isInitialized) { ad.selectionMode = selectedIds.isNotEmpty(); ad.selectedIds = selectedIds; ad.notifyDataSetChanged() }
    }

    fun confirmDeleteSelected() {
        if (selectedIds.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("حذف چندتایی")
            .setMessage("${selectedIds.size} مورد انتخاب شده است. همه حذف شوند؟")
            .setPositiveButton("حذف همه") { _, _ ->
                val chosen = all.filter { selectionKey(it) in selectedIds }
                try {
                    if (tab == 2) {
                        chosen.forEach { db.deleteByAddr(it.addr) }
                    } else if (tab == 0) {
                        chosen.forEach { m ->
                            if (m.spam) db.deleteByAddr(m.addr)
                            else contentResolver.delete(Uri.parse("content://sms/conversations/${m.thread}"), null, null)
                        }
                    } else {
                        chosen.forEach { m -> contentResolver.delete(Uri.parse("content://sms"), "thread_id=? AND type=2", arrayOf(m.thread.toString())) }
                    }
                    selectedIds.clear(); updateSelectionUi(); refresh()
                } catch (e: Exception) {
                    toast(this, "برای حذف پیامک‌ها، کیان باید برنامه پیامک پیش‌فرض باشد")
                }
            }
            .setNegativeButton("انصراف", null).show()
    }

    private fun messageMenu(anchor: View, m: Msg) {
        val popup = PopupMenu(this, anchor)
        if (m.spam) {
            popup.menu.add(0, 1, 0, "مسدود کلی")
            popup.menu.add(0, 2, 1, "بازگردانی به ورودی")
            popup.menu.add(0, 3, 2, "حذف پیام‌ها")
        } else {
            popup.menu.add(0, 4, 0, "انتقال به مزاحم‌ها")
            popup.menu.add(0, 1, 1, "مسدود کلی")
        }
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> if (m.spam) blockAllNow(m.addr) else confirmBlock(m)
                2 -> restoreGroup(m.addr)
                3 -> { db.deleteByAddr(m.addr); refresh() }
                4 -> confirmQuarantine(m)
            }
            true
        }
        popup.show()
    }

    /** Long-press on a spam message: smart actions for that sender. */
    fun spamActions(m: Msg) {
        val items = arrayOf("🚫  مسدود کلی (حذف همه و رد پیام‌های بعدی)", "↩  بازگردانی به ورودی", "🗑  حذف پیام‌ها", "👁  مشاهده‌ی پیام‌ها")
        AlertDialog.Builder(this).setTitle(Names.get(this, m.addr))
            .setItems(items) { _, w ->
                when (w) {
                    0 -> blockAllNow(m.addr)
                    1 -> restoreGroup(m.addr)
                    2 -> { db.deleteByAddr(m.addr); refresh(); toast(this, "پیام‌ها حذف شدند") }
                    else -> spamDialog(m)
                }
            }.show()
    }

    private fun blockAllNow(addr: String) {
        val n = blockEverywhere(this, addr)
        selectedIds.clear(); updateSelectionUi(); refresh()
        toast(this, if (isDefault(this)) "شماره مسدود شد؛ $n پیام حذف شد" else "شماره مسدود شد؛ برای حذف پیام‌های ورودی، کیان را پیش‌فرض کن")
    }

    private fun restoreGroup(addr: String) {
        val msgs = db.all().filter { it.addr == addr }
        var ok = 0
        msgs.forEach { if (restoreToInbox(this, it)) { db.delete(it.id); ok++ } }
        if (ok > 0) prefs.quarantineNumbers = prefs.quarantineNumbers.filterNot { sameAddr(addr, it) }.toSet()
        if (ok == 0 && msgs.isNotEmpty()) toast(this, "ابتدا برنامه را پیش‌فرض کنید") else toast(this, "$ok پیام به ورودی برگشت")
        refresh()
    }

    private fun confirmQuarantine(m: Msg) {
        AlertDialog.Builder(this)
            .setTitle("قرنطینه شماره؟")
            .setMessage("پیام‌های دریافتی از ${m.addr} به قرنطینه منتقل شوند؟\nپیامک‌های بعدی این شماره نیز خودکار وارد قرنطینه می‌شوند.")
            .setPositiveButton("بله، قرنطینه کن") { _, _ -> quarantineNumber(m.addr) }
            .setNegativeButton("خیر، انصراف", null)
            .show()
    }

    private fun confirmBlock(m: Msg) {
        AlertDialog.Builder(this).setTitle("مسدود کلی؟")
            .setMessage("شماره ${m.addr} مسدود شود؟\nهمه‌ی پیام‌های آن همین حالا حذف می‌شود و پیامک‌های بعدی هم بلافاصله حذف خواهند شد.")
            .setPositiveButton("بله، مسدود کن") { _, _ -> blockAllNow(m.addr) }
            .setNegativeButton("انصراف", null).show()
    }

    private fun quarantineNumber(address: String) {
        prefs.quarantineNumbers = prefs.quarantineNumbers + address
        val incoming = readSms(this, "address=? AND type=1", arrayOf(address), "date DESC")
        var moved = 0
        incoming.forEach { msg ->
            val id = db.add(msg.addr, msg.body, msg.date)
            if (id > 0) {
                moved++
                try { contentResolver.delete(Uri.parse("content://sms/${msg.id}"), null, null) } catch (_: Exception) {}
            }
        }
        toast(this, if (isDefault(this)) "شماره به قرنطینه منتقل شد" else "شماره قرنطینه شد؛ برای حذف پیام‌ها از ورودی، کیان را پیام‌رسان پیش‌فرض کن")
        selectedIds.clear(); updateSelectionUi(); refresh()
    }

    fun spamDialog(m: Msg) {
        val msgs = db.all().filter { it.addr == m.addr }.take(10)
        val text = msgs.joinToString("\n\n— — —\n\n") { "${fmtJalaliFull(it.date)}\n${it.body}" }.ifEmpty { m.body }
        AlertDialog.Builder(this).setTitle(Names.get(this, m.addr)).setMessage(text)
            .setPositiveButton("مسدود کلی") { _, _ -> blockAllNow(m.addr) }
            .setNegativeButton("بازگردانی") { _, _ -> restoreGroup(m.addr) }
            .setNeutralButton("بستن", null).show()
    }

    fun confirmDelete(m: Msg) {
        AlertDialog.Builder(this).setTitle(if (tab == 0) "حذف گفتگو؟" else "حذف پیام‌های ارسالی این گفتگو؟")
            .setPositiveButton("حذف") { _, _ ->
                try {
                    if (tab == 0) contentResolver.delete(Uri.parse("content://sms/conversations/${m.thread}"), null, null)
                    else contentResolver.delete(Uri.parse("content://sms"), "thread_id=? AND type=2", arrayOf(m.thread.toString()))
                } catch (e: Exception) { toast(this, "ابتدا برنامه را پیش‌فرض کنید") }
                refresh()
            }.setNegativeButton("لغو", null).show()
    }
}
