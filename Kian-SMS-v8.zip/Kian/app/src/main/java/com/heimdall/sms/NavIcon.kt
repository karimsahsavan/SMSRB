package com.heimdall.sms

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Crisp outline icons for the bottom bar, drawn in code (0 = inbox, 1 = sent, 2 = settings). */
class NavIcon(c: Context, private val kind: Int) : View(c) {
    var color: Int = C.SUB
        set(v) { field = v; invalidate() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onDraw(cv: Canvas) {
        val s = width / 24f
        cv.save(); cv.scale(s, s)
        stroke.strokeWidth = 1.9f; stroke.color = color
        when (kind) {
            0 -> {
                val tray = Path().apply {
                    moveTo(3f, 13f); lineTo(5.5f, 5f)
                    quadTo(5.8f, 4f, 6.9f, 4f); lineTo(17.1f, 4f)
                    quadTo(18.2f, 4f, 18.5f, 5f); lineTo(21f, 13f)
                    lineTo(21f, 18f); quadTo(21f, 20f, 19f, 20f)
                    lineTo(5f, 20f); quadTo(3f, 20f, 3f, 18f); close()
                }
                cv.drawPath(tray, stroke)
                val inner = Path().apply {
                    moveTo(3f, 13f); lineTo(8.2f, 13f); lineTo(9.4f, 15.5f)
                    lineTo(14.6f, 15.5f); lineTo(15.8f, 13f); lineTo(21f, 13f)
                }
                cv.drawPath(inner, stroke)
            }
            1 -> {
                val plane = Path().apply {
                    moveTo(21f, 3f); lineTo(3f, 10.5f); lineTo(10f, 13.5f); lineTo(13f, 21f); close()
                }
                cv.drawPath(plane, stroke)
                cv.drawLine(21f, 3f, 10f, 13.5f, stroke)
            }
            else -> {
                cv.drawLine(4f, 7f, 20f, 7f, stroke)
                cv.drawLine(4f, 12f, 20f, 12f, stroke)
                cv.drawLine(4f, 17f, 20f, 17f, stroke)
                fill.color = C.BG
                floatArrayOf(15f, 7f, 8f, 12f, 16f, 17f).toList().chunked(2).forEach { (x, y) ->
                    cv.drawCircle(x, y, 2.5f, fill); cv.drawCircle(x, y, 2.5f, stroke)
                }
            }
        }
        cv.restore()
    }
}
