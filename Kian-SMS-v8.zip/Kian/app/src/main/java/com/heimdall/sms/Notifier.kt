package com.heimdall.sms

import android.animation.ObjectAnimator
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.os.VibrationEffect
import android.os.Vibrator
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Telephony
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import android.view.MotionEvent
import android.graphics.drawable.GradientDrawable
import android.widget.LinearLayout
import androidx.core.app.NotificationCompat

/**
 * One notification slot for incoming SMS:
 *  - a new message replaces the previous one immediately;
 *  - it stays in the status bar until the user touches it (read);
 *  - 30 seconds after it was read it is removed.
 */
object Notifier {
    const val ID = 4100
    const val ACT_READ = "com.heimdall.sms.ACT_READ"
    const val ACT_CANCEL = "com.heimdall.sms.ACT_CANCEL"
    const val ACT_POPUP_OFF = "com.heimdall.sms.ACT_POPUP_OFF"
    const val CANCEL_DELAY = 30_000L
    const val POPUP_MS = 120_000L
    private const val REQ_OPEN = 11
    private const val REQ_READ = 12
    private const val REQ_CANCEL = 13
    private const val REQ_OTP = 14

    private val h = Handler(Looper.getMainLooper())
    private var ring: Ringtone? = null
    private var appCtx: Context? = null
    private val cancelRun = Runnable { appCtx?.let { cancelNow(it) } }

    private fun actionPi(c: Context, action: String, req: Int): PendingIntent =
        PendingIntent.getBroadcast(c, req, Intent(c, NotifActionReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun show(c: Context, addr: String, body: String, date: Long, otp: String?) {
        val app = c.applicationContext; appCtx = app
        Fonts.load(app)
        val prefs = Prefs(app)
        C.use(prefs.theme)
        cancelPending(app)                       // a new SMS replaces the old one right away
        prefs.notifAddr = addr
        val name = Names.get(app, addr)
        val time = fmtTime(date)
        val nm = app.getSystemService(NotificationManager::class.java)

        val pref = prefs.notificationSound
        val soundUri: Uri? = when (pref) {
            "silent" -> null
            "" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            else -> try { Uri.parse(pref) } catch (_: Exception) { RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) }
        }
        if (prefs.showPopup && OverlayPopup.canDraw(app)) {
            // The on-screen card replaces the status-bar notification (fallback below if it fails).
            if (OverlayPopup.show(app, addr, name, body, date, otp)) {
                try { nm.cancel(ID) } catch (_: Exception) {}
                playAlert(app, soundUri)
                return
            }
        }
        val channelId = "msg_v2_${(pref.ifEmpty { "default" }).hashCode()}"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "پیامک دریافتی", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "اعلان پیامک‌های جدید کیان"
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                setSound(soundUri, AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            }
            nm.createNotificationChannel(ch)
        }

        val open = PendingIntent.getActivity(app, REQ_OPEN,
            Intent(app, ConversationActivity::class.java).putExtra("addr", addr).putExtra("from_notif", true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val b = NotificationCompat.Builder(app, channelId)
            .setSmallIcon(R.drawable.ic_notif)
            .setLargeIcon(avatarBitmap(name))
            .setColor(C.AMBER)
            .setContentTitle(name)
            .setContentText(body)
            .setSubText("پیام جدید  •  $time")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body).setBigContentTitle(name))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setWhen(date).setShowWhen(true)
            .setOnlyAlertOnce(false)
            .setAutoCancel(false)
            .setOngoing(true)                    // stays until the user touches it
            .setContentIntent(open)
            .addAction(0, "✓ خوانده شد", actionPi(app, ACT_READ, REQ_READ))
        if (Build.VERSION.SDK_INT < 26) b.setSound(soundUri)
        if (!otp.isNullOrBlank()) {
            val copy = PendingIntent.getBroadcast(app, REQ_OTP,
                Intent(app, CopyOtpReceiver::class.java).putExtra("otp_code", otp),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            b.addAction(0, "کپی رمز  $otp", copy)
        }
        try { nm.notify(ID, b.build()) } catch (_: SecurityException) {}

    }

    private fun playAlert(c: Context, uri: Uri?) {
        try {
            val mode = c.getSystemService(AudioManager::class.java).ringerMode
            if (mode == AudioManager.RINGER_MODE_NORMAL && uri != null) {
                ring?.stop()
                ring = RingtoneManager.getRingtone(c, uri)
                ring?.play()
            }
            if (mode != AudioManager.RINGER_MODE_SILENT) {
                val v = c.getSystemService(Vibrator::class.java)
                val pattern = longArrayOf(0, 120, 80, 120)
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1))
                else v.vibrate(pattern, -1)
            }
        } catch (_: Exception) {}
    }

    /** The user touched the notification / opened the chat / pressed "read". */
    fun userRead(c: Context, addr: String, force: Boolean = false) {
        val app = c.applicationContext; appCtx = app
        val p = Prefs(app)
        val cur = p.notifAddr
        if (cur.isEmpty()) return
        if (!force && (addr.isEmpty() || !sameAddr(addr, cur))) return
        try {
            app.contentResolver.update(Telephony.Sms.Inbox.CONTENT_URI,
                ContentValues().apply { put("read", 1); put("seen", 1) },
                "address=? AND read=0", arrayOf(cur))
        } catch (_: Exception) {}
        OverlayPopup.dismiss(true)
        scheduleCancel(app)
    }

    private fun scheduleCancel(c: Context) {
        h.removeCallbacks(cancelRun); h.postDelayed(cancelRun, CANCEL_DELAY)
        try {   // backup in case the process is frozen
            val am = c.getSystemService(AlarmManager::class.java)
            val pi = actionPi(c, ACT_CANCEL, REQ_CANCEL)
            val at = System.currentTimeMillis() + CANCEL_DELAY
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.set(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: Exception) {}
    }

    private fun cancelPending(c: Context) {
        h.removeCallbacks(cancelRun)
        try { c.getSystemService(AlarmManager::class.java).cancel(actionPi(c, ACT_CANCEL, REQ_CANCEL)) } catch (_: Exception) {}
    }

    fun cancelNow(c: Context) {
        val app = c.applicationContext
        cancelPending(app)
        Prefs(app).notifAddr = ""
        try { app.getSystemService(NotificationManager::class.java).cancel(ID) } catch (_: Exception) {}
    }

    private fun avatarBitmap(name: String): Bitmap {
        val s = 128
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = C.AMBER
        cv.drawCircle(s / 2f, s / 2f, s / 2f, p)
        val first = name.trim().firstOrNull { it.isLetter() }?.uppercaseChar()?.toString() ?: "✉"
        p.color = C.ON; p.textSize = 64f; p.textAlign = Paint.Align.CENTER; p.typeface = Fonts.bold
        cv.drawText(first, s / 2f, s / 2f - (p.descent() + p.ascent()) / 2f, p)
        return bmp
    }
}

/** Compact floating circle for a new message: avatar, count badge, name and a countdown ring. Tap opens the chat. */
object OverlayPopup {
    private var view: View? = null
    private var wm: WindowManager? = null
    private var timer: android.animation.ValueAnimator? = null
    private var pulse: android.animation.ValueAnimator? = null
    private var count = 0
    private var lastAddr = ""
    private val h = Handler(Looper.getMainLooper())
    private val fadeRun = Runnable { dismiss(true) }

    fun canDraw(c: Context) = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)

    /** Thin ring that empties while the circle stays on screen. */
    private class Ring(c: Context) : View(c) {
        var sweep = 360f
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat(); strokeCap = Paint.Cap.ROUND }
        override fun onDraw(cv: Canvas) {
            val m = p.strokeWidth / 2
            p.color = tint(C.AMBER, 50); cv.drawOval(m, m, width - m, height - m, p)
            p.color = C.AMBER; cv.drawArc(m, m, width - m, height - m, -90f, sweep, false, p)
        }
    }

    fun show(c: Context, addr: String, name: String, body: String, date: Long, otp: String?): Boolean {
        if (!canDraw(c)) return false
        val n = if (view != null && lastAddr == addr) count + 1 else 1
        dismiss(false)
        count = n; lastAddr = addr
        try {
            val manager = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm = manager
            val boxW = dp(112); val circle = dp(70)
            val root = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }

            val stack = FrameLayout(c)
            val glow = View(c).apply { background = oval(tint(C.AMBER, 70)) }
            stack.addView(glow, FrameLayout.LayoutParams(circle, circle, Gravity.CENTER))
            val disc = FrameLayout(c).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.SURF, tint(C.AMBER, 60))).apply {
                    shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE)
                }
                elevation = dp(10).toFloat()
            }
            disc.addView(Avatar(c).apply { set(addr, false) }, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
            stack.addView(disc, FrameLayout.LayoutParams(circle, circle, Gravity.CENTER))
            val ring = Ring(c)
            stack.addView(ring, FrameLayout.LayoutParams(circle + dp(8), circle + dp(8), Gravity.CENTER))
            stack.addView(tv(c, faDigits(if (n > 9) "9+" else n.toString()), 11f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.RED); setStroke(dp(2), Color.WHITE) }
                minWidth = dp(22); minHeight = dp(22); setPadding(dp(3), 0, dp(3), 0); elevation = dp(12).toFloat()
            }, FrameLayout.LayoutParams(W, W, Gravity.TOP or Gravity.END).apply { topMargin = dp(2); marginEnd = dp(8) })
            root.addView(stack, LinearLayout.LayoutParams(boxW, circle + dp(10)))

            root.addView(tv(c, name, 11.5f, C.TEXT, true).apply {
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; maxWidth = dp(108)
                gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
                background = bg(C.SURF, 12, tint(C.AMBER, 140)); elevation = dp(6).toFloat()
                setPadding(dp(10), dp(3), dp(10), dp(3))
            }, LinearLayout.LayoutParams(W, W).apply { topMargin = dp(2) })
            if (!otp.isNullOrBlank()) {
                root.addView(tv(c, "کد  $otp", 11.5f, C.ON, true).apply {
                    gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
                    background = bg(C.AMBER, 12); elevation = dp(6).toFloat()
                    setPadding(dp(10), dp(3), dp(10), dp(3))
                    setOnClickListener { copyToClipboard(c, otp); toast(c, "رمز یکبارمصرف کپی شد") }
                }, LinearLayout.LayoutParams(W, W).apply { topMargin = dp(4) })
            }

            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(boxW, WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.LEFT
                x = c.resources.displayMetrics.widthPixels - boxW - dp(4); y = dp(70)
            }
            // Drag to move, tap to open the chat.
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            root.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) moved = true
                        if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); try { manager.updateViewLayout(root, lp) } catch (_: Exception) {} }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            try { c.startActivity(Intent(c, ConversationActivity::class.java).putExtra("addr", addr).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                            dismiss(true)
                        }
                        true
                    }
                    else -> false
                }
            }

            root.alpha = 0f; root.scaleX = .3f; root.scaleY = .3f
            manager.addView(root, lp)
            view = root
            root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380)
                .setInterpolator(android.view.animation.OvershootInterpolator(1.6f)).start()
            pulse = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1500; repeatCount = android.animation.ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener { val t = it.animatedValue as Float; glow.scaleX = 1f + t * .45f; glow.scaleY = 1f + t * .45f; glow.alpha = 1f - t }
                start()
            }
            timer = android.animation.ValueAnimator.ofFloat(360f, 0f).apply {
                duration = Notifier.POPUP_MS; interpolator = LinearInterpolator()
                addUpdateListener { ring.sweep = it.animatedValue as Float; ring.invalidate() }
                start()
            }
            h.removeCallbacks(fadeRun); h.postDelayed(fadeRun, Notifier.POPUP_MS)
            try {   // backup in case the process is frozen
                val am = c.getSystemService(AlarmManager::class.java)
                val pi = PendingIntent.getBroadcast(c, 15,
                    Intent(c, NotifActionReceiver::class.java).setAction(Notifier.ACT_POPUP_OFF),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val at = System.currentTimeMillis() + Notifier.POPUP_MS
                if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.set(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (_: Exception) {}
            return true
        } catch (_: Exception) { view = null; return false }
    }

    fun dismiss(animate: Boolean) {
        h.removeCallbacks(fadeRun)
        timer?.cancel(); timer = null
        pulse?.cancel(); pulse = null
        val v = view ?: return
        view = null; count = 0; lastAddr = ""
        val remove = { try { wm?.removeView(v) } catch (_: Exception) {} }
        if (animate) v.animate().alpha(0f).scaleX(.5f).scaleY(.5f).setDuration(450).withEndAction { remove() }.start()
        else remove()
    }
}
