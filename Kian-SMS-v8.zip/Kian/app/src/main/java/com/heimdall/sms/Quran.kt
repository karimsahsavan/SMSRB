package com.heimdall.sms

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class Ayah(val ar: String, val fa: String)

object Quran {
    val names = listOf(
        "فاتحه", "بقره", "آل‌عمران", "نساء", "مائده", "انعام", "اعراف", "انفال", "توبه", "یونس",
        "هود", "یوسف", "رعد", "ابراهیم", "حجر", "نحل", "اسراء", "کهف", "مریم", "طه",
        "انبیاء", "حج", "مؤمنون", "نور", "فرقان", "شعراء", "نمل", "قصص", "عنکبوت", "روم",
        "لقمان", "سجده", "احزاب", "سبأ", "فاطر", "یس", "صافات", "ص", "زمر", "غافر",
        "فصلت", "شوری", "زخرف", "دخان", "جاثیه", "احقاف", "محمد", "فتح", "حجرات", "ق",
        "ذاریات", "طور", "نجم", "قمر", "الرحمن", "واقعه", "حدید", "مجادله", "حشر", "ممتحنه",
        "صف", "جمعه", "منافقون", "تغابن", "طلاق", "تحریم", "ملک", "قلم", "حاقه", "معارج",
        "نوح", "جن", "مزمل", "مدثر", "قیامت", "انسان", "مرسلات", "نبأ", "نازعات", "عبس",
        "تکویر", "انفطار", "مطففین", "انشقاق", "بروج", "طارق", "اعلی", "غاشیه", "فجر", "بلد",
        "شمس", "لیل", "ضحی", "شرح", "تین", "علق", "قدر", "بینه", "زلزله", "عادیات",
        "قارعه", "تکاثر", "عصر", "همزه", "فیل", "قریش", "ماعون", "کوثر", "کافرون", "نصر",
        "مسد", "اخلاص", "فلق", "ناس"
    )
    val counts = intArrayOf(
        7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
        112, 78, 118, 64, 77, 227, 93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
        54, 53, 89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
        14, 11, 11, 18, 12, 12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
        29, 19, 36, 25, 22, 17, 19, 26, 30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
        11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6
    )
    const val BISMILLAH = "بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ"

    /** Short surahs bundled in the app so they work with no internet at all. */
    private val offline: Map<Int, List<Ayah>> = mapOf(
        1 to listOf(
            Ayah("بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ", "به نام خداوند بخشنده مهربان"),
            Ayah("ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَـٰلَمِينَ", "ستایش مخصوص خداوندی است که پروردگار جهانیان است"),
            Ayah("ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ", "آن بخشنده مهربان"),
            Ayah("مَـٰلِكِ يَوْمِ ٱلدِّينِ", "که مالک روز جزاست"),
            Ayah("إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", "تنها تو را می‌پرستیم و تنها از تو یاری می‌جوییم"),
            Ayah("ٱهْدِنَا ٱلصِّرَٰطَ ٱلْمُسْتَقِيمَ", "ما را به راه راست هدایت فرما"),
            Ayah("صِرَٰطَ ٱلَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ ٱلْمَغْضُوبِ عَلَيْهِمْ وَلَا ٱلضَّآلِّينَ", "راه کسانی که به آنان نعمت دادی؛ نه کسانی که بر آنان خشم گرفته شده و نه گمراهان")
        ),
        103 to listOf(
            Ayah("وَٱلْعَصْرِ", "سوگند به عصر"),
            Ayah("إِنَّ ٱلْإِنسَـٰنَ لَفِى خُسْرٍ", "که انسان قطعاً در زیان است"),
            Ayah("إِلَّا ٱلَّذِينَ ءَامَنُوا۟ وَعَمِلُوا۟ ٱلصَّـٰلِحَـٰتِ وَتَوَاصَوْا۟ بِٱلْحَقِّ وَتَوَاصَوْا۟ بِٱلصَّبْرِ", "مگر کسانی که ایمان آوردند و کارهای شایسته کردند و یکدیگر را به حق و به شکیبایی سفارش کردند")
        ),
        108 to listOf(
            Ayah("إِنَّآ أَعْطَيْنَـٰكَ ٱلْكَوْثَرَ", "ما به تو کوثر عطا کردیم"),
            Ayah("فَصَلِّ لِرَبِّكَ وَٱنْحَرْ", "پس برای پروردگارت نماز بگزار و قربانی کن"),
            Ayah("إِنَّ شَانِئَكَ هُوَ ٱلْأَبْتَرُ", "همانا دشمن تو خود بی‌نسل و ناکام است")
        ),
        112 to listOf(
            Ayah("قُلْ هُوَ ٱللَّهُ أَحَدٌ", "بگو: او خداوندی یگانه است"),
            Ayah("ٱللَّهُ ٱلصَّمَدُ", "خداوندی که بی‌نیاز و همه به او نیازمندند"),
            Ayah("لَمْ يَلِدْ وَلَمْ يُولَدْ", "نه فرزندی زاده و نه زاده شده است"),
            Ayah("وَلَمْ يَكُن لَّهُۥ كُفُوًا أَحَدٌۢ", "و هیچ‌کس همتای او نیست")
        ),
        113 to listOf(
            Ayah("قُلْ أَعُوذُ بِرَبِّ ٱلْفَلَقِ", "بگو: پناه می‌برم به پروردگار سپیده‌دم"),
            Ayah("مِن شَرِّ مَا خَلَقَ", "از شر آنچه آفریده است"),
            Ayah("وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ", "و از شر تاریکی شب هنگامی که فراگیرد"),
            Ayah("وَمِن شَرِّ ٱلنَّفَّـٰثَـٰتِ فِى ٱلْعُقَدِ", "و از شر دمندگان در گره‌ها"),
            Ayah("وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", "و از شر حسود هنگامی که حسد ورزد")
        ),
        114 to listOf(
            Ayah("قُلْ أَعُوذُ بِرَبِّ ٱلنَّاسِ", "بگو: پناه می‌برم به پروردگار مردم"),
            Ayah("مَلِكِ ٱلنَّاسِ", "فرمانروای مردم"),
            Ayah("إِلَـٰهِ ٱلنَّاسِ", "معبود مردم"),
            Ayah("مِن شَرِّ ٱلْوَسْوَاسِ ٱلْخَنَّاسِ", "از شر وسوسه‌گر پنهان‌شونده"),
            Ayah("ٱلَّذِى يُوَسْوِسُ فِى صُدُورِ ٱلنَّاسِ", "آن که در سینه‌های مردم وسوسه می‌کند"),
            Ayah("مِنَ ٱلْجِنَّةِ وَٱلنَّاسِ", "از جن و از انسان")
        )
    )

    fun hasOffline(n: Int) = offline.containsKey(n)

    private fun parse(json: String, n: Int): List<Ayah> {
        val data = JSONObject(json).getJSONArray("data")
        val ar = data.getJSONObject(0).getJSONArray("ayahs")
        val fa = if (data.length() > 1) data.getJSONObject(1).getJSONArray("ayahs") else null
        val out = ArrayList<Ayah>()
        for (i in 0 until ar.length()) {
            var t = ar.getJSONObject(i).getString("text").trim()
            // The API glues the Bismillah to the first verse of every surah except Fatiha/Tawba: show it as a header instead.
            if (i == 0 && n != 1 && n != 9 && t.startsWith("بِسْمِ")) {
                val parts = t.split(" ")
                if (parts.size > 4) t = parts.drop(4).joinToString(" ")
            }
            val f = try { fa?.getJSONObject(i)?.getString("text")?.trim() ?: "" } catch (e: Exception) { "" }
            out.add(Ayah(t, f))
        }
        return out
    }

    /** Cache first, then network (cached afterwards), then the bundled short surahs. Runs off the main thread. */
    fun load(ctx: Context, n: Int, done: (List<Ayah>?) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            var res: List<Ayah>? = null
            val f = File(app.filesDir, "quran_$n.json")
            try { if (f.exists()) res = parse(f.readText(), n) } catch (e: Exception) { f.delete() }
            if (res == null) {
                try {
                    val u = URL("https://api.alquran.cloud/v1/surah/$n/editions/quran-uthmani,fa.makarem")
                    val c = u.openConnection() as HttpURLConnection
                    c.connectTimeout = 12000; c.readTimeout = 20000
                    val txt = c.inputStream.bufferedReader().use { it.readText() }
                    res = parse(txt, n)
                    f.writeText(txt)
                } catch (e: Exception) { res = null }
            }
            if (res == null) res = offline[n]
            val r = res
            Handler(Looper.getMainLooper()).post { done(r) }
        }.start()
    }
}

/** List of the 114 surahs with search. */
class QuranActivity : AppCompatActivity() {
    private var shown: List<Int> = (1..114).toList()
    private lateinit var adapter: RecyclerView.Adapter<RecyclerView.ViewHolder>

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); themed()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(6), 0, 0)
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(6), dp(14), dp(8)) }
        bar.addView(tv(this, "→", 26f, C.TEXT, true).apply {
            setPadding(dp(8), dp(2), dp(14), dp(2)); contentDescription = "بازگشت"; setOnClickListener { finish() }
        })
        bar.addView(tv(this, "قرآن کریم", 19f, C.TEXT, true))
        val search = EditText(this).apply {
            typeface = Fonts.reg; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            hint = "جستجوی سوره (نام یا شماره)…"; setHintTextColor(C.SUB); setTextColor(C.TEXT); textSize = 14f
            background = bg(C.SURF, 18, C.LINE); setPadding(dp(17), dp(12), dp(17), dp(12)); isSingleLine = true
            layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(14), 0, dp(14), dp(8)) }
            onText { q ->
                val k = norm(q).trim()
                shown = (1..114).filter { k.isEmpty() || norm(Quran.names[it - 1]).contains(k) || it.toString() == normNum(k) }
                adapter.notifyDataSetChanged()
            }
        }
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@QuranActivity)
            clipToPadding = false; setPadding(0, 0, 0, dp(24))
            layoutParams = LinearLayout.LayoutParams(M, 0, 1f)
        }
        adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = shown.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
                val row = LinearLayout(p.context).apply {
                    gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
                    layoutParams = RecyclerView.LayoutParams(M, W).apply { setMargins(dp(14), dp(5), dp(14), dp(5)) }
                    background = bg(C.SURF, 18, C.LINE)
                }
                return object : RecyclerView.ViewHolder(row) {}
            }
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, i: Int) {
                val n = shown[i]; val row = h.itemView as LinearLayout
                row.removeAllViews()
                row.addView(tv(row.context, faDigits(n.toString()), 13f, C.AMBER, true).apply {
                    gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
                    background = bg(tint(C.AMBER, 28), 14, tint(C.AMBER, 90))
                    minWidth = dp(34); setPadding(dp(6), dp(5), dp(6), dp(5))
                })
                val col = LinearLayout(row.context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(12) }
                }
                col.addView(tv(row.context, "سوره ${Quran.names[n - 1]}", 16f, C.TEXT, true))
                col.addView(tv(row.context, "${faDigits(Quran.counts[n - 1].toString())} آیه", 12f, C.SUB))
                row.addView(col)
                row.setOnClickListener { startActivity(Intent(this@QuranActivity, SurahActivity::class.java).putExtra("n", n)) }
            }
        }
        rv.adapter = adapter
        root.addView(bar); root.addView(search); root.addView(rv)
        setContentView(root)
    }
}

/** Reads one surah: Arabic text, optional Persian translation, font size and audio. */
class SurahActivity : AppCompatActivity() {
    private var player: MediaPlayer? = null
    private var playing = false
    private lateinit var playBtn: TextView
    private lateinit var content: LinearLayout
    private var n = 1
    private var ayahs: List<Ayah> = emptyList()
    private var arSize = 24f
    private var showFa = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); themed()
        n = intent.getIntExtra("n", 1).coerceIn(1, 114)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(6), 0, 0)
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(6), dp(14), dp(8)) }
        bar.addView(tv(this, "→", 26f, C.TEXT, true).apply {
            setPadding(dp(8), dp(2), dp(14), dp(2)); contentDescription = "بازگشت"; setOnClickListener { finish() }
        })
        bar.addView(tv(this, "سوره ${Quran.names[n - 1]}", 19f, C.TEXT, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, W, 1f)
        })
        fun chip(t: String, cb: (TextView) -> Unit) = tv(this, t, 13f, C.AMBER, true).apply {
            gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
            background = bg(tint(C.AMBER, 28), 14, tint(C.AMBER, 100)); setPadding(dp(11), dp(6), dp(11), dp(6))
            layoutParams = LinearLayout.LayoutParams(W, W).apply { marginStart = dp(6) }
            setOnClickListener { cb(this) }
        }
        bar.addView(chip("A−") { arSize = (arSize - 2f).coerceAtLeast(18f); render() })
        bar.addView(chip("A+") { arSize = (arSize + 2f).coerceAtMost(40f); render() })
        bar.addView(chip("ترجمه") { v -> showFa = !showFa; v.alpha = if (showFa) 1f else .45f; render() })

        playBtn = tv(this, "▶  پخش صوتی سوره", 14f, C.ON, true).apply {
            gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
            background = bg(C.AMBER, 18); setPadding(dp(16), dp(11), dp(16), dp(11))
            layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(14), 0, dp(14), dp(8)) }
            setOnClickListener { togglePlay() }
        }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(4), dp(14), dp(40)) }
        val sv = ScrollView(this).apply { layoutParams = LinearLayout.LayoutParams(M, 0, 1f); addView(content) }
        root.addView(bar); root.addView(playBtn); root.addView(sv)
        setContentView(root)

        content.addView(tv(this, "در حال بارگذاری…", 14f, C.SUB).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER })
        Quran.load(this, n) { list ->
            if (isFinishing || isDestroyed) return@load
            if (list == null) {
                content.removeAllViews()
                content.addView(tv(this, if (Quran.hasOffline(n)) "" else "برای دیدن این سوره بار اول به اینترنت نیاز است؛ بعد از آن آفلاین هم کار می‌کند.", 14f, C.SUB).apply {
                    gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; setPadding(0, dp(30), 0, 0)
                })
            } else { ayahs = list; render() }
        }
    }

    private fun render() {
        if (ayahs.isEmpty()) return
        content.removeAllViews()
        if (n != 1 && n != 9) {
            content.addView(tv(this, Quran.BISMILLAH, arSize + 2f, C.AMBER, true).apply {
                gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; setLineSpacing(0f, 1.4f)
                background = bg(tint(C.AMBER, 24), 20, tint(C.AMBER, 90)); setPadding(dp(12), dp(14), dp(12), dp(14))
                layoutParams = LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(10) }
            })
        }
        ayahs.forEachIndexed { i, a ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = bg(C.SURF, 18, C.LINE)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                layoutParams = LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(8) }
            }
            box.addView(tv(this, faDigits("${i + 1}"), 11.5f, C.AMBER, true).apply {
                gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER
                background = bg(tint(C.AMBER, 28), 12, tint(C.AMBER, 90)); setPadding(dp(9), dp(2), dp(9), dp(2))
                layoutParams = LinearLayout.LayoutParams(W, W).apply { bottomMargin = dp(6) }
            })
            box.addView(TextView(this).apply {
                text = a.ar; textSize = arSize; typeface = Fonts.bold; setTextColor(C.TEXT)
                textDirection = View.TEXT_DIRECTION_RTL; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                setLineSpacing(0f, 1.55f)
            })
            if (showFa && a.fa.isNotEmpty()) box.addView(tv(this, a.fa, 13.5f, C.SUB).apply {
                setLineSpacing(0f, 1.25f); setPadding(0, dp(8), 0, 0)
            })
            content.addView(box)
        }
    }

    private fun togglePlay() {
        if (playing) { stopPlay(); return }
        playBtn.text = "…  در حال اتصال"
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            mp.setDataSource("https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/$n.mp3")
            mp.setOnPreparedListener { it.start(); playing = true; playBtn.text = "■  توقف پخش" }
            mp.setOnCompletionListener { stopPlay() }
            mp.setOnErrorListener { _, _, _ ->
                Toast.makeText(this, "پخش صوتی نیاز به اینترنت دارد", Toast.LENGTH_SHORT).show(); stopPlay(); true
            }
            player = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, "پخش صوتی ممکن نشد", Toast.LENGTH_SHORT).show(); stopPlay()
        }
    }

    private fun stopPlay() {
        try { player?.release() } catch (_: Exception) {}
        player = null; playing = false
        playBtn.text = "▶  پخش صوتی سوره"
    }

    override fun onStop() { super.onStop(); if (playing) stopPlay() }
    override fun onDestroy() { try { player?.release() } catch (_: Exception) {}; super.onDestroy() }
}
