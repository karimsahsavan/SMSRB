package com.heimdall.sms

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val addr = parts[0].originatingAddress ?: ""
        val body = parts.joinToString("") { it.messageBody ?: "" }
        val date = System.currentTimeMillis()
        val prefs = Prefs(c)

        // Blocked numbers: dropped immediately, nothing is stored and no notification is shown.
        if (prefs.isBlocked(addr)) return

        // Quarantined numbers go to the spam tab and are removed automatically after 5 hours.
        if (prefs.isQuarantined(addr)) {
            val rowId = SpamDb(c).add(addr, body, date)
            scheduleQuarantineExpiry(c, rowId, date + 5L * 60L * 60L * 1000L)
            return
        }

        restoreToInbox(c, Msg(0, addr, body, date, 1, 0))
        val otp = extractOtpCode(body)
        if (otp != null && prefs.autoCopyOtp) copyToClipboard(c, otp)
        Notifier.show(c, addr, body, date, otp)
        Reminder.schedule(c)                     // first reminder 10 minutes after this message
    }
}

class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }
class RespondService : Service() { override fun onBind(i: Intent?): IBinder? = null }

fun copyToClipboard(c: Context, code: String) {
    val clipboard = c.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("رمز یکبارمصرف", code))
}

class CopyOtpReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val code = i.getStringExtra("otp_code")?.takeIf { it.matches(Regex("[A-Za-z0-9]{4,10}")) } ?: return
        copyToClipboard(c, code)
        OverlayPopup.dismiss(true)
        Notifier.cancelNow(c)
        android.widget.Toast.makeText(c, "رمز یکبارمصرف کپی شد", android.widget.Toast.LENGTH_SHORT).show()
    }
}

/** Handles the notification's "read" button and the timers that remove the notification / popup. */
class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            Notifier.ACT_READ -> Notifier.userRead(c, "", true)
            Notifier.ACT_CANCEL -> Notifier.cancelNow(c)
            Notifier.ACT_POPUP_OFF -> OverlayPopup.dismiss(true)
        }
    }
}

fun scheduleQuarantineExpiry(c: Context, rowId: Long, whenAt: Long) {
    val alarm = c.getSystemService(AlarmManager::class.java)
    val intent = Intent(c, QuarantineExpiryReceiver::class.java).putExtra("row_id", rowId)
    val pi = PendingIntent.getBroadcast(c, rowId.toInt(), intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    try {
        if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt, pi)
        else alarm.set(AlarmManager.RTC_WAKEUP, whenAt, pi)
    } catch (_: Exception) {}
}

class QuarantineExpiryReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        SpamDb(c).purgeExpired()
    }
}
