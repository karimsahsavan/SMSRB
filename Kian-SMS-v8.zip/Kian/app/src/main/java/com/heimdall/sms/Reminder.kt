package com.heimdall.sms

import android.animation.ValueAnimator
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

/** Every 10 minutes, while there are unread messages: short vibration + a small pulsing circle on screen. */
object Reminder {
    const val ACT = "com.heimdall.sms.ACT_REMIND"
    const val EVERY = 10 * 60_000L
    private const val NOTIF_ID = 4101
    @Volatile var foreground = 0

    private fun pi(c: Context): PendingIntent = PendingIntent.getBroadcast(c, 21,
        Intent(c, ReminderReceiver::class.java).setAction(ACT),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** (Re)starts the 10-minute countdown. */
    fun schedule(c: Context) {
        val app = c.applicationContext
        if (!Prefs(app).remindUnread) { cancel(app); return }
        try {
            val am = app.getSystemService(AlarmManager::class.java)
            val at = System.currentTimeMillis() + EVERY
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(app))
            else am.set(AlarmManager.RTC_WAKEUP, at, pi(app))
        } catch (_: Exception) {}
    }

    fun cancel(c: Context) {
        try { c.getSystemService(AlarmManager::class.java).cancel(pi(c)) } catch (_: Exception) {}
        ReminderBubble.dismiss(false)
        try { c.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID) } catch (_: Exception) {}
    }

    fun unreadCount(c: Context): Int = try {
        c.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("_id"), "read=0", null, null)?.use { it.count } ?: 0
    } catch (_: Exception) { 0 }

    /** Called when the app is opened: the user sees the messages, so the reminder goes away. */
    fun onAppOpen(c: Context) {
        ReminderBubble.dismiss(false)
        try { c.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID) } catch (_: Exception) {}
        schedule(c)
    }

    fun fire(c: Context) {
        val app = c.applicationContext
        val prefs = Prefs(app)
        if (!prefs.remindUnread) return
        val n = unreadCount(app)
        if (n <= 0) return                       // nothing unread: the chain stops until the next message / app start
        if (foreground == 0) {
            vibrate(app)
            var shown = false
            if (OverlayPopup.canDraw(app)) { Fonts.load(app); C.use(prefs.theme); shown = ReminderBubble.show(app, n) }
            if (!shown) notify(app, n)
        }
        schedule(app)
    }

    private fun vibrate(c: Context) {
        try {
            val mode = c.getSystemService(AudioManager::class.java).ringerMode
            if (mode == AudioManager.RINGER_MODE_SILENT) return
            val v = c.getSystemService(Vibrator::class.java)
            val pattern = longArrayOf(0, 90, 70, 90, 70, 180)
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1)) else v.vibrate(pattern, -1)
        } catch (_: Exception) {}
    }

    private fun notify(c: Context, n: Int) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
                NotificationChannel("remind_v1", "یادآوری پیام‌های خوانده‌نشده", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    enableVibration(false); setSound(null, null)
                })
            val open = PendingIntent.getActivity(c, 22, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(NOTIF_ID, NotificationCompat.Builder(c, "remind_v1")
                .setSmallIcon(R.drawable.ic_notif).setColor(C.AMBER)
                .setContentTitle("پیام خوانده‌نشده")
                .setContentText("${faDigits(n.toString())} پیام جدید منتظر خواندن شماست")
                .setAutoCancel(true).setContentIntent(open).setOnlyAlertOnce(true).build())
        } catch (_: Exception) {}
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Reminder.ACT) Reminder.fire(c)
    }
}

/** Restarts the reminder after reboot / app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Reminder.schedule(c) }
}

/** Small draggable circle with a pulsing ring and the unread count. Tap it to open the app. */
object ReminderBubble {
    private var view: View? = null
    private var wm: WindowManager? = null
    private var pulse: ValueAnimator? = null
    private val h = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { dismiss(true) }
    private const val SHOW_MS = 30_000L

    fun show(c: Context, count: Int): Boolean {
        dismiss(false)
        try {
            val manager = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm = manager
            val size = dp(62); val box = dp(96)
            val root = FrameLayout(c)

            val ring = View(c).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(3), C.AMBER) }
            }
            root.addView(ring, FrameLayout.LayoutParams(size, size, Gravity.CENTER))

            val circle = FrameLayout(c).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tint(C.AMBER, 255), tint(C.AMBER, 190))).apply {
                    shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE)
                }
                elevation = dp(8).toFloat()
            }
            circle.addView(TextView(c).apply {
                text = "✉"; textSize = 26f; setTextColor(C.ON); gravity = Gravity.CENTER; includeFontPadding = false
            }, FrameLayout.LayoutParams(-1, -1))
            root.addView(circle, FrameLayout.LayoutParams(size, size, Gravity.CENTER))

            root.addView(TextView(c).apply {
                text = if (count > 99) "۹۹+" else faDigits(count.toString())
                textSize = 11f; typeface = Fonts.bold; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.RED); setStroke(dp(2), Color.WHITE) }
                minWidth = dp(22); minHeight = dp(22); setPadding(dp(3), 0, dp(3), 0)
                elevation = dp(10).toFloat()
            }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT).apply { topMargin = dp(10); rightMargin = dp(10) })

            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(box, box, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.LEFT
                x = c.resources.displayMetrics.widthPixels - box - dp(6); y = dp(140)
            }

            // Drag to move, tap to open.
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            root.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) moved = true
                        if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); try { manager.updateViewLayout(root, lp) } catch (_: Exception) {} }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            try { c.startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                            dismiss(true)
                        }
                        true
                    }
                    else -> false
                }
            }

            root.alpha = 0f; root.scaleX = .4f; root.scaleY = .4f
            manager.addView(root, lp)
            view = root
            root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320).withEndAction {
                // a little wiggle to catch the eye
                circle.animate().rotation(14f).setDuration(80).withEndAction {
                    circle.animate().rotation(-14f).setDuration(120).withEndAction {
                        circle.animate().rotation(0f).setDuration(80).start()
                    }.start()
                }.start()
            }.start()
            pulse = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener {
                    val t = it.animatedValue as Float
                    ring.scaleX = 1f + t * .55f; ring.scaleY = 1f + t * .55f; ring.alpha = .7f * (1f - t)
                }
                start()
            }
            h.removeCallbacks(hideRun); h.postDelayed(hideRun, SHOW_MS)
            return true
        } catch (_: Exception) { view = null; return false }
    }

    fun dismiss(animate: Boolean) {
        h.removeCallbacks(hideRun)
        pulse?.cancel(); pulse = null
        val v = view ?: return
        view = null
        val remove = { try { wm?.removeView(v) } catch (_: Exception) {} }
        if (animate) v.animate().alpha(0f).scaleX(.5f).scaleY(.5f).setDuration(350).withEndAction { remove() }.start() else remove()
    }
}
