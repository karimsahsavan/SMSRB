package com.heimdall.sms

/** Spam / quarantine list, opened from Settings. */
class SpamActivity : MainActivity() {
    override val spamMode: Boolean get() = true
}
