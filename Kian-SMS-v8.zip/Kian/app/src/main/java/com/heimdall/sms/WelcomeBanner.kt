package com.heimdall.sms

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.View
import android.view.animation.BounceInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import java.util.Calendar
import java.util.Random

/**
 * Playful banner at the top of the messenger. The latest message's sender (or a greeting) is rendered as big text,
 * which is cut into its real pieces (letter groups and dots). A tiny stickman walks in and plays with them:
 * he lifts a piece and throws it away, tosses it up and catches it, or kicks the dot off a letter like «خ».
 * Every piece flies back home afterwards, so the word is always whole again.
 */
class WelcomeBanner(c: Context) : View(c) {
    private class Sprite(val bmp: Bitmap, val hx: Float, val hy: Float, val dot: Boolean) {
        var x = hx; var y = hy; var rot = 0f; var sc = 1f
        val w: Int get() = bmp.width
        val h: Int get() = bmp.height
        fun reset() { x = hx; y = hy; rot = 0f; sc = 1f }
    }

    private class Step(val dur: Long, val begin: (() -> Unit)?, val run: (Float) -> Unit)

    private val u = dp(1).toFloat()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val rnd = Random()
    private val bounce = BounceInterpolator()
    private val over = OvershootInterpolator(2.2f)

    private val sprites = ArrayList<Sprite>()
    private val queue = ArrayList<Step>()
    private var cur: Step? = null
    private var stepT0 = 0L

    // stickman state
    private var mx = -40f
    private var gy = 0f
    private var facing = 1f
    private var walkPh = 0f
    private var walking = false
    private var armsUp = 0f
    private var kick = 0f
    private var wave = 0f
    private var pendingEntrance = true

    private var unread = 0
    private var msgSender: String? = null
    private var msgBody: String? = null

    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    init {
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(tint(C.AMBER, 55), C.SURF, tint(C.GREEN, 28))).apply {
            cornerRadius = dp(24).toFloat(); setStroke(dp(1), tint(C.AMBER, 130))
        }
        elevation = dp(4).toFloat()
        textPaint.typeface = Fonts.bold
        chipPaint.typeface = Fonts.bold
        setOnClickListener { poke() }
    }

    // ───────────── public API ─────────────

    /** Shows this sender's name (or Persian words from the body) as the playground text; null → a greeting. */
    fun setMessage(sender: String?, body: String?) {
        if (sender == msgSender && body == msgBody) return
        msgSender = sender; msgBody = body
        rebuild()
    }

    fun setUnread(n: Int) { unread = n; invalidate() }

    /** Called each time the app comes to the front: the stickman walks in again. */
    fun restart() { pendingEntrance = true }

    // ───────────── view plumbing ─────────────

    override fun onMeasure(ws: Int, hs: Int) { setMeasuredDimension(MeasureSpec.getSize(ws), (140f * u).toInt()) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        gy = h - 8f * u
        rebuild()
        pendingEntrance = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); pendingEntrance = true
        if (!loop.isStarted) loop.start()
    }

    override fun onDetachedFromWindow() { loop.cancel(); super.onDetachedFromWindow() }

    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        if (v == VISIBLE) { if (isAttachedToWindow && !loop.isStarted) loop.start() } else loop.cancel()
    }

    // ───────────── text → sprites ─────────────

    private fun greeting(): String {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hr in 5..10 -> "صبح بخیر"
            hr in 11..15 -> "روز بخیر"
            hr in 16..18 -> "عصر بخیر"
            else -> "شب بخیر"
        }
    }

    private fun persianWords(s: String?): List<String> {
        if (s == null) return emptyList()
        return s.split(Regex("\\s+"))
            .map { w -> w.filter { ch -> (ch in '\u0600'..'\u06FF' && ch.isLetter()) || ch == '\u200c' } }
            .filter { it.length >= 2 }
    }

    private fun pickWords(): List<String> {
        var w = persianWords(msgSender)
        if (w.isEmpty()) w = persianWords(msgBody)
        if (w.isEmpty()) w = listOf("سلام") + greeting().split(" ")
        return w.take(3)
    }

    private fun rebuild() {
        for (s in sprites) s.bmp.recycle()
        sprites.clear(); queue.clear(); cur = null
        val w = width
        if (w <= 0) return
        var use = pickWords()
        textPaint.color = C.TEXT
        var size = 34f * u
        textPaint.textSize = size
        val avail = w - 28f * u
        while (textPaint.measureText(use.joinToString(" ")) > avail && size > 22f * u) { size -= 2f * u; textPaint.textSize = size }
        while (use.size > 1 && textPaint.measureText(use.joinToString(" ")) > avail) use = use.dropLast(1)
        val t = use.joinToString(" ")
        val fm = textPaint.fontMetrics
        val pad = (4f * u).toInt()
        val bw = Math.ceil(textPaint.measureText(t).toDouble()).toInt() + 2 * pad
        val bh = Math.ceil((fm.descent - fm.ascent).toDouble()).toInt() + 2 * pad
        if (bw <= 0 || bh <= 0) return
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawText(t, pad.toFloat(), pad - fm.ascent, textPaint)
        extract(bmp, (w - bw) / 2f, 24f * u, size)
        bmp.recycle()
    }

    /** Splits the rendered text into connected pieces: letter groups (bodies) and tiny dots. */
    private fun extract(bmp: Bitmap, left: Float, top: Float, ts: Float) {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        val lab = IntArray(w * h)
        val stack = IntArray(w * h)
        var n = 0
        for (i0 in px.indices) {
            if ((px[i0] ushr 24) < 60 || lab[i0] != 0) continue
            n++
            var sp = 0; stack[sp++] = i0; lab[i0] = n
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w; val y = i / w
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val j = ny * w + nx
                    if (lab[j] == 0 && (px[j] ushr 24) >= 60) { lab[j] = n; stack[sp++] = j }
                }
            }
        }
        if (n == 0) return
        // faint anti-aliased edge pixels join the neighbouring piece so the text keeps its smooth look
        val lab2 = lab.copyOf()
        for (i in px.indices) {
            if (lab[i] != 0 || (px[i] ushr 24) == 0) continue
            val x = i % w; val y = i / w
            var found = 0
            search@ for (dy in -1..1) {
                for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val l = lab[ny * w + nx]
                    if (l != 0) { found = l; break@search }
                }
            }
            lab2[i] = found
        }
        val x0 = IntArray(n + 1) { w }; val y0 = IntArray(n + 1) { h }
        val x1 = IntArray(n + 1) { -1 }; val y1 = IntArray(n + 1) { -1 }
        val area = IntArray(n + 1)
        for (i in px.indices) {
            val l = lab2[i]; if (l == 0) continue
            val x = i % w; val y = i / w
            area[l]++
            if (x < x0[l]) x0[l] = x
            if (x > x1[l]) x1[l] = x
            if (y < y0[l]) y0[l] = y
            if (y > y1[l]) y1[l] = y
        }
        val dotArea = 0.04f * ts * ts
        val isDot = BooleanArray(n + 1)
        val ops = arrayOfNulls<IntArray>(n + 1)
        for (l in 1..n) {
            if (area[l] < 4) continue
            val bw = x1[l] - x0[l] + 1; val bh = y1[l] - y0[l] + 1
            isDot[l] = area[l] < dotArea && bw < 0.3f * ts && bh < 0.3f * ts
            ops[l] = IntArray(bw * bh)
        }
        for (i in px.indices) {
            val l = lab2[i]; if (l == 0) continue
            val o = ops[l] ?: continue
            val bw = x1[l] - x0[l] + 1
            val x = i % w - x0[l]; val y = i / w - y0[l]
            var col = px[i]
            if (isDot[l]) col = (col and 0xFF000000.toInt()) or (C.AMBER and 0x00FFFFFF)
            o[y * bw + x] = col
        }
        for (l in 1..n) {
            val o = ops[l] ?: continue
            val bw = x1[l] - x0[l] + 1; val bh = y1[l] - y0[l] + 1
            val out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            out.setPixels(o, 0, bw, 0, 0, bw, bh)
            sprites.add(Sprite(out, left + x0[l] + bw / 2f, top + y0[l] + bh / 2f, isDot[l]))
        }
    }

    // ───────────── animation engine ─────────────

    private fun ease(p: Float) = p * p * (3f - 2f * p)
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun arcY(y0: Float, y1: Float, p: Float, h: Float) = lerp(y0, y1, p) - 4f * h * p * (1f - p)
    private fun holdY(s: Sprite) = gy - 49f * u - s.h * s.sc / 2f
    private fun st(dur: Long, begin: (() -> Unit)? = null, run: (Float) -> Unit) = Step(dur, begin, run)

    private fun tick() {
        val now = SystemClock.uptimeMillis()
        walking = false
        if (width <= 0) return
        if (pendingEntrance) { pendingEntrance = false; entrance() }
        var c = cur
        if (c == null) {
            if (queue.isEmpty()) planNext()
            if (queue.isEmpty()) return
            c = queue.removeAt(0); cur = c; stepT0 = now
            c.begin?.invoke()
        }
        val p = ((now - stepT0).toFloat() / c.dur.toFloat()).coerceIn(0f, 1f)
        c.run(p)
        if (p >= 1f) cur = null
    }

    private fun entrance() {
        queue.clear(); cur = null
        sprites.forEach { it.reset() }
        armsUp = 0f; kick = 0f; wave = 0f; facing = 1f
        mx = -24f * u
        queue.add(walk(mx, width * 0.3f, null))
        queue.add(st(1100L) { p -> facing = 1f; wave = if (p < 0.9f) 1f else 0f })
        queue.add(st(1L) { _ -> wave = 0f })
    }

    private fun poke() {
        queue.clear(); cur = null
        sprites.forEach { it.reset() }
        armsUp = 0f; kick = 0f; wave = 0f
        planNext()
    }

    private fun planNext() {
        val bodies = sprites.filter { !it.dot }.sortedBy { it.w }
        val dots = sprites.filter { it.dot }
        if (sprites.isEmpty()) { queue.add(st(1000L) { _ -> }); return }
        val r = rnd.nextInt(100)
        val small = if (bodies.isEmpty()) emptyList() else bodies.take(maxOf(1, (bodies.size + 1) / 2))
        when {
            dots.isNotEmpty() && (r < 45 || small.isEmpty()) -> planKick(dots[rnd.nextInt(dots.size)])
            small.isNotEmpty() && r < 78 -> planThrow(small[rnd.nextInt(small.size)])
            small.isNotEmpty() -> planToss(small[rnd.nextInt(small.size)])
        }
        queue.add(st(900L) { _ -> armsUp = 0f; kick = 0f })
    }

    private fun walk(from: Float, to: Float, carry: Sprite?): Step {
        val dist = Math.abs(to - from)
        val dur = (dist / (110f * u) * 1000f).toLong().coerceAtLeast(150L)
        var x0 = from
        return st(dur, { x0 = mx }) { p ->
            val nx = lerp(x0, to, ease(p))
            if (Math.abs(to - x0) > 1f) facing = if (to > x0) 1f else -1f
            walkPh += Math.abs(nx - mx) / (6f * u)
            walking = Math.abs(nx - mx) > 0.01f
            mx = nx
            if (carry != null) { carry.x = mx; carry.y = holdY(carry); carry.rot = Math.sin(walkPh.toDouble()).toFloat() * 3f }
        }
    }

    /** Walk under the piece, reach up and lift it above the head. Returns the man's x. */
    private fun grab(sp: Sprite): Float {
        val tx = sp.hx.coerceIn(22f * u, width - 22f * u)
        queue.add(walk(mx, tx, null))
        queue.add(st(300L) { p -> armsUp = ease(p) })
        var sx = 0f; var sy = 0f
        queue.add(st(450L, { sx = sp.x; sy = sp.y }) { p ->
            val e = ease(p)
            sp.x = lerp(sx, mx, e); sp.y = lerp(sy, holdY(sp), e); sp.rot = lerp(0f, -6f, e)
        })
        return tx
    }

    private fun planThrow(sp: Sprite) {
        val pos = grab(sp)
        val far = if (pos < width / 2f) width - 30f * u else 30f * u
        val d = if (far > pos) 1f else -1f
        queue.add(walk(pos, far, sp))
        queue.add(st(240L) { p -> facing = d; sp.x = mx; sp.y = holdY(sp); sp.rot = lerp(0f, -22f * d, ease(p)) })
        val offX = if (d > 0) width + 60f * u else -60f * u
        var sx = 0f; var sy = 0f
        queue.add(st(650L, { sx = sp.x; sy = sp.y }) { p ->
            armsUp = 1f - ease(minOf(1f, p * 3f))
            sp.x = lerp(sx, offX, p); sp.y = arcY(sy, -30f * u, p, 40f * u)
            sp.rot = -22f * d + d * 720f * p; sp.sc = lerp(1f, 0.6f, p)
        })
        queue.add(st(700L) { _ -> armsUp = 0f })
        queue.add(st(1000L) { p ->
            val e = over.getInterpolation(p)
            sp.x = lerp(offX, sp.hx, e); sp.y = arcY(-30f * u, sp.hy, e, 36f * u)
            sp.rot = (1f - p) * -540f * d; sp.sc = lerp(0.6f, 1f, p)
        })
        queue.add(st(1L) { _ -> sp.reset() })
    }

    private fun planToss(sp: Sprite) {
        grab(sp)
        for (i in 0 until 2) {
            val spin = if (i == 0) 1f else -1f
            queue.add(st(850L) { p ->
                armsUp = if (p < 0.25f) 1f else if (p > 0.8f) 0.3f + 0.7f * ((p - 0.8f) / 0.2f) else 0.3f
                sp.x = mx; sp.y = holdY(sp) - 4f * 50f * u * p * (1f - p); sp.rot = p * 360f * spin
            })
        }
        var sx = 0f; var sy = 0f
        queue.add(st(550L, { sx = sp.x; sy = sp.y; sp.rot = 0f }) { p ->
            val e = ease(p)
            armsUp = 1f - e
            sp.x = lerp(sx, sp.hx, e); sp.y = arcY(sy, sp.hy, e, 24f * u)
        })
        queue.add(st(1L) { _ -> sp.reset(); armsUp = 0f })
    }

    private fun planKick(dot: Sprite) {
        val dir = if (dot.hx < width / 2f) 1f else -1f
        val groundY = gy - dot.h / 2f - 1f * u
        var y0 = 0f
        // the dot drops off its letter and bounces on the floor
        queue.add(st(700L, { y0 = dot.y }) { p ->
            dot.y = lerp(y0, groundY, bounce.getInterpolation(p))
            dot.rot = 25f * Math.sin(p * 18.0).toFloat() * (1f - p)
        })
        val stand = (dot.hx - dir * 17f * u).coerceIn(16f * u, width - 16f * u)
        queue.add(walk(mx, stand, null))
        queue.add(st(280L) { p -> facing = dir; kick = -0.7f * ease(p) })
        var fx = 0f; var fy = 0f
        val wallX = if (dir > 0) width - 12f * u else 12f * u
        queue.add(st(1000L, { fx = dot.x; fy = dot.y; dot.rot = 0f }) { p ->
            kick = if (p < 0.12f) lerp(-0.7f, 1f, p / 0.12f) else lerp(1f, 0f, minOf(1f, (p - 0.12f) * 4f))
            val f = maxOf(0f, (p - 0.12f) / 0.88f)
            if (f < 0.55f) {
                val t = f / 0.55f
                dot.x = lerp(fx, wallX, t); dot.y = arcY(fy, gy - 36f * u, t, 44f * u); dot.rot = dir * 600f * t
            } else {
                val t = (f - 0.55f) / 0.45f
                dot.x = lerp(wallX, wallX - dir * 46f * u, t); dot.y = arcY(gy - 36f * u, groundY, t, 20f * u)
                dot.rot = dir * (600f + 300f * t)
            }
        })
        queue.add(st(600L) { _ -> kick = 0f })
        var cx0 = 0f; var cy0 = 0f; var r0 = 0f
        // the dot flies home, the stickman cheers
        queue.add(st(1000L, { cx0 = dot.x; cy0 = dot.y; r0 = dot.rot % 360f }) { p ->
            val e = ease(p)
            dot.x = lerp(cx0, dot.hx, e); dot.y = arcY(cy0, dot.hy, e, 70f * u); dot.rot = lerp(r0, 0f, e)
            armsUp = if (p < 0.5f) ease(p * 2f) else 1f - ease((p - 0.5f) * 2f)
        })
        queue.add(st(260L) { p -> dot.sc = 1f + 0.5f * Math.sin(p * Math.PI).toFloat(); armsUp = 0f })
        queue.add(st(1L) { _ -> dot.reset() })
    }

    // ───────────── drawing ─────────────

    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        tick()
        drawMan(cv)
        for (s in sprites) if (!s.dot) drawSprite(cv, s)
        for (s in sprites) if (s.dot) drawSprite(cv, s)
        drawChip(cv)
    }

    private fun drawSprite(cv: Canvas, s: Sprite) {
        cv.save()
        cv.translate(s.x, s.y); cv.rotate(s.rot); cv.scale(s.sc, s.sc)
        paint.reset(); paint.isAntiAlias = true; paint.isFilterBitmap = true
        cv.drawBitmap(s.bmp, -s.w / 2f, -s.h / 2f, paint)
        cv.restore()
    }

    private fun drawChip(cv: Canvas) {
        if (unread <= 0) return
        val label = faDigits(unread.toString()) + " پیام جدید"
        chipPaint.textSize = 12f * u; chipPaint.color = C.GREEN
        val tw = chipPaint.measureText(label)
        val l = 12f * u; val t = 8f * u
        rect.set(l, t, l + tw + 30f * u, t + 20f * u)
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.FILL; paint.color = tint(C.GREEN, 30); cv.drawRoundRect(rect, 10f * u, 10f * u, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1f * u; paint.color = tint(C.GREEN, 140); cv.drawRoundRect(rect, 10f * u, 10f * u, paint)
        val k = (Math.sin(SystemClock.uptimeMillis() / 260.0).toFloat() + 1f) / 2f
        paint.style = Paint.Style.FILL; paint.color = tint(C.GREEN, (70 + 110 * k).toInt())
        cv.drawCircle(l + 11f * u, t + 10f * u, (4f + 2.5f * k) * u, paint)
        paint.color = C.GREEN; cv.drawCircle(l + 11f * u, t + 10f * u, 3.2f * u, paint)
        cv.drawText(label, l + 21f * u, t + 14.5f * u, chipPaint)
    }

    private fun drawMan(cv: Canvas) {
        val ms = SystemClock.uptimeMillis()
        val x = mx
        val hipY = gy - 20f * u
        val shY = gy - 36f * u
        val sw = if (walking) Math.sin(walkPh.toDouble()).toFloat() else 0f
        val pi = Math.PI.toFloat()
        paint.reset(); paint.isAntiAlias = true
        // shadow
        paint.style = Paint.Style.FILL; paint.color = 0x22000000
        rect.set(x - 12f * u, gy - 2f * u, x + 12f * u, gy + 2.5f * u); cv.drawOval(rect, paint)
        paint.style = Paint.Style.STROKE; paint.strokeCap = Paint.Cap.ROUND; paint.strokeWidth = 3.2f * u; paint.color = C.TEXT
        // legs
        var thL = -0.06f - 0.65f * sw
        var thR = 0.06f + 0.65f * sw
        if (kick != 0f) { if (facing > 0) thR = facing * kick * 1.35f else thL = facing * kick * 1.35f }
        cv.drawLine(x, hipY, x + 20f * u * Math.sin(thL.toDouble()).toFloat(), hipY + 20f * u * Math.cos(thL.toDouble()).toFloat(), paint)
        cv.drawLine(x, hipY, x + 20f * u * Math.sin(thR.toDouble()).toFloat(), hipY + 20f * u * Math.cos(thR.toDouble()).toFloat(), paint)
        // torso
        cv.drawLine(x, hipY, x, shY, paint)
        // arms (angle 0 = hanging down, ±π = straight up)
        val aL = lerp(-0.12f + 0.55f * sw, -(pi - 0.32f), armsUp)
        var aR = lerp(0.12f - 0.55f * sw, pi - 0.32f, armsUp)
        if (wave > 0.01f) aR = lerp(aR, pi - 1.0f + 0.4f * Math.sin(ms / 85.0).toFloat(), wave)
        val sy = shY + 1f * u
        cv.drawLine(x, sy, x + 15f * u * Math.sin(aL.toDouble()).toFloat(), sy + 15f * u * Math.cos(aL.toDouble()).toFloat(), paint)
        cv.drawLine(x, sy, x + 15f * u * Math.sin(aR.toDouble()).toFloat(), sy + 15f * u * Math.cos(aR.toDouble()).toFloat(), paint)
        // head
        val hy = gy - 44f * u
        paint.style = Paint.Style.FILL; paint.color = 0xFFFFE3C4.toInt()
        cv.drawCircle(x, hy, 6.5f * u, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f * u; paint.color = C.TEXT
        cv.drawCircle(x, hy, 6.5f * u, paint)
        // little hat with a pompom
        paint.style = Paint.Style.FILL; paint.color = C.AMBER
        rect.set(x - 7f * u, hy - 8f * u, x + 7f * u, hy + 4f * u)
        cv.drawArc(rect, 180f, 180f, true, paint)
        cv.drawCircle(x, hy - 8.5f * u, 2.2f * u, paint)
        // face
        paint.color = C.TEXT
        cv.drawCircle(x - 2.4f * u + facing * 1.3f * u, hy + 0.8f * u, 0.9f * u, paint)
        cv.drawCircle(x + 2.4f * u + facing * 1.3f * u, hy + 0.8f * u, 0.9f * u, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.2f * u; paint.strokeCap = Paint.Cap.ROUND
        rect.set(x - 2.5f * u + facing * 1.3f * u, hy + 1f * u, x + 2.5f * u + facing * 1.3f * u, hy + 4.8f * u)
        cv.drawArc(rect, 20f, 140f, false, paint)
    }
}
