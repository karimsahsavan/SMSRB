package com.heimdall.sms

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

/**
 * A cartoon kid drawn on a Canvas: it bobs up and down, blinks, waves its hand, talks while the greeting
 * is being typed, and jumps when tapped. A pulsing green dot appears next to it when there are unread messages.
 */
class KidView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var jump = 0f
    var talking = false
    var alertDot = false

    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }
    private val jumper = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 520; interpolator = LinearInterpolator()
        addUpdateListener { jump = it.animatedValue as Float; invalidate() }
    }

    fun hop() { jumper.cancel(); jumper.start() }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); loop.start() }
    override fun onDetachedFromWindow() { loop.cancel(); jumper.cancel(); super.onDetachedFromWindow() }

    private val skin = 0xFFFFD2AE.toInt()
    private val hair = 0xFF4B2E1A.toInt()
    private val dark = 0xFF2B1D14.toInt()

    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return
        val ms = SystemClock.uptimeMillis()
        val cx = width / 2f
        val bob = Math.sin(ms / 380.0).toFloat() * s * 0.022f
        val hopY = -Math.sin(jump * Math.PI).toFloat() * s * 0.16f

        // ground shadow (shrinks while the kid is in the air)
        p.style = Paint.Style.FILL; p.color = 0x22000000
        val sh = 1f + hopY / s * 1.6f
        r.set(cx - s * 0.26f * sh, s * 0.955f, cx + s * 0.26f * sh, s * 0.995f)
        cv.drawOval(r, p)

        cv.save(); cv.translate(0f, bob + hopY)

        // body / shirt
        p.color = C.AMBER
        r.set(cx - s * 0.22f, s * 0.60f, cx + s * 0.22f, s * 0.98f)
        cv.drawRoundRect(r, s * 0.12f, s * 0.12f, p)
        p.color = 0x55FFFFFF
        r.set(cx - s * 0.05f, s * 0.74f, cx + s * 0.05f, s * 0.84f)
        cv.drawOval(r, p)

        // resting arm (left of the picture)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = s * 0.085f; p.color = C.AMBER
        cv.drawLine(cx - s * 0.20f, s * 0.68f, cx - s * 0.30f, s * 0.84f, p)
        p.style = Paint.Style.FILL; p.color = skin
        cv.drawCircle(cx - s * 0.31f, s * 0.865f, s * 0.05f, p)

        // waving arm
        val ang = Math.sin(ms / 140.0).toFloat() * 24f
        cv.save(); cv.rotate(ang, cx + s * 0.20f, s * 0.68f)
        p.style = Paint.Style.STROKE; p.color = C.AMBER
        cv.drawLine(cx + s * 0.20f, s * 0.68f, cx + s * 0.33f, s * 0.42f, p)
        p.style = Paint.Style.FILL; p.color = skin
        cv.drawCircle(cx + s * 0.335f, s * 0.395f, s * 0.052f, p)
        cv.restore()

        // ears, head
        p.color = skin
        cv.drawCircle(cx - s * 0.265f, s * 0.40f, s * 0.05f, p)
        cv.drawCircle(cx + s * 0.265f, s * 0.40f, s * 0.05f, p)
        cv.drawCircle(cx, s * 0.38f, s * 0.265f, p)

        // hair + little tuft
        p.color = hair
        r.set(cx - s * 0.275f, s * 0.105f, cx + s * 0.275f, s * 0.655f)
        cv.drawArc(r, 192f, 156f, true, p)
        cv.drawCircle(cx + s * 0.02f, s * 0.115f, s * 0.045f, p)

        // eyes (blink every ~3 s)
        val blink = (ms % 3200L) < 140L
        val ey = s * 0.41f
        if (blink) {
            p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.02f; p.color = dark
            cv.drawLine(cx - s * 0.13f, ey, cx - s * 0.06f, ey, p)
            cv.drawLine(cx + s * 0.06f, ey, cx + s * 0.13f, ey, p)
        } else {
            p.style = Paint.Style.FILL; p.color = dark
            cv.drawCircle(cx - s * 0.095f, ey, s * 0.038f, p)
            cv.drawCircle(cx + s * 0.095f, ey, s * 0.038f, p)
            p.color = 0xFFFFFFFF.toInt()
            cv.drawCircle(cx - s * 0.085f, ey - s * 0.012f, s * 0.013f, p)
            cv.drawCircle(cx + s * 0.105f, ey - s * 0.012f, s * 0.013f, p)
        }

        // cheeks
        p.style = Paint.Style.FILL; p.color = 0x66FF6F91
        cv.drawCircle(cx - s * 0.165f, s * 0.49f, s * 0.04f, p)
        cv.drawCircle(cx + s * 0.165f, s * 0.49f, s * 0.04f, p)

        // mouth: opens and closes while talking, otherwise a smile
        if (talking) {
            val open = 0.35f + 0.65f * Math.abs(Math.sin(ms / 110.0)).toFloat()
            p.style = Paint.Style.FILL; p.color = 0xFF8E2C3E.toInt()
            r.set(cx - s * 0.055f, s * 0.50f, cx + s * 0.055f, s * 0.50f + s * 0.07f * open)
            cv.drawOval(r, p)
        } else {
            p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.02f; p.strokeCap = Paint.Cap.ROUND; p.color = 0xFF8E2C3E.toInt()
            r.set(cx - s * 0.075f, s * 0.455f, cx + s * 0.075f, s * 0.57f)
            cv.drawArc(r, 25f, 130f, false, p)
        }
        cv.restore()

        // pulsing green dot when there are unread messages
        if (alertDot) {
            val k = (Math.sin(ms / 260.0).toFloat() + 1f) / 2f
            p.style = Paint.Style.FILL; p.color = tint(C.GREEN, (60 + 90 * k).toInt())
            cv.drawCircle(cx - s * 0.36f, s * 0.12f, s * (0.085f + 0.05f * k), p)
            p.color = C.GREEN
            cv.drawCircle(cx - s * 0.36f, s * 0.12f, s * 0.065f, p)
        }
    }
}

/** Card at the top of the messenger: the kid says hello with a typing effect and cycles through friendly lines. */
class WelcomeBanner(c: Context) : LinearLayout(c) {
    private val kid = KidView(c)
    private val bubble = TextView(c)
    private val h = Handler(Looper.getMainLooper())
    private var unread = 0
    private var msgIndex = 0
    private var full = ""
    private var shown = 0
    private var running = false

    private val typeRun = object : Runnable {
        override fun run() {
            if (!running) return
            if (shown < full.length) {
                shown++
                // never cut a surrogate pair (emoji) in half
                if (shown < full.length && Character.isHighSurrogate(full[shown - 1])) shown++
                bubble.text = full.substring(0, shown)
                kid.talking = true
                h.postDelayed(this, 42)
            } else {
                kid.talking = false
                h.postDelayed(nextRun, 3600)
            }
        }
    }
    private val nextRun = Runnable { if (running) { msgIndex++; startMessage() } }

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(12), dp(8), dp(14), dp(8))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(tint(C.AMBER, 55), C.SURF, tint(C.GREEN, 28))).apply {
            cornerRadius = dp(24).toFloat(); setStroke(dp(1), tint(C.AMBER, 130))
        }
        elevation = dp(4).toFloat()

        addView(kid, LayoutParams(dp(92), dp(104)))
        bubble.apply {
            textSize = 14.5f; setTextColor(C.TEXT); typeface = Fonts.bold
            setLineSpacing(0f, 1.25f); minLines = 2; maxLines = 3
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            textDirection = View.TEXT_DIRECTION_RTL
            background = GradientDrawable().apply {
                setColor(C.SURF); cornerRadius = dp(18).toFloat(); setStroke(dp(1), tint(C.AMBER, 120))
            }
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        addView(bubble, LayoutParams(0, W, 1f).apply { marginStart = dp(8) })

        setOnClickListener { poke() }
        kid.setOnClickListener { poke() }
    }

    private fun poke() {
        kid.hop()
        h.removeCallbacks(typeRun); h.removeCallbacks(nextRun)
        msgIndex++; startMessage()
        animate().scaleX(.985f).scaleY(.985f).setDuration(80).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator()).start()
        }.start()
    }

    fun setUnread(n: Int) {
        val changed = (n > 0) != (unread > 0)
        unread = n
        kid.alertDot = n > 0
        if (changed && running) { h.removeCallbacks(typeRun); h.removeCallbacks(nextRun); startMessage() }
    }

    /** Called every time the app comes to the front: greet again from the beginning. */
    fun restart() {
        h.removeCallbacks(typeRun); h.removeCallbacks(nextRun)
        msgIndex = 0; running = true
        kid.hop()
        startMessage()
    }

    private fun greeting(): String {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hr in 5..10 -> "صبح بخیر"
            hr in 11..15 -> "روز بخیر"
            hr in 16..18 -> "عصر بخیر"
            else -> "شب بخیر"
        }
    }

    private fun lines(): List<String> {
        val l = ArrayList<String>()
        l.add("سلام! ${greeting()} 👋\nخوش اومدی به کیان")
        l.add(if (unread > 0) "${faDigits(unread.toString())} گفتگوی خوانده‌نشده منتظرته 💌" else "پیام جدیدی نداری، همه‌چی آرومه 😌")
        l.add("امروز چه خبر؟ بیا گپ بزنیم ✨")
        l.add("منو لمس کن تا بپرم! 🎈")
        return l
    }

    private fun startMessage() {
        val ls = lines()
        full = ls[msgIndex % ls.size]; shown = 0
        bubble.text = ""
        h.removeCallbacks(typeRun)
        h.postDelayed(typeRun, 250)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!running) { running = true; startMessage() }
    }

    override fun onDetachedFromWindow() {
        running = false
        h.removeCallbacks(typeRun); h.removeCallbacks(nextRun)
        kid.talking = false
        super.onDetachedFromWindow()
    }
}
