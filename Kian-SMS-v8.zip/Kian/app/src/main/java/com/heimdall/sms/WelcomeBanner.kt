package com.heimdall.sms

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.View
import android.view.animation.BounceInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import java.util.Calendar
import java.util.Random

/**
 * Playful banner at the top of the messenger. The latest message's sender (or a greeting) is rendered as big text and
 * cut into its real pieces (letter groups and dots). A tiny mischievous stickman plays with them: he hangs from letters,
 * swings like Tarzan, kicks dots, juggles, rockets letters into space, topples them like dominoes, skates on them…
 * Every piece always returns home, so the word is whole again after each game.
 */
class WelcomeBanner(c: Context) : View(c) {
    private class Sprite(val bmp: Bitmap, val hx: Float, val hy: Float, val dot: Boolean) {
        var x = hx; var y = hy; var rot = 0f; var sc = 1f; var stx = 1f; var sty = 1f
        var alpha = 1f; var tint = 0
        val w: Int get() = bmp.width
        val h: Int get() = bmp.height
        fun reset() { x = hx; y = hy; rot = 0f; sc = 1f; stx = 1f; sty = 1f; alpha = 1f; tint = 0 }
    }

    private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val col: Int, val r: Float)
    private class Step(val dur: Long, val begin: (() -> Unit)?, val run: (Float) -> Unit)
    private class Game(val nb: Int, val nd: Int, val run: () -> Unit)

    companion object { const val EXTRA_DP = 340 }   // transparent area below the card where the stickman climbs down the messages

    private val u = dp(1).toFloat()
    private val baseH: Float get() = 172f * u
    private val whitePaint = Paint().apply { color = android.graphics.Color.WHITE }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val rnd = Random()
    private val bounce = BounceInterpolator()
    private val over = OvershootInterpolator(2.2f)
    private val PIF = Math.PI.toFloat()
    private val K = 1.35f                       // the stickman is drawn K times bigger so face and hands are clear
    private val reach: Float get() = 51f * u * K // how high his raised hands reach above his feet

    private val sprites = ArrayList<Sprite>()
    private val queue = ArrayList<Step>()
    private val parts = ArrayList<Part>()
    private val games = ArrayList<Game>()
    private val recent = ArrayList<Int>()
    private var cur: Step? = null
    private var stepT0 = 0L
    private var planX = 0f
    private var lastT = 0L

    // ── stickman state ──
    private var mx = -40f
    private var gy = 0f
    private var lift = 0f          // how high above the ground his feet are
    private var facing = 1f
    private var walkPh = 0f
    private var walking = false
    private var armsUp = 0f
    private var handOff = 0f      // alternating hand heights while climbing (hand over hand)
    private var kick = 0f
    private var wave = 0f
    private var dance = 0f
    private var bodyRot = 0f       // degrees, whole-body rotation (falls, swings, flips)
    private var pivHip = false     // rotate around the hip instead of the feet (flips)
    private var hangOn = false     // hanging from a piece by both hands
    private var gripX = 0f
    private var gripY = 0f
    private var bend = 0f          // pull-up amount while hanging
    private var legAdd = 0f        // legs swinging while hanging
    private var lastAng = 0f
    private var shake = 0f
    private var sling: Sprite? = null
    private var chute: Sprite? = null
    private var pendingEntrance = true

    private var unread = 0
    private var msgSender: String? = null
    private var msgBody: String? = null

    private val letterCols = intArrayOf(0xFF2979FF.toInt(), 0xFFE91E63.toInt(), 0xFF00B894.toInt(), 0xFFFF9800.toInt(), 0xFF8E44FF.toInt(), 0xFF00B8D9.toInt(), 0xFFFF5252.toInt(), 0xFF43A047.toInt())
    private val confetti = intArrayOf(C.AMBER, C.GREEN, 0xFFFF6F91.toInt(), 0xFF4FC3F7.toInt(), 0xFFFFD54F.toInt(), 0xFFB388FF.toInt())

    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { @Suppress("DEPRECATION") invalidate(0, 0, width, (baseH + EXTRA_DP * u).toInt()) }
    }

    init {
        elevation = 0f; translationZ = 2f * u; outlineProvider = null   // drawn above the messages, no shadow
        textPaint.typeface = Fonts.bold
        chipPaint.typeface = Fonts.bold
        setOnClickListener { poke() }
        buildGames()
    }

    // ───────────── public API ─────────────

    /** Shows this sender's name (or Persian words from the body) as the playground text; null → a greeting. */
    fun setMessage(sender: String?, body: String?) {
        if (sender == msgSender && body == msgBody) return
        msgSender = sender; msgBody = body
        rebuild()
    }

    fun setUnread(n: Int) { unread = n; invalidate() }

    /** Called each time the app comes to the front: the stickman walks in again. */
    fun restart() { pendingEntrance = true }

    // ───────────── view plumbing ─────────────

    override fun onMeasure(ws: Int, hs: Int) { setMeasuredDimension(MeasureSpec.getSize(ws), baseH.toInt()) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        gy = baseH - 8f * u
        rebuild()
        pendingEntrance = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); pendingEntrance = true
        if (!loop.isStarted) loop.start()
    }

    override fun onDetachedFromWindow() { loop.cancel(); super.onDetachedFromWindow() }

    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        if (v == VISIBLE) { if (isAttachedToWindow && !loop.isStarted) loop.start() } else loop.cancel()
    }

    // ───────────── text → sprites ─────────────

    private fun greeting(): String {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hr in 5..10 -> "صبح بخیر"
            hr in 11..15 -> "روز بخیر"
            hr in 16..18 -> "عصر بخیر"
            else -> "شب بخیر"
        }
    }

    private fun persianWords(s: String?): List<String> {
        if (s == null) return emptyList()
        return s.split(Regex("\\s+"))
            .map { w -> w.filter { ch -> (ch in '\u0600'..'\u06FF' && (ch.isLetter() || ch in '\u0660'..'\u0669' || ch in '\u06F0'..'\u06F9')) || ch in '0'..'9' || ch == '\u200c' } }
            .filter { it.length >= 2 || it.any { ch -> ch.isDigit() } }
    }

    private fun pickWords(): List<String> {
        var w = persianWords(msgSender)
        if (w.isEmpty()) w = persianWords(msgBody)
        if (w.isEmpty()) w = listOf("سلام") + greeting().split(" ")
        return w.take(4)
    }

    private fun rebuild() {
        for (s in sprites) s.bmp.recycle()
        sprites.clear(); queue.clear(); cur = null; parts.clear()
        resetPose()
        val w = width
        if (w <= 0) return
        var use = pickWords()
        textPaint.color = C.TEXT
        var size = 34f * u
        textPaint.textSize = size
        val avail = w - 28f * u
        while (textPaint.measureText(use.joinToString(" ")) > avail && size > 22f * u) { size -= 2f * u; textPaint.textSize = size }
        while (use.size > 1 && textPaint.measureText(use.joinToString(" ")) > avail) use = use.dropLast(1)
        val t = use.joinToString(" ")
        val fm = textPaint.fontMetrics
        val pad = (4f * u).toInt()
        val bw = Math.ceil(textPaint.measureText(t).toDouble()).toInt() + 2 * pad
        val bh = Math.ceil((fm.descent - fm.ascent).toDouble()).toInt() + 2 * pad
        if (bw <= 0 || bh <= 0) return
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawText(t, pad.toFloat(), pad - fm.ascent, textPaint)
        extract(bmp, (w - bw) / 2f, 24f * u, size)
        bmp.recycle()
    }

    /** Splits the rendered text into connected pieces: letter groups (bodies) and tiny dots. */
    private fun extract(bmp: Bitmap, left: Float, top: Float, ts: Float) {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        val lab = IntArray(w * h)
        val stack = IntArray(w * h)
        var n = 0
        for (i0 in px.indices) {
            if ((px[i0] ushr 24) < 60 || lab[i0] != 0) continue
            n++
            var sp = 0; stack[sp++] = i0; lab[i0] = n
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w; val y = i / w
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val j = ny * w + nx
                    if (lab[j] == 0 && (px[j] ushr 24) >= 60) { lab[j] = n; stack[sp++] = j }
                }
            }
        }
        if (n == 0) return
        val lab2 = lab.copyOf()
        for (i in px.indices) {
            if (lab[i] != 0 || (px[i] ushr 24) == 0) continue
            val x = i % w; val y = i / w
            var found = 0
            search@ for (dy in -1..1) {
                for (dx in -1..1) {
                    val nx = x + dx; val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val l = lab[ny * w + nx]
                    if (l != 0) { found = l; break@search }
                }
            }
            lab2[i] = found
        }
        val x0 = IntArray(n + 1) { w }; val y0 = IntArray(n + 1) { h }
        val x1 = IntArray(n + 1) { -1 }; val y1 = IntArray(n + 1) { -1 }
        val area = IntArray(n + 1)
        for (i in px.indices) {
            val l = lab2[i]; if (l == 0) continue
            val x = i % w; val y = i / w
            area[l]++
            if (x < x0[l]) x0[l] = x
            if (x > x1[l]) x1[l] = x
            if (y < y0[l]) y0[l] = y
            if (y > y1[l]) y1[l] = y
        }
        val dotArea = 0.04f * ts * ts
        val isDot = BooleanArray(n + 1)
        val ops = arrayOfNulls<IntArray>(n + 1)
        for (l in 1..n) {
            if (area[l] < 4) continue
            val bw = x1[l] - x0[l] + 1; val bh = y1[l] - y0[l] + 1
            isDot[l] = area[l] < dotArea && bw < 0.3f * ts && bh < 0.3f * ts
            ops[l] = IntArray(bw * bh)
        }
        for (i in px.indices) {
            val l = lab2[i]; if (l == 0) continue
            val o = ops[l] ?: continue
            val bw = x1[l] - x0[l] + 1
            val x = i % w - x0[l]; val y = i / w - y0[l]
            var col = px[i]
            col = (col and 0xFF000000.toInt()) or (letterCols[(l - 1) % letterCols.size] and 0x00FFFFFF)
            o[y * bw + x] = col
        }
        for (l in 1..n) {
            val o = ops[l] ?: continue
            val bw = x1[l] - x0[l] + 1; val bh = y1[l] - y0[l] + 1
            var out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            out.setPixels(o, 0, bw, 0, 0, bw, bh)
            if (isDot[l]) {   // dots a little bigger (same centre)
                val big = Bitmap.createScaledBitmap(out, (bw * 1.45f).toInt().coerceAtLeast(bw), (bh * 1.45f).toInt().coerceAtLeast(bh), true)
                out.recycle(); out = big
            }
            sprites.add(Sprite(out, left + x0[l] + bw / 2f, top + y0[l] + bh / 2f, isDot[l]))
        }
    }

    // ───────────── small helpers ─────────────

    private fun ease(p: Float) = p * p * (3f - 2f * p)
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun arcY(y0: Float, y1: Float, p: Float, h: Float) = lerp(y0, y1, p) - 4f * h * p * (1f - p)
    private fun sinF(x: Float) = Math.sin(x.toDouble()).toFloat()
    private fun cosF(x: Float) = Math.cos(x.toDouble()).toFloat()
    private fun cx(x: Float) = x.coerceIn(22f * u, width - 22f * u)
    private fun holdY(s: Sprite) = gy - (reach - 2f * u) - s.h * s.sc / 2f
    private fun st(dur: Long, begin: (() -> Unit)? = null, run: (Float) -> Unit) = Step(dur, begin, run)
    private fun <T> pick(l: List<T>): T = l[rnd.nextInt(l.size)]
    private fun bodies() = sprites.filter { !it.dot }.sortedBy { it.hx }
    private fun dotList() = sprites.filter { it.dot }
    private fun smallOnes(): List<Sprite> {
        val b = sprites.filter { !it.dot }.sortedBy { it.w }
        return b.take(maxOf(1, (b.size + 1) / 2))
    }

    private fun resetPose() {
        lift = 0f; armsUp = 0f; kick = 0f; wave = 0f; dance = 0f; bodyRot = 0f
        pivHip = false; hangOn = false; bend = 0f; handOff = 0f; legAdd = 0f; shake = 0f
        sling = null; chute = null; walking = false
    }

    private fun endGame() { sprites.forEach { it.reset() }; resetPose() }

    private fun burst(x: Float, y: Float, n: Int, spread: Float = 260f) {
        for (i in 0 until n) {
            val a = rnd.nextFloat() * 6.2831f
            val s = (0.3f + rnd.nextFloat()) * spread * u
            parts.add(Part(x, y, cosF(a) * s, sinF(a) * s - 120f * u, 0.7f + rnd.nextFloat() * 0.6f,
                confetti[rnd.nextInt(confetti.size)], 1.6f + rnd.nextFloat() * 1.6f))
        }
    }

    private fun flame(x: Float, y: Float) {
        parts.add(Part(x + (rnd.nextFloat() - 0.5f) * 6f * u, y, (rnd.nextFloat() - 0.5f) * 40f * u,
            120f * u + rnd.nextFloat() * 80f * u, 0.35f,
            if (rnd.nextBoolean()) 0xFFFF9800.toInt() else 0xFFFFEB3B.toInt(), 2.4f))
    }

    // ───────────── step engine ─────────────

    private fun tick() {
        val now = SystemClock.uptimeMillis()
        walking = false
        if (width <= 0) return
        if (pendingEntrance) { pendingEntrance = false; entrance() }
        var c = cur
        if (c == null) {
            if (queue.isEmpty()) planNext()
            if (queue.isEmpty()) return
            c = queue.removeAt(0); cur = c; stepT0 = now
            c.begin?.invoke()
        }
        val p = ((now - stepT0).toFloat() / c.dur.toFloat()).coerceIn(0f, 1f)
        c.run(p)
        if (p >= 1f) cur = null
    }

    private fun entrance() {
        queue.clear(); cur = null
        endGame()
        facing = 1f
        mx = -24f * u
        queue.add(walk(mx, width * 0.3f, null))
        queue.add(st(1100L) { p -> facing = 1f; wave = if (p < 0.9f) 1f else 0f })
        queue.add(st(1L) { _ -> wave = 0f })
        planX = width * 0.3f
        val b = bodies()
        // first trick: climb up and hang from a letter
        if (b.isNotEmpty()) { gHangSwing(pick(b)); queue.add(st(1L) { _ -> endGame() }); queue.add(st(600L) { _ -> }) }
    }

    private fun poke() {
        queue.clear(); cur = null
        endGame()
        planNext()
    }

    private fun walk(from: Float, to: Float, carry: Sprite?): Step {
        val dist = Math.abs(to - from)
        val dur = (dist / (110f * u) * 1000f).toLong().coerceAtLeast(150L)
        var x0 = from
        return st(dur, { x0 = mx }) { p ->
            val nx = lerp(x0, to, ease(p))
            if (Math.abs(to - x0) > 1f) facing = if (to > x0) 1f else -1f
            walkPh += Math.abs(nx - mx) / (6f * u * K)
            walking = Math.abs(nx - mx) > 0.01f
            mx = nx
            if (carry != null) { carry.x = mx; carry.y = holdY(carry); carry.rot = sinF(walkPh) * 3f }
        }
    }

    private fun go(to: Float, carry: Sprite? = null) { queue.add(walk(planX, to, carry)); planX = to }

    /** One sprite flies from where it is to a target (evaluated when the step starts). */
    private fun fly(sp: Sprite, dur: Long, h: Float, rotEnd: Float, spinIn: Float, mode: Int, sc1: Float,
                    tx: () -> Float, ty: () -> Float) {
        var sx = 0f; var sy = 0f; var sr = 0f; var ss = 1f; var ex = 0f; var ey = 0f
        queue.add(st(dur, { sx = sp.x; sy = sp.y; sr = sp.rot % 360f + spinIn; ss = sp.sc; ex = tx(); ey = ty() }) { p ->
            val e = when (mode) { 1 -> over.getInterpolation(p); 2 -> bounce.getInterpolation(p); 3 -> p; else -> ease(p) }
            sp.x = lerp(sx, ex, e); sp.y = arcY(sy, ey, e, h); sp.rot = lerp(sr, rotEnd, e); sp.sc = lerp(ss, sc1, e)
        })
    }

    private fun flyHome(sp: Sprite, dur: Long, h: Float, spinIn: Float = 0f, mode: Int = 1) {
        fly(sp, dur, h, 0f, spinIn, mode, 1f, { sp.hx }, { sp.hy })
    }

    /** Walk under the piece, reach up and lift it above the head. */
    private fun grab(sp: Sprite) {
        go(cx(sp.hx))
        queue.add(st(300L) { p -> armsUp = ease(p) })
        var sx = 0f; var sy = 0f
        queue.add(st(450L, { sx = sp.x; sy = sp.y }) { p ->
            val e = ease(p)
            sp.x = lerp(sx, mx, e); sp.y = lerp(sy, holdY(sp), e); sp.rot = lerp(0f, -6f, e)
        })
    }

    // ───────────── hanging ─────────────

    private fun hangFrame(sp: Sprite, ang: Float, b: Float) {
        hangOn = true; bend = b; bodyRot = ang; lastAng = ang; legAdd = -ang * 0.02f
        sp.x = sp.hx + ang * 0.2f; sp.y = sp.hy + 3f * u + b * 5f * u; sp.rot = ang * 0.12f
        gripX = sp.x; gripY = sp.y + sp.h / 2f - 3f * u; mx = gripX
    }

    /** Jump up from the ground and grab the bottom of a piece with both hands. */
    private fun hangStart(sp: Sprite) {
        go(cx(sp.hx))
        val gripEff = sp.hy + sp.h / 2f
        val lT = maxOf(gy - reach - gripEff, 3f * u)
        queue.add(st(320L) { p -> armsUp = ease(p) })
        queue.add(st(520L) { p ->
            val e = ease(p)
            lift = lerp(0f, lT, e) + 4f * 16f * u * p * (1f - p)
            armsUp = 1f
            if (p >= 1f) hangFrame(sp, 0f, 0f)
        })
    }

    /** Let go and land on the ground. */
    private fun dropDown() {
        var l0 = 0f
        queue.add(st(550L, { hangOn = false; mx = gripX; l0 = gy - reach - gripY; bodyRot = 0f; legAdd = 0f; bend = 0f; armsUp = 1f }) { p ->
            lift = lerp(l0, 0f, bounce.getInterpolation(p)); armsUp = 1f - ease(p)
        })
        queue.add(st(1L) { _ -> lift = 0f })
    }

    private fun gHangSwing(sp: Sprite) {
        hangStart(sp)
        val sgn = if (rnd.nextBoolean()) 1f else -1f
        queue.add(st(2600L) { p -> hangFrame(sp, sgn * sinF(p * 5.5f * PIF) * (6f + 38f * p), 0f) })
        val dir = sgn
        val landX = (planX + dir * 120f * u).coerceIn(24f * u, width - 24f * u)
        var x0 = 0f; var l0 = 0f; var a0 = 0f
        // Tarzan: let go at the top of the swing and fly off with a somersault
        queue.add(st(900L, { x0 = gripX; l0 = gy - reach - gripY; a0 = lastAng; hangOn = false; pivHip = true; mx = x0; lift = l0; bend = 0f }) { p ->
            mx = lerp(x0, landX, p); lift = lerp(l0, 0f, p) + 4f * 40f * u * p * (1f - p)
            bodyRot = lerp(a0, dir * 360f, ease(p)); facing = dir; armsUp = lerp(1f, 0.3f, p); legAdd = 0f
            val k = ease(minOf(1f, p * 3f))
            sp.x = sp.hx + (1f - k) * a0 * 0.2f; sp.y = sp.hy + 3f * u * (1f - k); sp.rot = a0 * 0.12f * (1f - p)
        })
        queue.add(st(1L) { _ -> pivHip = false; bodyRot = 0f; lift = 0f; sp.reset() })
        queue.add(st(500L) { p -> armsUp = if (p < 0.5f) ease(p * 2f) else 1f - ease((p - 0.5f) * 2f) })
    }

    /** Climbs down the "wall" of messages below the card hand over hand, then climbs back up. */
    private fun gWall() {
        val wx = if (rnd.nextBoolean()) width - 26f * u else 26f * u
        val depth = 250f * u
        var gx = 0f
        go(wx)
        queue.add(st(350L) { p -> armsUp = ease(p) })
        // lower himself over the edge and hold on
        queue.add(st(700L, { gx = mx }) { p ->
            hangOn = true; gripX = gx; mx = gx; gripY = lerp(gy - reach, gy, ease(p)); bend = 0f; bodyRot = 0f; legAdd = 0f
        })
        // climb down
        queue.add(st(5600L) { p ->
            val ph = p * 11f * 2f * PIF
            hangOn = true; gripX = gx; mx = gx
            gripY = gy + depth * ease(p) + sinF(ph) * 2.5f * u
            bend = (1f - cosF(ph)) / 2f * 0.6f; legAdd = sinF(ph) * 0.35f; handOff = sinF(ph) * 5f * u
            bodyRot = sinF(ph * 0.5f) * 2.5f
        })
        // hang for a moment at the bottom
        queue.add(st(900L) { p ->
            gripY = gy + depth; bend = 0f; handOff = 0f
            legAdd = sinF(p * 3f * PIF) * 0.4f; bodyRot = sinF(p * 2f * PIF) * 5f
        })
        // climb back up
        queue.add(st(5600L) { p ->
            val ph = p * 11f * 2f * PIF
            gripY = gy + depth * (1f - ease(p)) + sinF(ph) * 2.5f * u
            bend = (1f - cosF(ph)) / 2f * 0.6f; legAdd = sinF(ph) * 0.35f; handOff = sinF(ph) * 5f * u
            bodyRot = sinF(ph * 0.5f) * 2.5f
        })
        // pull himself up onto the edge
        queue.add(st(650L) { p ->
            gripY = lerp(gy, gy - reach, ease(p)); bend = 0f; handOff = 0f; legAdd = 0f; bodyRot = 0f
        })
        queue.add(st(1L) { _ -> hangOn = false; lift = 0f; mx = gx; handOff = 0f })
        queue.add(st(450L) { p -> armsUp = 1f - ease(p) })
    }

    private fun gPullups(sp: Sprite) {
        hangStart(sp)
        queue.add(st(2400L) { p -> hangFrame(sp, sinF(p * 20f) * 2f, (1f - cosF(p * 6f * PIF)) / 2f) })
        dropDown()
    }

    private fun gMonkey(bs: List<Sprite>) {
        val ord = if (rnd.nextBoolean()) bs else bs.reversed()
        val seq = ord.take(minOf(ord.size, 2 + rnd.nextInt(2)))
        hangStart(seq[0])
        for (k in seq.indices) {
            val s = seq[k]
            queue.add(st(650L) { p -> hangFrame(s, 12f * sinF(p * 4f * PIF), 0f) })
            if (k + 1 < seq.size) {
                val nx = seq[k + 1]
                var gx0 = 0f; var gy0 = 0f
                val side = if (nx.hx > s.hx) -1f else 1f
                queue.add(st(520L, { gx0 = gripX; gy0 = gripY }) { p ->
                    val e = ease(p)
                    hangOn = true
                    gripX = lerp(gx0, nx.hx, e); gripY = arcY(gy0, nx.hy + nx.h / 2f, e, 12f * u); mx = gripX
                    bodyRot = side * 28f * sinF(p * PIF); lastAng = bodyRot
                    s.x = s.hx; s.y = s.hy; s.rot = 0f
                })
            }
        }
        dropDown()
    }

    // ───────────── piece games ─────────────

    private fun gThrow(sp: Sprite) {
        grab(sp)
        val far = if (planX < width / 2f) width - 30f * u else 30f * u
        val d = if (far > planX) 1f else -1f
        go(far, sp)
        queue.add(st(240L) { p -> facing = d; sp.x = mx; sp.y = holdY(sp); sp.rot = lerp(0f, -22f * d, ease(p)) })
        val offX = if (d > 0) width + 60f * u else -60f * u
        var sx = 0f; var sy = 0f
        queue.add(st(650L, { sx = sp.x; sy = sp.y }) { p ->
            armsUp = 1f - ease(minOf(1f, p * 3f))
            sp.x = lerp(sx, offX, p); sp.y = arcY(sy, -30f * u, p, 40f * u)
            sp.rot = -22f * d + d * 720f * p; sp.sc = lerp(1f, 0.6f, p)
        })
        queue.add(st(700L) { _ -> armsUp = 0f })
        val backX = if (rnd.nextBoolean()) offX else (if (d > 0) -60f * u else width + 60f * u)
        queue.add(st(1L) { _ -> sp.x = backX; sp.y = -30f * u; sp.sc = 0.6f })
        flyHome(sp, 1000L, 36f * u, -540f * d)
    }

    private fun gToss(sp: Sprite) {
        grab(sp)
        val n = 2 + rnd.nextInt(2)
        for (i in 0 until n) {
            val spin = (if (i % 2 == 0) 1f else -1f) * 360f * (1 + rnd.nextInt(2))
            queue.add(st(800L) { p ->
                armsUp = if (p < 0.25f) 1f else if (p > 0.8f) 0.3f + 0.7f * ((p - 0.8f) / 0.2f) else 0.3f
                sp.x = mx; sp.y = holdY(sp) - 4f * 50f * u * p * (1f - p); sp.rot = p * spin
            })
        }
        queue.add(st(1L) { _ -> sp.rot = 0f })
        flyHome(sp, 550L, 24f * u, 0f, 0)
    }

    private fun dropFall(dot: Sprite) {
        var y0 = 0f
        val groundY = gy - dot.h / 2f - 1f * u
        queue.add(st(700L, { y0 = dot.y }) { p ->
            dot.y = lerp(y0, groundY, bounce.getInterpolation(p))
            dot.rot = 25f * sinF(p * 18f) * (1f - p)
        })
    }

    private fun gKick(dot: Sprite) {
        val dir = if (dot.hx < width / 2f) 1f else -1f
        val groundY = gy - dot.h / 2f - 1f * u
        dropFall(dot)
        go((dot.hx - dir * 17f * u).coerceIn(16f * u, width - 16f * u))
        queue.add(st(280L) { p -> facing = dir; kick = -0.7f * ease(p) })
        var fx = 0f; var fy = 0f
        val wallX = if (dir > 0) width - 12f * u else 12f * u
        queue.add(st(1000L, { fx = dot.x; fy = dot.y; dot.rot = 0f }) { p ->
            kick = if (p < 0.12f) lerp(-0.7f, 1f, p / 0.12f) else lerp(1f, 0f, minOf(1f, (p - 0.12f) * 4f))
            val f = maxOf(0f, (p - 0.12f) / 0.88f)
            if (f < 0.55f) {
                val t = f / 0.55f
                dot.x = lerp(fx, wallX, t); dot.y = arcY(fy, gy - 36f * u, t, 44f * u); dot.rot = dir * 600f * t
            } else {
                val t = (f - 0.55f) / 0.45f
                dot.x = lerp(wallX, wallX - dir * 46f * u, t); dot.y = arcY(gy - 36f * u, groundY, t, 20f * u)
                dot.rot = dir * (600f + 300f * t)
            }
        })
        queue.add(st(600L) { _ -> kick = 0f })
        var cx0 = 0f; var cy0 = 0f; var r0 = 0f
        queue.add(st(1000L, { cx0 = dot.x; cy0 = dot.y; r0 = dot.rot % 360f }) { p ->
            val e = ease(p)
            dot.x = lerp(cx0, dot.hx, e); dot.y = arcY(cy0, dot.hy, e, 70f * u); dot.rot = lerp(r0, 0f, e)
            armsUp = if (p < 0.5f) ease(p * 2f) else 1f - ease((p - 0.5f) * 2f)
        })
        queue.add(st(260L) { p -> dot.sc = 1f + 0.5f * sinF(p * PIF); armsUp = 0f })
    }

    private fun gSwap(bs: List<Sprite>, n: Int) {
        val g = bs.shuffled(rnd).take(n)
        val m = g.size
        go(cx(g.map { it.hx }.average().toFloat()))
        queue.add(st(500L) { p -> armsUp = ease(p) * (0.55f + 0.45f * sinF(p * 24f)) })
        val sx = FloatArray(m); val sy = FloatArray(m)
        queue.add(st(1100L, { for (i in 0 until m) { sx[i] = g[i].x; sy[i] = g[i].y } }) { p ->
            val e = over.getInterpolation(p)
            for (i in 0 until m) {
                val t = g[(i + 1) % m]
                g[i].x = lerp(sx[i], t.hx, e); g[i].y = arcY(sy[i], t.hy, e, if (i % 2 == 0) 30f * u else -18f * u)
                g[i].rot = 360f * p * (if (i % 2 == 0) 1f else -1f)
            }
        })
        queue.add(st(900L) { p -> wave = 1f; facing = if (p < 0.5f) 1f else -1f; for (s in g) s.rot = 0f })
        val ex = FloatArray(m); val ey = FloatArray(m)
        queue.add(st(1000L, { wave = 0f; for (i in 0 until m) { ex[i] = g[i].x; ey[i] = g[i].y } }) { p ->
            val e = over.getInterpolation(p)
            for (i in 0 until m) { g[i].x = lerp(ex[i], g[i].hx, e); g[i].y = arcY(ey[i], g[i].hy, e, 26f * u); g[i].rot = -360f * (1f - p) * (if (i % 2 == 0) 1f else -1f) }
        })
    }

    private fun gRoll(sp: Sprite) {
        val dir = if (sp.hx < width / 2f) 1f else -1f
        val s0 = 0.65f
        var y0 = 0f
        val gnd = gy - sp.h * s0 / 2f
        queue.add(st(650L, { y0 = sp.y }) { p -> sp.y = lerp(y0, gnd, bounce.getInterpolation(p)); sp.sc = lerp(1f, s0, ease(p)) })
        go((sp.hx - dir * (sp.w * s0 / 2f + 18f * u)).coerceIn(16f * u, width - 16f * u))
        queue.add(st(260L) { p -> facing = dir; kick = -0.7f * ease(p) })
        val r = maxOf(sp.w, sp.h) * s0 / 2f
        val wall = if (dir > 0) width - 14f * u - sp.w * s0 / 2f else 14f * u + sp.w * s0 / 2f
        var x0 = 0f
        queue.add(st(1400L, { x0 = sp.x }) { p ->
            kick = if (p < 0.1f) lerp(-0.7f, 1f, p / 0.1f) else lerp(1f, 0f, minOf(1f, (p - 0.1f) * 5f))
            val e = 1f - (1f - p) * (1f - p) * (1f - p)
            val nx = lerp(x0, wall, e); sp.rot += (nx - sp.x) / r * 57.3f; sp.x = nx
        })
        val back = if (dir > 0) 14f * u + sp.w * s0 / 2f else width - 14f * u - sp.w * s0 / 2f
        var x1 = 0f
        queue.add(st(1700L, { x1 = sp.x; kick = 0f }) { p ->
            val e = 1f - (1f - p) * (1f - p) * (1f - p)
            val nx = lerp(x1, back, e); sp.rot += (nx - sp.x) / r * 57.3f; sp.x = nx
            val dx = sp.x - mx
            facing = if (dx > 0) 1f else -1f
            lift = if (Math.abs(dx) < 30f * u) 24f * u * (1f - (dx / (30f * u)) * (dx / (30f * u))) else 0f
            armsUp = if (lift > 1f) 0.8f else 0f
        })
        queue.add(st(1L) { _ -> lift = 0f; armsUp = 0f })
        flyHome(sp, 900L, 50f * u, 360f)
    }

    private fun gBowling(dot: Sprite, target: Sprite) {
        val dir = if (target.hx > dot.hx) 1f else -1f
        val groundY = gy - dot.h / 2f - 1f * u
        dropFall(dot)
        go((dot.hx - dir * 17f * u).coerceIn(16f * u, width - 16f * u))
        queue.add(st(280L) { p -> facing = dir; kick = -0.7f * ease(p) })
        var fx = 0f; var fy = 0f
        queue.add(st(800L, { fx = dot.x; fy = dot.y; dot.rot = 0f }) { p ->
            kick = if (p < 0.15f) lerp(-0.7f, 1f, p / 0.15f) else lerp(1f, 0f, minOf(1f, (p - 0.15f) * 4f))
            val f = maxOf(0f, (p - 0.15f) / 0.85f)
            dot.x = lerp(fx, target.hx, f); dot.y = arcY(fy, target.hy, f, 40f * u); dot.rot = dir * 720f * f
        })
        queue.add(st(1L) { _ -> kick = 0f; shake = 6f * u; burst(target.hx, target.hy, 22) })
        var ty0 = 0f
        queue.add(st(800L, { ty0 = target.y }) { p ->
            val e = bounce.getInterpolation(p)
            target.x = target.hx + dir * 26f * u * e; target.y = lerp(ty0, gy - target.w / 2f - 1f * u, e); target.rot = dir * 90f * e
            dot.y = lerp(dot.y, groundY, 0.2f)
            armsUp = if (p > 0.4f) ease((p - 0.4f) / 0.6f) else 0f
        })
        queue.add(st(500L) { p -> armsUp = 1f; lift = 6f * u * sinF(p * 3f * PIF) })
        queue.add(st(1L) { _ -> lift = 0f; armsUp = 0f })
        flyHome(target, 900L, 40f * u, -360f * dir)
        flyHome(dot, 700L, 50f * u, 360f)
    }

    private fun gJuggle(ds: List<Sprite>) {
        val items = ds.shuffled(rnd).take(3)
        val n = items.size
        go(cx(width * (0.35f + rnd.nextFloat() * 0.3f)))
        for (it in items) fly(it, 450L, 24f * u, 0f, 0f, 0, 0.9f, { mx }, { gy - 62f * u * K })
        queue.add(st(2800L) { p ->
            armsUp = 0.55f + 0.45f * sinF(p * 60f)
            for (k in 0 until n) {
                val th = p * 2f * PIF * 5f + k * 2f * PIF / n
                items[k].x = mx + 20f * u * cosF(th); items[k].y = gy - 64f * u * K - 11f * u * sinF(th)
            }
        })
        queue.add(st(1L) { _ -> armsUp = 0f })
        for (it in items) flyHome(it, 480L, 40f * u, 360f)
    }

    private fun gBalloon(sp: Sprite) {
        go(cx(sp.hx))
        queue.add(st(300L) { p -> armsUp = ease(p) })
        for (k in 1..3) {
            queue.add(st(500L) { p ->
                armsUp = 0.2f + 0.8f * Math.abs(sinF(p * PIF * 2f))
                val e = ease(p)
                sp.sc = 1f + 0.45f * (k - 1) + 0.45f * e
                sp.rot = 4f * sinF(p * 26f) * k
            })
        }
        queue.add(st(1L) { _ -> sp.alpha = 0f; shake = 6f * u; burst(sp.x, sp.y, 34, 320f) })
        queue.add(st(500L) { p -> bodyRot = -30f * sinF(minOf(1f, p * 2f) * PIF); armsUp = 0f })
        queue.add(st(1L) { _ -> bodyRot = 0f; sp.sc = 0.1f; sp.rot = 0f; sp.alpha = 1f })
        flyHome(sp, 750L, 20f * u, 720f)
        queue.add(st(1L) { _ -> burst(sp.hx, sp.hy, 10, 160f) })
    }

    private fun gRocket(sp: Sprite) {
        go(cx(sp.hx))
        queue.add(st(500L) { p -> armsUp = 0f; wave = 1f; facing = 1f; if (rnd.nextInt(3) == 0) burst(sp.x, sp.y + sp.h / 2f, 1, 90f) })
        queue.add(st(900L) { p ->
            wave = 0f
            sp.x = sp.hx + sinF(p * 70f) * 2.5f * u * p; sp.rot = sinF(p * 55f) * 4f * p
            flame(sp.x, sp.y + sp.h / 2f)
            armsUp = ease(minOf(1f, p * 2f))
        })
        var sy = 0f
        queue.add(st(750L, { sy = sp.y }) { p ->
            sp.y = lerp(sy, -90f * u, p * p); sp.rot = 0f
            flame(sp.x, sp.y + sp.h / 2f); flame(sp.x, sp.y + sp.h / 2f)
        })
        queue.add(st(600L) { p -> armsUp = 1f; if (p > 0.9f) shake = 3f * u })
        queue.add(st(1L) { _ -> chute = sp; sp.sc = 0.8f; sp.y = -50f * u })
        queue.add(st(1900L) { p ->
            val e = ease(p)
            sp.y = lerp(-50f * u, sp.hy, e); sp.x = sp.hx + sinF(p * 9f) * 16f * u * (1f - p); sp.rot = sinF(p * 9f) * 8f * (1f - p)
            sp.sc = lerp(0.8f, 1f, e); armsUp = 1f - ease(p)
        })
        queue.add(st(1L) { _ -> chute = null; burst(sp.hx, sp.hy, 14, 180f) })
    }

    private fun gSling(sp: Sprite) {
        val dir = if (sp.hx < width / 2f) 1f else -1f
        go(cx(if (dir > 0) 34f * u else width - 34f * u))
        queue.add(st(1L) { _ -> facing = dir })
        fly(sp, 500L, 22f * u, 0f, 0f, 0, 0.7f, { mx + dir * 16f * u }, { gy - 28f * u * K })
        queue.add(st(1L) { _ -> sling = sp })
        queue.add(st(700L) { p ->
            val e = ease(p)
            bodyRot = -dir * 16f * e
            sp.x = mx + dir * 16f * u - dir * 26f * u * e; sp.y = gy - 28f * u * K
        })
        val wallX = if (dir > 0) width - 14f * u else 14f * u
        var x0 = 0f; var y0 = 0f
        queue.add(st(1200L, { x0 = sp.x; y0 = sp.y; sling = null }) { p ->
            bodyRot = -dir * 16f * (1f - over.getInterpolation(minOf(1f, p * 2f)))
            if (p < 0.45f) {
                val t = p / 0.45f
                sp.x = lerp(x0, wallX, t); sp.y = arcY(y0, gy - 66f * u, t, 18f * u); sp.rot = dir * 540f * t
            } else {
                val t = (p - 0.45f) / 0.55f
                sp.x = lerp(wallX, width * 0.5f, t); sp.y = arcY(gy - 66f * u, gy - sp.h * 0.35f, t, 26f * u); sp.rot = dir * (540f + 360f * t)
            }
        })
        queue.add(st(1L) { _ -> bodyRot = 0f })
        flyHome(sp, 900L, 44f * u, 360f)
    }

    private fun gTug(sp: Sprite) {
        val dir = if (rnd.nextBoolean()) 1f else -1f
        go(cx(sp.hx))
        queue.add(st(300L) { p -> armsUp = ease(p); facing = dir })
        queue.add(st(1000L) { p ->
            val e = ease(p)
            armsUp = 1f; sp.sty = lerp(1f, 1.5f, e); sp.stx = lerp(1f, 0.8f, e); bodyRot = -dir * 10f * e
            sp.rot = sinF(p * 30f) * 1.5f
        })
        queue.add(st(900L) { p ->
            val v = Math.exp((-p * 4f).toDouble()).toFloat() * cosF(p * 22f)
            sp.sty = 1f + 0.5f * v; sp.stx = 1f - 0.2f * v
            val q = minOf(1f, p * 2.2f)
            bodyRot = lerp(-dir * 10f, -dir * 88f, ease(q)); lift = 8f * u * sinF(q * PIF); armsUp = 1f - ease(q)
        })
        queue.add(st(600L) { _ -> lift = 0f })
        queue.add(st(550L) { p -> bodyRot = lerp(-dir * 88f, 0f, ease(p)) })
        queue.add(st(500L) { p -> wave = 1f; facing = dir; if (p >= 1f) wave = 0f })
    }

    private fun gSlip(dot: Sprite) {
        val dir = if (mx < width / 2f) 1f else -1f
        val dx = (mx + dir * 80f * u).coerceIn(30f * u, width - 30f * u)
        val groundY = gy - dot.h / 2f - 1f * u
        planX = mx
        fly(dot, 700L, 50f * u, 0f, 360f, 2, 1f, { dx }, { groundY })
        go(dx - dir * 24f * u)
        var x0 = 0f
        queue.add(st(450L, { x0 = mx }) { p ->
            walking = true; walkPh += 0.25f; facing = dir
            mx = lerp(x0, dx - dir * 6f * u, p)
            bodyRot = dir * 95f * p * p
        })
        queue.add(st(800L) { p -> bodyRot = dir * 95f; dot.sc = 1f + 0.25f * sinF(p * 26f); shake = 1f * u })
        queue.add(st(1L) { _ -> dot.sc = 1f })
        flyHome(dot, 850L, 60f * u, 720f)
        queue.add(st(550L) { p -> bodyRot = lerp(dir * 95f, 0f, ease(p)) })
        queue.add(st(800L) { p -> wave = 1f; facing = dir; kick = 0f; if (p >= 1f) wave = 0f })
    }

    private fun gSkate(sp: Sprite) {
        val dir = if (sp.hx < width / 2f) 1f else -1f
        val s0 = 0.7f
        var y0 = 0f
        val gnd = gy - sp.h * s0 / 2f
        val topL = sp.h * s0
        queue.add(st(650L, { y0 = sp.y }) { p -> sp.y = lerp(y0, gnd, bounce.getInterpolation(p)); sp.sc = lerp(1f, s0, ease(p)) })
        go((sp.hx - dir * (sp.w * s0 / 2f + 16f * u)).coerceIn(16f * u, width - 16f * u))
        var mx0 = 0f
        queue.add(st(420L, { mx0 = mx }) { p ->
            val e = ease(p)
            facing = dir
            mx = lerp(mx0, sp.x, e); lift = lerp(0f, topL, e) + 4f * 14f * u * p * (1f - p)
        })
        val wallX = if (dir > 0) width - 34f * u else 34f * u
        var x0 = 0f
        queue.add(st(1500L, { x0 = sp.x }) { p ->
            val e = ease(p)
            sp.x = lerp(x0, wallX, e); mx = sp.x; lift = topL; armsUp = 0.5f + 0.2f * sinF(p * 30f); facing = dir
            sp.rot = sinF(p * 20f) * 2f; bodyRot = dir * 6f * sinF(p * PIF)
        })
        var xs = 0f
        queue.add(st(800L, { xs = mx; bodyRot = 0f }) { p ->
            mx = lerp(xs, xs + dir * 26f * u, p); lift = lerp(topL, 0f, p) + 4f * 30f * u * p * (1f - p)
            pivHip = true; bodyRot = dir * 360f * ease(p); armsUp = 0.8f
            sp.x = lerp(wallX, wallX - dir * 40f * u, p)
        })
        queue.add(st(1L) { _ -> pivHip = false; bodyRot = 0f; lift = 0f; armsUp = 0f })
        flyHome(sp, 900L, 50f * u, 360f)
    }

    private fun gHeadbutt(sp: Sprite) {
        go(cx(sp.hx))
        val need = gy - reach - (sp.hy + sp.h / 2f)
        val hMax = maxOf(need + 5f * u, 18f * u)
        var hit = false
        queue.add(st(520L) { p ->
            armsUp = 0.4f; lift = 4f * hMax * p * (1f - p)
            if (p > 0.5f) {
                if (!hit) { hit = true; shake = 3f * u; burst(sp.hx, sp.hy + sp.h / 2f, 12, 150f) }
                val q = (p - 0.5f) * 2f
                sp.y = sp.hy - 40f * u * sinF(q * PIF); sp.rot = 360f * q
            }
        })
        queue.add(st(1L) { _ -> lift = 0f; sp.rot = 0f })
        queue.add(st(700L) { p ->
            val v = Math.exp((-p * 3f).toDouble()).toFloat() * cosF(p * 20f)
            sp.y = sp.hy + 6f * u * v; wave = 1f; facing = 1f
        })
        queue.add(st(1L) { _ -> wave = 0f })
    }

    private fun gHat(sp: Sprite) {
        grab(sp)
        val topY = gy - 55f * u * K
        var sx = 0f; var sy = 0f; var ss = 1f
        queue.add(st(550L, { sx = sp.x; sy = sp.y; ss = sp.sc }) { p ->
            val e = ease(p)
            sp.sc = lerp(ss, 0.55f, e); sp.x = lerp(sx, mx, e); sp.y = lerp(sy, topY - sp.h * sp.sc / 2f + 4f * u, e)
            sp.rot = lerp(sp.rot, 0f, e); armsUp = lerp(1f, 0.35f, e)
        })
        val m0 = planX
        queue.add(st(2200L) { p ->
            val nx = m0 + 22f * u * sinF(p * 4f * PIF)
            walkPh += Math.abs(nx - mx) / (6f * u * K); walking = true; mx = nx
            facing = if (cosF(p * 4f * PIF) > 0f) 1f else -1f
            sp.x = mx; sp.y = topY - sp.h * sp.sc / 2f + 4f * u; sp.rot = 7f * sinF(p * 30f)
            armsUp = 0.35f + 0.1f * sinF(p * 40f)
        })
        queue.add(st(1L) { _ -> armsUp = 0.2f })
        flyHome(sp, 800L, 46f * u, 540f)
    }

    private val discoCols = intArrayOf(C.AMBER, C.GREEN, 0xFFFF6F91.toInt(), 0xFF4FC3F7.toInt(), 0xFFFFD54F.toInt(), 0xFFB388FF.toInt())

    private fun gDisco() {
        go(cx(width * 0.5f))
        val list = sprites.toList()
        queue.add(st(3400L) { p ->
            dance = 1f; facing = 1f
            lift = Math.abs(sinF(p * 60f)) * 4f * u
            for ((i, s) in list.withIndex()) {
                val hop = maxOf(0f, sinF(p * 30f + i * 0.9f))
                s.y = s.hy - hop * 8f * u; s.rot = sinF(p * 30f + i) * 5f
                s.tint = discoCols[((p * 16f).toInt() + i) % discoCols.size]
            }
        })
        queue.add(st(1L) { _ -> dance = 0f; lift = 0f; for (s in list) { s.tint = 0; s.reset() }; burst(width / 2f, 40f * u, 30, 300f) })
        queue.add(st(500L) { p -> armsUp = if (p < 0.5f) ease(p * 2f) else 1f - ease((p - 0.5f) * 2f) })
    }

    private fun gCollapse() {
        val list = sprites.toList()
        val n = list.size
        go(cx(width * (0.3f + rnd.nextFloat() * 0.4f)))
        queue.add(st(900L) { p -> shake = 3.5f * u; bodyRot = sinF(p * 40f) * 5f })
        val sx = FloatArray(n); val sy = FloatArray(n); val tx = FloatArray(n); val tr = FloatArray(n)
        queue.add(st(900L, { for (i in 0 until n) { sx[i] = list[i].x; sy[i] = list[i].y; tx[i] = (list[i].hx + (rnd.nextFloat() - 0.5f) * 50f * u).coerceIn(14f * u, width - 14f * u); tr[i] = (rnd.nextFloat() - 0.5f) * 160f } }) { p ->
            bodyRot = 0f
            val e = bounce.getInterpolation(p)
            for (i in 0 until n) { val s = list[i]; s.x = lerp(sx[i], tx[i], ease(p)); s.y = lerp(sy[i], gy - minOf(s.h, s.w) * s.sc / 2f - 1f * u, e); s.rot = tr[i] * ease(p) }
        })
        queue.add(st(700L) { p -> wave = 1f; facing = 1f })
        val rx = FloatArray(n); val ry = FloatArray(n); val rr = FloatArray(n)
        queue.add(st(1700L, { wave = 0f; for (i in 0 until n) { rx[i] = list[i].x; ry[i] = list[i].y; rr[i] = list[i].rot } }) { p ->
            armsUp = if (((p * 6f).toInt() % 2) == 0) 0.9f else 0.3f
            for (i in 0 until n) {
                val t = ((p * 1700f - i * 150f) / 500f).coerceIn(0f, 1f)
                val e = over.getInterpolation(t)
                list[i].x = lerp(rx[i], list[i].hx, e); list[i].y = arcY(ry[i], list[i].hy, e, 30f * u); list[i].rot = lerp(rr[i], 0f, e)
            }
        })
        queue.add(st(1L) { _ -> armsUp = 0f; burst(width / 2f, 40f * u, 16, 200f) })
    }

    private fun gWave() {
        val list = sprites.toList()
        val left = 18f * u; val right = width - 18f * u
        queue.add(walk(planX, left, null)); planX = left
        for (round in 0 until 2) {
            val a = if (round == 0) left else right; val b = if (round == 0) right else left
            queue.add(st(2300L) { p ->
                walking = true; val nx = lerp(a, b, ease(p)); walkPh += Math.abs(nx - mx) / (5f * u * K); facing = if (b > a) 1f else -1f; mx = nx
                armsUp = 0.8f
                for (s in list) {
                    val hop = maxOf(0f, 1f - Math.abs(s.hx - mx) / (34f * u))
                    s.y = s.hy - 20f * u * hop; s.rot = 10f * hop * facing
                }
            })
        }
        queue.add(st(1L) { _ -> armsUp = 0f; for (s in list) s.reset() })
    }

    private fun gDomino(bs: List<Sprite>) {
        val right = rnd.nextBoolean()
        val ord = if (right) bs else bs.reversed()
        val n = ord.size
        val sgn = if (right) 1f else -1f
        go(cx(ord[0].hx - sgn * 34f * u))
        queue.add(st(300L) { p -> facing = sgn; kick = 0f; armsUp = 0.6f * ease(p) })
        val total = 420f + 260f * (n - 1)
        queue.add(st(total.toLong()) { p ->
            armsUp = 0f
            for (i in 0 until n) {
                val s = ord[i]
                val t = ((p * total - i * 260f) / 420f).coerceIn(0f, 1f)
                val th = sgn * 90f * t * t
                val r = s.h / 2f; val rad = th * PIF / 180f
                s.rot = th; s.x = s.hx + r * sinF(rad); s.y = s.hy + r - r * cosF(rad)
            }
            shake = if (p > 0.3f) 1.5f * u else 0f
        })
        queue.add(st(500L) { p -> armsUp = ease(p) })
        queue.add(st(total.toLong()) { p ->
            for (i in 0 until n) {
                val s = ord[i]
                val t = ((p * total - (n - 1 - i) * 200f) / 420f).coerceIn(0f, 1f)
                val th = sgn * 90f * (1f - ease(t))
                val r = s.h / 2f; val rad = th * PIF / 180f
                s.rot = th; s.x = s.hx + r * sinF(rad); s.y = s.hy + r - r * cosF(rad)
            }
            armsUp = if (((p * 8f).toInt() % 2) == 0) 1f else 0.4f
        })
        queue.add(st(1L) { _ -> burst(width / 2f, 50f * u, 24, 260f) })
    }

    private fun gRunAway(dot: Sprite) {
        val groundY = gy - dot.h / 2f - 1f * u
        dropFall(dot)
        val dir = if (dot.hx < width / 2f) 1f else -1f
        go((dot.hx - dir * 40f * u).coerceIn(20f * u, width - 20f * u))
        val target = if (dir > 0) width - 22f * u else 22f * u
        var x0 = 0f
        queue.add(st(2400L, { x0 = dot.x }) { p ->
            dot.x = lerp(x0, target, ease(p)); dot.y = groundY - Math.abs(sinF(p * PIF * 9f)) * 16f * u
            dot.rot = sinF(p * 40f) * 20f
            val goal = dot.x - dir * 30f * u
            val nx = lerp(mx, goal, 0.09f)
            walkPh += Math.abs(nx - mx) / (5f * u * K); walking = true; mx = nx; facing = dir
            armsUp = 0.3f
        })
        queue.add(st(450L) { p -> bodyRot = dir * 80f * ease(p); lift = 4f * u * sinF(p * PIF); armsUp = 1f; dot.sc = 1f - 0.2f * p })
        flyHome(dot, 900L, 70f * u, 720f)
        queue.add(st(550L) { p -> bodyRot = lerp(dir * 80f, 0f, ease(p)); lift = 0f })
        queue.add(st(1L) { _ -> armsUp = 0f })
    }

    private fun gEat(dot: Sprite) {
        go(cx(dot.hx))
        queue.add(st(1L) { _ -> facing = 1f })
        fly(dot, 600L, 30f * u, 0f, 0f, 0, 1f, { mx + 1f * u }, { gy - 41f * u * K })
        queue.add(st(300L) { p -> dot.sc = 1f - ease(p); dot.x = mx + 1f * u; dot.y = gy - 41f * u * K })
        queue.add(st(700L) { p -> dot.alpha = 0f; armsUp = 0f; wave = if (p < 0.8f) 0f else 0f; bodyRot = sinF(p * 20f) * 4f })
        queue.add(st(1L) { _ -> bodyRot = 0f; shake = 2f * u; burst(mx + 6f * u * K, gy - 40f * u * K, 8, 120f) })
        queue.add(st(1L) { _ -> dot.alpha = 1f; dot.x = mx + 4f * u; dot.y = gy - 41f * u * K; dot.sc = 0.2f })
        fly(dot, 800L, 60f * u, 0f, 720f, 0, 1f, { dot.hx }, { dot.hy })
    }

    private fun gDribble(dot: Sprite) {
        val groundY = gy - dot.h / 2f - 1f * u
        val dir = if (dot.hx < width / 2f) 1f else -1f
        dropFall(dot)
        go((dot.hx - dir * 18f * u).coerceIn(20f * u, width - 20f * u))
        queue.add(st(1900L) { p ->
            facing = dir
            dot.x = mx + dir * 14f * u; dot.y = groundY - Math.abs(sinF(p * PIF * 6f)) * 26f * u
            armsUp = 0.15f + 0.1f * sinF(p * 60f)
        })
        var x0 = 0f; var y0 = 0f
        queue.add(st(750L, { x0 = dot.x; y0 = dot.y }) { p ->
            val e = ease(p)
            lift = 4f * 26f * u * p * (1f - p); armsUp = ease(minOf(1f, p * 2f))
            dot.x = lerp(x0, dot.hx, e); dot.y = arcY(y0, dot.hy, e, 60f * u); dot.rot = 360f * p
        })
        queue.add(st(1L) { _ -> lift = 0f; burst(dot.hx, dot.hy, 18, 220f); dot.rot = 0f })
        queue.add(st(500L) { p -> armsUp = if (p < 0.5f) 1f else 1f - ease((p - 0.5f) * 2f) })
    }

    private fun gSneeze(ds: List<Sprite>) {
        go(cx(width * 0.5f))
        queue.add(st(900L) { p -> facing = 1f; bodyRot = -12f * ease(p) + sinF(p * 24f) * 1.5f })
        val list = ds.toList(); val n = list.size
        val sx = FloatArray(n); val sy = FloatArray(n); val tx = FloatArray(n); val ty = FloatArray(n)
        queue.add(st(800L, { for (i in 0 until n) { sx[i] = list[i].x; sy[i] = list[i].y; tx[i] = 20f * u + rnd.nextFloat() * (width - 40f * u); ty[i] = 30f * u + rnd.nextFloat() * 90f * u }; shake = 5f * u; burst(mx + 6f * u * K, gy - 40f * u * K, 14, 200f) }) { p ->
            bodyRot = lerp(-12f, 22f, ease(minOf(1f, p * 4f))) * (1f - p)
            val e = ease(p)
            for (i in 0 until n) { list[i].x = lerp(sx[i], tx[i], e); list[i].y = arcY(sy[i], ty[i], e, 30f * u); list[i].rot = 540f * p }
        })
        queue.add(st(700L) { p -> bodyRot = 0f; wave = 1f; facing = -1f })
        val rx = FloatArray(n); val ry = FloatArray(n)
        queue.add(st(1400L, { wave = 0f; for (i in 0 until n) { rx[i] = list[i].x; ry[i] = list[i].y } }) { p ->
            for (i in 0 until n) {
                val t = ((p * 1400f - i * 220f) / 700f).coerceIn(0f, 1f)
                val e = over.getInterpolation(t)
                list[i].x = lerp(rx[i], list[i].hx, e); list[i].y = arcY(ry[i], list[i].hy, e, 36f * u); list[i].rot = 540f * (1f - t)
            }
        })
    }

    // ───────────── game catalogue ─────────────

    private fun buildGames() {
        games.add(Game(0, 0) { gWall() })
        games.add(Game(0, 0) { gWall() })
        games.add(Game(1, 0) { gThrow(pick(smallOnes())) })
        games.add(Game(1, 0) { gToss(pick(smallOnes())) })
        games.add(Game(0, 1) { gKick(pick(dotList())) })
        games.add(Game(1, 0) { gHangSwing(pick(bodies())) })
        games.add(Game(1, 0) { gPullups(pick(bodies())) })
        games.add(Game(2, 0) { gMonkey(bodies()) })
        games.add(Game(2, 0) { gSwap(bodies(), 2) })
        games.add(Game(3, 0) { gSwap(bodies(), minOf(4, bodies().size)) })
        games.add(Game(1, 0) { gRoll(pick(smallOnes())) })
        games.add(Game(1, 1) { gBowling(pick(dotList()), pick(bodies())) })
        games.add(Game(0, 1) { gJuggle(dotList()) })
        games.add(Game(1, 0) { gBalloon(pick(bodies())) })
        games.add(Game(1, 0) { gRocket(pick(bodies())) })
        games.add(Game(1, 0) { gSling(pick(smallOnes())) })
        games.add(Game(1, 0) { gTug(pick(bodies())) })
        games.add(Game(0, 1) { gSlip(pick(dotList())) })
        games.add(Game(1, 0) { gSkate(pick(smallOnes())) })
        games.add(Game(1, 0) { gHeadbutt(pick(bodies())) })
        games.add(Game(1, 0) { gHat(pick(smallOnes())) })
        games.add(Game(1, 0) { gDisco() })
        games.add(Game(2, 0) { gCollapse() })
        games.add(Game(2, 0) { gWave() })
        games.add(Game(3, 0) { gDomino(bodies()) })
        games.add(Game(0, 1) { gRunAway(pick(dotList())) })
        games.add(Game(0, 1) { gEat(pick(dotList())) })
        games.add(Game(0, 1) { gDribble(pick(dotList())) })
        games.add(Game(0, 1) { gSneeze(dotList()) })
        games.add(Game(0, 1) { gThrow(pick(dotList())) })
        games.add(Game(0, 1) { gToss(pick(dotList())) })
    }

    private fun planNext() {
        val nb = sprites.count { !it.dot }; val nd = sprites.count { it.dot }
        if (sprites.isEmpty()) { queue.add(st(1000L) { _ -> }); return }
        planX = mx
        val ok = ArrayList<Int>()
        for (i in games.indices) if (nb >= games[i].nb && nd >= games[i].nd && i !in recent) ok.add(i)
        if (ok.isEmpty()) { recent.clear(); for (i in games.indices) if (nb >= games[i].nb && nd >= games[i].nd) ok.add(i) }
        if (ok.isEmpty()) { queue.add(st(1000L) { _ -> }); return }
        val g = pick(ok)
        recent.add(g); while (recent.size > 8) recent.removeAt(0)
        games[g].run()
        queue.add(st(1L) { _ -> endGame() })
        queue.add(st(700L) { _ -> })
    }

    // ───────────── drawing ─────────────

    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        cv.drawRect(0f, 0f, width.toFloat(), baseH, whitePaint)
        tick()
        val now = SystemClock.uptimeMillis()
        val dt = if (lastT == 0L) 0.016f else minOf(0.05f, (now - lastT) / 1000f)
        lastT = now
        cv.save()
        if (shake > 0.05f) { cv.translate((rnd.nextFloat() - 0.5f) * shake * 2f, (rnd.nextFloat() - 0.5f) * shake * 2f); shake *= 0.9f } else shake = 0f
        for (s in sprites) if (!s.dot) drawSprite(cv, s)
        drawMan(cv)
        for (s in sprites) if (s.dot) drawSprite(cv, s)
        drawChute(cv)
        drawSling(cv)
        drawParts(cv, dt)
        cv.restore()
        drawChip(cv)
    }

    private fun drawSprite(cv: Canvas, s: Sprite) {
        if (s.alpha <= 0.01f) return
        cv.save()
        cv.translate(s.x, s.y); cv.rotate(s.rot); cv.scale(s.sc * s.stx, s.sc * s.sty)
        paint.reset(); paint.isAntiAlias = true; paint.isFilterBitmap = true
        paint.alpha = (255f * s.alpha).toInt()
        if (s.tint != 0) paint.colorFilter = PorterDuffColorFilter(s.tint, PorterDuff.Mode.SRC_IN)
        cv.drawBitmap(s.bmp, -s.w / 2f, -s.h / 2f, paint)
        cv.restore()
    }

    private fun drawChute(cv: Canvas) {
        val s = chute ?: return
        val top = s.y - s.h * s.sc / 2f
        val cw = maxOf(24f * u, s.w * 0.7f)
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.2f * u; paint.color = tint(C.TEXT, 170)
        cv.drawLine(s.x - cw, top - 16f * u, s.x - s.w * 0.3f, top, paint)
        cv.drawLine(s.x + cw, top - 16f * u, s.x + s.w * 0.3f, top, paint)
        cv.drawLine(s.x, top - 30f * u, s.x, top, paint)
        paint.style = Paint.Style.FILL; paint.color = C.AMBER
        rect.set(s.x - cw, top - 46f * u, s.x + cw, top + 12f * u)
        cv.save(); cv.clipRect(s.x - cw, top - 46f * u, s.x + cw, top - 16f * u)
        cv.drawOval(rect, paint)
        cv.restore()
    }

    private fun drawSling(cv: Canvas) {
        val s = sling ?: return
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.6f * u; paint.color = tint(C.TEXT, 190); paint.strokeCap = Paint.Cap.ROUND
        cv.drawLine(mx + facing * 3f * u, gy - 40f * u * K, s.x, s.y, paint)
        cv.drawLine(mx + facing * 3f * u, gy - 18f * u * K, s.x, s.y, paint)
    }

    private fun drawParts(cv: Canvas, dt: Float) {
        if (parts.isEmpty()) return
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
        val iter = parts.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            p.life -= dt
            if (p.life <= 0f) { iter.remove(); continue }
            p.vy += 900f * u * dt; p.x += p.vx * dt; p.y += p.vy * dt
            paint.color = tint(p.col, (255f * minOf(1f, p.life * 2f)).toInt())
            cv.drawCircle(p.x, p.y, p.r * u, paint)
        }
    }

    private fun drawChip(cv: Canvas) {
        if (unread <= 0) return
        val label = faDigits(unread.toString()) + " پیام جدید"
        chipPaint.textSize = 12f * u; chipPaint.color = C.GREEN
        val tw = chipPaint.measureText(label)
        val l = 12f * u; val t = 8f * u
        rect.set(l, t, l + tw + 30f * u, t + 20f * u)
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.FILL; paint.color = tint(C.GREEN, 30); cv.drawRoundRect(rect, 10f * u, 10f * u, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1f * u; paint.color = tint(C.GREEN, 140); cv.drawRoundRect(rect, 10f * u, 10f * u, paint)
        val k = (sinF(SystemClock.uptimeMillis() / 260f) + 1f) / 2f
        paint.style = Paint.Style.FILL; paint.color = tint(C.GREEN, (70 + 110 * k).toInt())
        cv.drawCircle(l + 11f * u, t + 10f * u, (4f + 2.5f * k) * u, paint)
        paint.color = C.GREEN; cv.drawCircle(l + 11f * u, t + 10f * u, 3.2f * u, paint)
        cv.drawText(label, l + 21f * u, t + 14.5f * u, chipPaint)
    }

    private val SHIRT = 0xFF2979FF.toInt()
    private val SHIRT_D = 0xFF1B4FC4.toInt()
    private val SHORTS = 0xFFFF6D00.toInt()
    private val SHORTS_D = 0xFFC24E00.toInt()
    private val SHOE = 0xFFFF4081.toInt()
    private val SHOE_ACC = 0xFFB2FF59.toInt()
    private val SKIN = 0xFFFFD2AE.toInt()
    private val SKIN_D = 0xFFE3A57A.toInt()
    private val INK = 0xFF3A2A20.toInt()
    private val WHITE = 0xFFFFFFFF.toInt()
    private val FANG = floatArrayOf(-1.05f, -0.5f, -0.05f, 0.4f, 0.85f)   // thumb, index, middle, ring, pinky
    private val FLEN = floatArrayOf(3.0f, 4.0f, 4.4f, 4.0f, 3.2f)

    /** A coloured part of a limb, from fraction [from] to [to] of the way from (x0,y0) to (x1,y1). */
    private fun seg(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, from: Float, to: Float, wd: Float, col: Int) {
        val dx = x1 - x0; val dy = y1 - y0
        paint.style = Paint.Style.STROKE; paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = wd; paint.color = col
        cv.drawLine(x0 + dx * from, y0 + dy * from, x0 + dx * to, y0 + dy * to, paint)
    }

    /** Skin-coloured limb with a thin dark outline. */
    private fun limb(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, wd: Float) {
        seg(cv, x0, y0, x1, y1, 0f, 1f, wd + 1.3f * u, INK)
        seg(cv, x0, y0, x1, y1, 0f, 1f, wd, SKIN)
    }

    /** A human hand with five separate fingers (thumb on the side facing the body). */
    private fun hand(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, bx: Float) {
        val dx = x1 - x0; val dy = y1 - y0
        val len = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        if (len < 0.01f) return
        val ux = dx / len; val uy = dy / len
        val base = Math.atan2(uy.toDouble(), ux.toDouble()).toFloat()
        val pr = 1.9f * u
        val pcx = x1 + ux * pr * 0.55f; val pcy = y1 + uy * pr * 0.55f
        val toBody = if (bx > x1) 1f else -1f
        val sg = if (cosF(base - 1.05f) * toBody >= cosF(base + 1.05f) * toBody) 1f else -1f
        paint.strokeCap = Paint.Cap.ROUND
        for (pass in 0..1) {
            paint.style = Paint.Style.STROKE
            paint.color = if (pass == 0) INK else SKIN
            paint.strokeWidth = if (pass == 0) 1.6f * u else 0.8f * u
            for (i in 0 until 5) {
                val a = base + sg * FANG[i]
                val l0 = pr * 0.6f; val l1 = pr * 0.6f + FLEN[i] * u
                cv.drawLine(pcx + cosF(a) * l0, pcy + sinF(a) * l0, pcx + cosF(a) * l1, pcy + sinF(a) * l1, paint)
            }
            paint.style = Paint.Style.FILL
            cv.drawCircle(pcx, pcy, if (pass == 0) pr + 0.7f * u else pr, paint)
        }
        paint.style = Paint.Style.STROKE
    }

    /** Arm in a short sports sleeve with a white wristband, ending in a hand. */
    private fun arm(cv: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, bx: Float) {
        limb(cv, x0, y0, x1, y1, 2.0f * u)
        seg(cv, x0, y0, x1, y1, 0f, 0.4f, 5.4f * u, SHIRT_D)
        seg(cv, x0, y0, x1, y1, 0f, 0.4f, 4.2f * u, SHIRT)
        seg(cv, x0, y0, x1, y1, 0.74f, 0.9f, 3.9f * u, INK)
        seg(cv, x0, y0, x1, y1, 0.74f, 0.9f, 2.9f * u, WHITE)
        hand(cv, x0, y0, x1, y1, bx)
    }

    /** A matching pair of sneakers: pink upper, lime heel patch and swoosh, white laces and sole. */
    private fun shoe(cv: Canvas, fx: Float, fy: Float, th: Float) {
        val f = if (facing >= 0f) 1f else -1f
        cv.save()
        cv.translate(fx, fy)
        cv.rotate(-th * 57.3f * 0.7f)
        val back = -3.6f * u; val front = 8.6f * u
        val l = if (f > 0f) back else -front
        val r = if (f > 0f) front else -back
        paint.style = Paint.Style.FILL
        paint.color = INK
        rect.set(l - 0.8f * u, -3.8f * u, r + 0.8f * u, 3.9f * u); cv.drawRoundRect(rect, 3f * u, 3f * u, paint)
        paint.color = SHOE
        rect.set(l, -3f * u, r, 2.4f * u); cv.drawRoundRect(rect, 2.6f * u, 2.6f * u, paint)
        // lime heel patch
        paint.color = SHOE_ACC
        val hl = if (f > 0f) l else r - 2.6f * u
        rect.set(hl, -1f * u, hl + 2.6f * u, 2.2f * u); cv.drawRoundRect(rect, 1.2f * u, 1.2f * u, paint)
        // white sole
        paint.color = WHITE
        rect.set(l, 1.6f * u, r, 3.4f * u); cv.drawRoundRect(rect, 1f * u, 1f * u, paint)
        // laces
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 0.8f * u; paint.color = WHITE
        for (k in 0..2) {
            val lx = if (f > 0f) 1.6f * u + k * 1.6f * u else -1.6f * u - k * 1.6f * u
            cv.drawLine(lx - 0.7f * u, -2.6f * u, lx + 0.7f * u, -1.2f * u, paint)
        }
        // lime swoosh
        paint.strokeWidth = 1.2f * u; paint.color = SHOE_ACC; paint.strokeCap = Paint.Cap.ROUND
        val sx0 = if (f > 0f) 0f else 0f
        cv.drawLine(sx0 - f * 1.2f * u, 0.9f * u, sx0 + f * 4.4f * u, -0.6f * u, paint)
        paint.strokeWidth = 3.2f * u
        cv.restore()
    }

    private fun drawFace(cv: Canvas, x: Float, hy: Float, ms: Long) {
        val f = if (facing >= 0f) 1f else -1f
        val R = 7.4f * u
        val blink = (ms % 3300L) < 130L
        val excited = hangOn || Math.abs(bodyRot) > 25f || lift > 8f * u || armsUp > 0.85f || kick > 0.5f
        // ears
        paint.style = Paint.Style.FILL; paint.color = INK
        cv.drawCircle(x - R * 1.0f, hy + 0.1f * R, 0.26f * R + 0.8f * u, paint)
        cv.drawCircle(x + R * 1.0f, hy + 0.1f * R, 0.26f * R + 0.8f * u, paint)
        paint.color = SKIN_D
        cv.drawCircle(x - R * 1.0f, hy + 0.1f * R, 0.26f * R, paint)
        cv.drawCircle(x + R * 1.0f, hy + 0.1f * R, 0.26f * R, paint)
        // head
        paint.color = INK; cv.drawCircle(x, hy, R + 0.9f * u, paint)
        paint.color = SKIN; cv.drawCircle(x, hy, R, paint)
        // sporty cap with a visor
        paint.color = SHIRT_D
        rect.set(x + (if (f > 0f) 0.3f * R else -1.9f * R), hy - 0.78f * R, x + (if (f > 0f) 1.9f * R else -0.3f * R), hy - 0.42f * R)
        cv.drawRoundRect(rect, 0.18f * R, 0.18f * R, paint)
        paint.color = INK
        rect.set(x - R * 1.12f, hy - R * 1.2f, x + R * 1.12f, hy + R * 0.34f)
        cv.drawArc(rect, 180f, 180f, true, paint)
        paint.color = SHIRT
        rect.set(x - R * 1.04f, hy - R * 1.14f, x + R * 1.04f, hy + R * 0.28f)
        cv.drawArc(rect, 180f, 180f, true, paint)
        paint.color = WHITE; paint.style = Paint.Style.STROKE; paint.strokeWidth = 1f * u
        cv.drawLine(x - 0.5f * R, hy - 0.95f * R, x - 0.5f * R + 0.15f * R, hy - 0.45f * R, paint)
        cv.drawLine(x + 0.5f * R, hy - 0.95f * R, x + 0.5f * R - 0.15f * R, hy - 0.45f * R, paint)
        paint.style = Paint.Style.FILL
        // eyes
        val ey = hy + 0.12f * R
        for (side in intArrayOf(-1, 1)) {
            val ex = x + side * 0.43f * R + f * 0.1f * R
            if (blink) {
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.2f * u; paint.color = INK; paint.strokeCap = Paint.Cap.ROUND
                cv.drawLine(ex - 0.28f * R, ey + 0.05f * R, ex + 0.28f * R, ey + 0.05f * R, paint)
                paint.style = Paint.Style.FILL
            } else {
                paint.color = INK
                rect.set(ex - 0.33f * R, ey - 0.4f * R, ex + 0.33f * R, ey + 0.4f * R); cv.drawOval(rect, paint)
                paint.color = WHITE
                rect.set(ex - 0.28f * R, ey - 0.35f * R, ex + 0.28f * R, ey + 0.35f * R); cv.drawOval(rect, paint)
                paint.color = 0xFF2B1D14.toInt()
                cv.drawCircle(ex + f * 0.08f * R, ey + 0.03f * R, 0.21f * R, paint)
                paint.color = WHITE
                cv.drawCircle(ex + f * 0.08f * R - 0.07f * R, ey - 0.07f * R, 0.075f * R, paint)
            }
            // eyebrow (raised when excited)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.3f * u; paint.color = INK; paint.strokeCap = Paint.Cap.ROUND
            val up = if (excited) 0.2f * R else 0f
            cv.drawLine(ex - 0.3f * R, ey - 0.62f * R - up, ex + 0.3f * R, ey - 0.7f * R - up, paint)
            paint.style = Paint.Style.FILL
        }
        // rosy cheeks
        paint.color = 0x66FF6F91
        cv.drawCircle(x - 0.72f * R + f * 0.08f * R, hy + 0.52f * R, 0.22f * R, paint)
        cv.drawCircle(x + 0.72f * R + f * 0.08f * R, hy + 0.52f * R, 0.22f * R, paint)
        // nose
        paint.color = SKIN_D
        cv.drawCircle(x + f * 0.2f * R, hy + 0.42f * R, 0.11f * R, paint)
        // mouth: open happy grin when excited, otherwise a smile
        val mxc = x + f * 0.1f * R
        if (excited) {
            paint.color = 0xFF8E2C3E.toInt()
            rect.set(mxc - 0.38f * R, hy + 0.5f * R, mxc + 0.38f * R, hy + 1.0f * R)
            cv.drawArc(rect, 0f, 180f, true, paint)
            paint.color = 0xFFFF8A9B.toInt()
            cv.drawCircle(mxc, hy + 0.9f * R, 0.14f * R, paint)
        } else {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.3f * u; paint.color = 0xFF8E2C3E.toInt(); paint.strokeCap = Paint.Cap.ROUND
            rect.set(mxc - 0.4f * R, hy + 0.3f * R, mxc + 0.4f * R, hy + 0.85f * R)
            cv.drawArc(rect, 20f, 140f, false, paint)
            paint.style = Paint.Style.FILL
        }
    }

    private fun drawMan(cv: Canvas) {
        val ms = SystemClock.uptimeMillis()
        val x = if (hangOn) gripX else mx
        val lfW = if (hangOn) gy - reach - gripY + bend * 9f * u else lift   // feet height above ground, in screen pixels
        paint.reset(); paint.isAntiAlias = true
        // ground shadow
        val shw = 13f * u * (1f - minOf(lfW, 60f * u) / 100f)
        paint.style = Paint.Style.FILL; paint.color = 0x22000000
        rect.set(x - shw, gy - 2f * u, x + shw, gy + 2.5f * u); if (lfW >= 0f) cv.drawOval(rect, paint)

        cv.save()
        if (bodyRot != 0f) {
            if (hangOn) cv.rotate(bodyRot, gripX, gripY)
            else if (pivHip) cv.rotate(bodyRot, x, gy - lfW - 20f * u * K)
            else cv.rotate(bodyRot, x, gy - lfW)
        }
        cv.scale(K, K, x, gy)
        val fy = gy - lfW / K
        val hipY = fy - 20f * u
        val shY = fy - 36f * u
        val sw = if (walking) sinF(walkPh) else 0f
        val dph = ms / 150f
        paint.style = Paint.Style.STROKE; paint.strokeCap = Paint.Cap.ROUND

        // legs
        var thL = -0.06f - 0.65f * sw + legAdd
        var thR = 0.06f + 0.65f * sw + legAdd * 0.5f
        if (kick != 0f) { if (facing > 0) thR = facing * kick * 1.35f else thL = facing * kick * 1.35f }
        if (dance > 0.01f) { thL -= 0.5f * sinF(dph) * dance; thR += 0.5f * sinF(dph) * dance }
        val lx = x + 20f * u * sinF(thL); val ly = hipY + 20f * u * cosF(thL)
        val rx = x + 20f * u * sinF(thR); val ry = hipY + 20f * u * cosF(thR)
        limb(cv, x, hipY, lx, ly, 3.8f * u)
        limb(cv, x, hipY, rx, ry, 3.8f * u)
        seg(cv, x, hipY, lx, ly, 0f, 0.42f, 7.8f * u, SHORTS_D); seg(cv, x, hipY, lx, ly, 0f, 0.42f, 6.4f * u, SHORTS)
        seg(cv, x, hipY, rx, ry, 0f, 0.42f, 7.8f * u, SHORTS_D); seg(cv, x, hipY, rx, ry, 0f, 0.42f, 6.4f * u, SHORTS)
        seg(cv, x, hipY, lx, ly, 0.66f, 0.92f, 5f * u, INK); seg(cv, x, hipY, lx, ly, 0.66f, 0.92f, 3.8f * u, WHITE)
        seg(cv, x, hipY, rx, ry, 0.66f, 0.92f, 5f * u, INK); seg(cv, x, hipY, rx, ry, 0.66f, 0.92f, 3.8f * u, WHITE)
        shoe(cv, lx, ly, thL)
        shoe(cv, rx, ry, thR)

        // jersey with a side stripe, shorts band
        seg(cv, x, shY, x, hipY - 2f * u, 0f, 1f, 9.6f * u, SHIRT_D)
        seg(cv, x, shY, x, hipY - 2f * u, 0f, 1f, 8f * u, SHIRT)
        seg(cv, x + 2.6f * u, shY + 2f * u, x + 2.6f * u, hipY - 4f * u, 0f, 1f, 1.4f * u, WHITE)
        seg(cv, x - 3f * u, hipY, x + 3f * u, hipY, 0f, 1f, 6.4f * u, SHORTS)

        // arms and hands (angle 0 = hanging down, ±π = straight up)
        val sy = shY + 1f * u
        if (hangOn) {
            val hyS = gy + (gripY - gy) / K        // hand height in the stickman's own (scaled) space
            arm(cv, x, sy, x - 4.5f * u, hyS - handOff, x)
            arm(cv, x, sy, x + 4.5f * u, hyS + handOff, x)
        } else {
            var aL = lerp(-0.12f + 0.55f * sw, -(PIF - 0.32f), armsUp)
            var aR = lerp(0.12f - 0.55f * sw, PIF - 0.32f, armsUp)
            if (wave > 0.01f) aR = lerp(aR, PIF - 1.0f + 0.4f * sinF(ms / 85f), wave)
            if (dance > 0.01f) {
                aL = lerp(aL, lerp(-0.12f, -(PIF - 0.4f), (sinF(dph * 0.5f) + 1f) / 2f), dance)
                aR = lerp(aR, lerp(0.12f, PIF - 0.4f, (cosF(dph * 0.5f) + 1f) / 2f), dance)
            }
            arm(cv, x, sy, x + 15f * u * sinF(aL), sy + 15f * u * cosF(aL), x)
            arm(cv, x, sy, x + 15f * u * sinF(aR), sy + 15f * u * cosF(aR), x)
        }

        // head and face
        drawFace(cv, x, fy - 45f * u, ms)
        cv.restore()
    }
}
