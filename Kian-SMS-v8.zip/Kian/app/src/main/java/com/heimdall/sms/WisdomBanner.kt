package com.heimdall.sms

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Compact hadith card: Islamic star-lattice pattern, gold double frame, calligraphic Arabic line on top,
 * Persian meaning below. The chip at the top picks whose sayings are shown (all / one specific Imam).
 * Tap = next saying, long-press = full text.
 */
class WisdomBanner(c: Context) : LinearLayout(c) {
    private var current: Hadith? = null
    private val arabic = TextView(c)
    private val meaning = TextView(c)
    private val source = TextView(c)
    private val chip = TextView(c)

    private val pat = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1) * 0.8f }
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1).toFloat() }
    private val clip = Path()
    private val rect = RectF()

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setWillNotDraw(false)
        setPadding(dp(16), dp(10), dp(16), dp(12))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(tint(C.AMBER, 52), C.SURF, tint(C.AMBER, 30))).apply {
            cornerRadius = dp(24).toFloat(); setStroke(dp(1), tint(C.AMBER, 150))
        }
        elevation = dp(4).toFloat()

        // Top row: imam chip — ornamental rule — source
        val top = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        chip.apply {
            textSize = 11.5f; typeface = Fonts.bold; setTextColor(C.ON); gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.AMBER, tint(C.AMBER, 200))).apply { cornerRadius = dp(14).toFloat() }
            setPadding(dp(12), dp(4), dp(10), dp(4)); maxLines = 1
            contentDescription = "انتخاب معصوم"
            setOnClickListener { pickImam() }
        }
        val rule = View(c).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(tint(C.AMBER, 0), tint(C.AMBER, 160), tint(C.AMBER, 0)))
        }
        top.addView(chip, LayoutParams(W, W))
        top.addView(rule, LayoutParams(0, dp(1), 1f).apply { marginStart = dp(8); marginEnd = dp(8) })
        top.addView(TextView(c).apply { text = "✦"; textSize = 12f; setTextColor(tint(C.AMBER, 230)) }, LayoutParams(W, W))

        arabic.apply {
            setTextColor(C.TEXT); typeface = Fonts.bold; gravity = Gravity.CENTER
            setLineSpacing(0f, 1.35f); ellipsize = TextUtils.TruncateAt.END
            textDirection = View.TEXT_DIRECTION_RTL
        }
        meaning.apply {
            textSize = 12.5f; setTextColor(C.SUB); typeface = Fonts.reg; gravity = Gravity.CENTER
            setLineSpacing(0f, 1.2f); maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        }
        source.apply {
            textSize = 10f; setTextColor(tint(C.AMBER, 235)); typeface = Fonts.reg; gravity = Gravity.CENTER; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        addView(top, LayoutParams(M, W))
        addView(arabic, LayoutParams(M, W).apply { topMargin = dp(6) })
        addView(meaning, LayoutParams(M, W).apply { topMargin = dp(3) })
        addView(source, LayoutParams(M, W).apply { topMargin = dp(5) })
        setOnClickListener { advance(true) }
        setOnLongClickListener { showFull(); true }
        advance(true)
    }

    // Eight-pointed star lattice (two overlaid squares), clipped to the rounded card, plus an inner gold frame.
    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val r = dp(24).toFloat()
        rect.set(0f, 0f, w, h)
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW)
        cv.save(); cv.clipPath(clip)
        pat.color = tint(C.AMBER, 38)
        val t = dp(30).toFloat(); val half = t * 0.34f
        var y = t / 2
        var row = 0
        while (y < h + t) {
            var x = if (row % 2 == 0) t / 2 else t
            while (x < w + t) {
                cv.drawRect(x - half, y - half, x + half, y + half, pat)
                cv.save(); cv.rotate(45f, x, y); cv.drawRect(x - half, y - half, x + half, y + half, pat); cv.restore()
                x += t
            }
            y += t / 2; row++
        }
        cv.restore()
        frame.color = tint(C.AMBER, 90)
        val inset = dp(4).toFloat()
        rect.set(inset, inset, w - inset, h - inset)
        cv.drawRoundRect(rect, r - inset, r - inset, frame)
    }

    private fun pickImam() {
        val labels = ArrayList<String>()
        labels.add("همه‌ی معصومین  (${faDigits(Hadiths.all.size.toString())})")
        Hadiths.imams.forEachIndexed { i, n ->
            val k = Hadiths.count(i)
            labels.add(if (k > 0) "$n  (${faDigits(k.toString())})" else "$n  —  به‌زودی")
        }
        AlertDialog.Builder(context).setTitle("احادیث چه کسی نمایش داده شود؟")
            .setItems(labels.toTypedArray()) { _, which ->
                val imam = which - 1
                if (imam >= 0 && Hadiths.count(imam) == 0) {
                    Toast.makeText(context, "احادیث این معصوم به‌زودی اضافه می‌شود", Toast.LENGTH_SHORT).show()
                } else { Prefs(context).hadithImam = imam; advance(true) }
            }.setNegativeButton("بستن", null).show()
    }

    private fun showFull() {
        val h = current ?: return
        val msg = (if (h.ar.isNotEmpty()) h.ar + "\n\n" else "") + h.fa + "\n\n(" + h.src + ")"
        AlertDialog.Builder(context).setTitle(Hadiths.imams[h.imam]).setMessage(msg)
            .setPositiveButton("کپی") { _, _ ->
                try {
                    (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("حدیث", msg))
                    Toast.makeText(context, "کپی شد", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {}
            }.setNegativeButton("بستن", null).show()
    }

    /** Next saying; called on every app open (and not more often than every 60 s otherwise). */
    fun advance(force: Boolean = false) {
        val p = Prefs(context)
        val list = Hadiths.forImam(p.hadithImam).ifEmpty { Hadiths.all }
        val now = System.currentTimeMillis()
        if (!force && now - p.wisdomTs < 60_000L && current != null) return
        val next = if (p.wisdomIndex < 0) (now % list.size).toInt() else (p.wisdomIndex + 1) % list.size
        p.wisdomIndex = next; p.wisdomTs = now
        current = list[next]
        show(current!!, p.hadithImam)
    }

    private fun show(h: Hadith, selected: Int) {
        chip.text = (if (selected < 0) "✦ " else "") + Hadiths.imams[h.imam] + "  ▾"
        source.text = h.src
        if (h.ar.isNotEmpty()) {
            arabic.textSize = if (h.ar.length > 70) 16f else 20f; arabic.maxLines = 3
            arabic.text = h.ar
            meaning.text = h.fa; meaning.visibility = View.VISIBLE
        } else {
            // Persian-only saying: it takes the main place.
            arabic.textSize = 15.5f; arabic.maxLines = 4
            arabic.text = h.fa
            meaning.visibility = View.GONE
        }
    }
}
