plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.heimdall.sms"
    compileSdk = 34
    defaultConfig { applicationId = "com.heimdall.sms"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}

// Downloads the Vazirmatn Persian font at build time (falls back to the system font if offline)
val fetchFont = tasks.register("fetchFont") {
    doLast {
        val out = file("src/main/assets/fonts")
        out.mkdirs()
        listOf("Regular", "Bold").forEach { w ->
            val f = File(out, "Vazirmatn-$w.ttf")
            if (!f.exists()) {
                try {
                    java.net.URL("https://raw.githubusercontent.com/rastikerdar/vazirmatn/master/fonts/ttf/Vazirmatn-$w.ttf")
                        .openStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                } catch (e: Exception) {
                    f.delete(); println("font download failed: $e")
                }
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchFont) }
