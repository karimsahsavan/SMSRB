package com.heimdall.sms

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Resources
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Telephony
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.*

const val M = -1
const val W = -2

object C {
    val BG = Color.parseColor("#121214")
    val SURF = Color.parseColor("#1C1C20")
    val LINE = Color.parseColor("#2E2E35")
    val AMBER = Color.parseColor("#F5B81C")
    val TEXT = Color.parseColor("#F2F2F2")
    val SUB = Color.parseColor("#9A9AA3")
    val RED = Color.parseColor("#FF5C5C")
    val PAL = listOf("#F5B81C", "#5CC8FF", "#7BE0A4", "#FF9F6B", "#C39BFF").map { Color.parseColor(it) }
}

fun dp(v: Int) = (v * Resources.getSystem().displayMetrics.density).toInt()
fun bg(color: Int, r: Int = 16, stroke: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
}
fun oval(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
fun tv(c: Context, t: String, size: Float, color: Int, bold: Boolean = false) = TextView(c).apply {
    text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
}
fun btn(c: Context, t: String, filled: Boolean = true, cb: () -> Unit) =
    tv(c, t, 14f, if (filled) C.BG else C.AMBER, true).apply {
        gravity = Gravity.CENTER
        background = bg(if (filled) C.AMBER else Color.TRANSPARENT, 14, if (filled) 0 else C.AMBER)
        setPadding(dp(18), dp(12), dp(18), dp(12)); setOnClickListener { cb() }
    }
fun card(c: Context) = LinearLayout(c).apply {
    orientation = LinearLayout.VERTICAL; background = bg(C.SURF, 18, C.LINE)
    setPadding(dp(16), dp(16), dp(16), dp(16))
    layoutParams = LinearLayout.LayoutParams(M, W).apply { bottomMargin = dp(12) }
}
fun switchRow(c: Context, title: String, desc: String, on: Boolean, cb: (Boolean) -> Unit): LinearLayout {
    val r = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
    val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, W, 1f) }
    col.addView(tv(c, title, 16f, C.TEXT, true)); col.addView(tv(c, desc, 12f, C.SUB))
    val s = MaterialSwitch(c).apply { isChecked = on; setOnCheckedChangeListener { _, v -> cb(v) } }
    r.addView(col); r.addView(s); return r
}
fun EditText.onText(cb: (String) -> Unit) = addTextChangedListener(object : TextWatcher {
    override fun afterTextChanged(s: Editable?) { cb(s.toString()) }
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
})
fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

fun norm(s: String) = s.replace('ي', 'ی').replace('ك', 'ک').replace("\u200c", "").lowercase()
fun fmtTime(t: Long): String {
    val n = Calendar.getInstance(); val d = Calendar.getInstance().apply { timeInMillis = t }
    val same = n.get(Calendar.YEAR) == d.get(Calendar.YEAR) && n.get(Calendar.DAY_OF_YEAR) == d.get(Calendar.DAY_OF_YEAR)
    return SimpleDateFormat(if (same) "HH:mm" else "MM/dd", Locale.getDefault()).format(Date(t))
}

data class Msg(val id: Long, val addr: String, val body: String, val date: Long, val type: Int,
               val thread: Long, val spam: Boolean = false, val unread: Boolean = false)

class Prefs(c: Context) {
    private val p = c.getSharedPreferences("p", 0)
    var enabled: Boolean get() = p.getBoolean("en", true); set(v) { p.edit().putBoolean("en", v).apply() }
    var showSpam: Boolean get() = p.getBoolean("show", false); set(v) { p.edit().putBoolean("show", v).apply() }
    var rules: List<String>
        get() = p.getString("rules", null)?.split("\n")?.filter { it.isNotBlank() }
            ?: listOf("تخفیف", "اقساط", "اعتبار اضطراری", "اسنپ", "ورود به بام", "قسطی", "رایتل", "دیجی\u200cپی")
        set(v) { p.edit().putString("rules", v.joinToString("\n")).apply() }
    fun isSpam(addr: String, body: String): Boolean {
        if (!enabled) return false
        val b = norm(body); val a = norm(addr)
        return rules.any { val r = norm(it); b.contains(r) || a.contains(r) }
    }
}

class SpamDb(c: Context) : SQLiteOpenHelper(c, "spam.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE spam(id INTEGER PRIMARY KEY AUTOINCREMENT, addr TEXT, body TEXT, date INTEGER)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    fun add(a: String, b: String, d: Long) {
        writableDatabase.insert("spam", null, ContentValues().apply { put("addr", a); put("body", b); put("date", d) })
    }
    fun all(): List<Msg> {
        val o = ArrayList<Msg>()
        readableDatabase.rawQuery("SELECT id,addr,body,date FROM spam ORDER BY date DESC", null).use {
            while (it.moveToNext()) o.add(Msg(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "", it.getLong(3), 1, -it.getLong(0), true))
        }
        return o
    }
    fun count() = DatabaseUtils.queryNumEntries(readableDatabase, "spam").toInt()
    fun delete(id: Long) { writableDatabase.delete("spam", "id=?", arrayOf(id.toString())) }
    fun clear() { writableDatabase.delete("spam", null, null) }
}

fun readSms(c: Context, sel: String?, args: Array<String>?, order: String): List<Msg> {
    val out = ArrayList<Msg>()
    try {
        c.contentResolver.query(Telephony.Sms.CONTENT_URI,
            arrayOf("_id", "address", "body", "date", "type", "thread_id", "read"), sel, args, order)?.use {
            while (it.moveToNext()) out.add(Msg(it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "",
                it.getLong(3), it.getInt(4), it.getLong(5), false, it.getInt(6) == 0))
        }
    } catch (e: Exception) {}
    return out
}

object Names {
    private val m = HashMap<String, String>()
    fun get(c: Context, a: String): String = m.getOrPut(a) {
        try {
            val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(a))
            c.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: a
        } catch (e: Exception) { a }
    }
}

fun isDefault(c: Context) = Telephony.Sms.getDefaultSmsPackage(c) == c.packageName
fun requestDefault(a: Activity) {
    if (Build.VERSION.SDK_INT >= 29) {
        val rm = a.getSystemService(RoleManager::class.java)
        a.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 2)
    } else a.startActivity(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
        .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, a.packageName))
}
fun ensurePerms(a: Activity) {
    val l = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE)
    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
    val miss = l.filter { a.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    if (miss.isNotEmpty()) a.requestPermissions(miss.toTypedArray(), 1)
}
fun restoreToInbox(c: Context, m: Msg): Boolean = try {
    c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
        put(Telephony.Sms.ADDRESS, m.addr); put(Telephony.Sms.BODY, m.body)
        put(Telephony.Sms.DATE, m.date); put(Telephony.Sms.READ, 0)
    }) != null
} catch (e: Exception) { false }
