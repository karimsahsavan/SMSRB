package com.heimdall.sms

import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton

class RowAdapter(val onClick: (Msg) -> Unit, val onLong: (Msg) -> Unit) : RecyclerView.Adapter<RowAdapter.VH>() {
    var items: List<Msg> = emptyList()
    var mode = 0
    class VH(val v: LinearLayout, val av: TextView, val name: TextView, val body: TextView,
             val time: TextView, val badge: TextView) : RecyclerView.ViewHolder(v)

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val c = p.context
        val row = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
            layoutParams = RecyclerView.LayoutParams(M, W)
        }
        val av = tv(c, "", 18f, C.BG, true).apply { gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)) }
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(12); marginEnd = dp(12) }
        }
        val name = tv(c, "", 16f, C.TEXT, true).apply { maxLines = 1 }
        val body = tv(c, "", 13f, C.SUB).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        col.addView(name); col.addView(body)
        val right = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        val time = tv(c, "", 11f, C.SUB)
        val badge = tv(c, "", 11f, C.AMBER, true)
        right.addView(time); right.addView(badge)
        row.addView(av); row.addView(col); row.addView(right)
        return VH(row, av, name, body, time, badge)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val m = items[i]; val n = Names.get(h.v.context, m.addr)
        val ch = n.trim().firstOrNull()
        h.av.text = if (ch != null && ch.isLetter()) ch.toString() else "✉"
        h.av.background = oval(if (m.spam) C.RED else C.PAL[Math.abs(m.addr.hashCode()) % C.PAL.size])
        h.name.text = n
        h.body.text = (if (m.type == 2 && mode == 0) "شما: " else "") + m.body.replace("\n", " ")
        h.body.setTextColor(if (m.unread) C.TEXT else C.SUB)
        h.time.text = fmtTime(m.date)
        h.badge.visibility = if (m.spam || m.unread) View.VISIBLE else View.GONE
        h.badge.text = if (m.spam) "مزاحم" else "●"
        h.badge.setTextColor(if (m.spam) C.RED else C.AMBER)
        h.v.setOnClickListener { onClick(m) }
        h.v.setOnLongClickListener { onLong(m); true }
    }
}

class MainActivity : AppCompatActivity() {
    lateinit var prefs: Prefs
    lateinit var db: SpamDb
    lateinit var ad: RowAdapter
    lateinit var tabs: List<TextView>
    lateinit var banner: TextView
    lateinit var empty: TextView
    var tab = 0
    var all: List<Msg> = emptyList()
    var query = ""
    val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { refresh() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this); db = SpamDb(this)
        ad = RowAdapter({ m ->
            if (m.spam) spamDialog(m) else startActivity(Intent(this, ConversationActivity::class.java)
                .putExtra("addr", m.addr).putExtra("thread", m.thread))
        }, { m -> if (m.spam) spamDialog(m) else confirmDelete(m) })

        val root = FrameLayout(this).apply { setBackgroundColor(C.BG) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(16), dp(12), dp(8)) }
        head.addView(tv(this, "کیان", 26f, C.AMBER, true).apply { layoutParams = LinearLayout.LayoutParams(0, W, 1f) })
        head.addView(tv(this, "⚙", 24f, C.TEXT).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        banner = tv(this, "برای دریافت پیام و فعال شدن فیلتر، کیان را برنامه پیامک پیش‌فرض کنید (ضربه بزنید)", 13f, C.BG, true).apply {
            background = bg(C.AMBER, 12); setPadding(dp(14), dp(10), dp(14), dp(10)); visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(16), dp(4), dp(16), dp(8)) }
            setOnClickListener { requestDefault(this@MainActivity) }
        }
        val tr = LinearLayout(this).apply { setPadding(dp(12), dp(4), dp(12), dp(8)) }
        tabs = listOf("ورودی", "ارسالی", "مزاحم").mapIndexed { i, n ->
            tv(this, n, 14f, C.TEXT, true).apply {
                gravity = Gravity.CENTER; setPadding(dp(8), dp(10), dp(8), dp(10))
                layoutParams = LinearLayout.LayoutParams(0, W, 1f).apply { setMargins(dp(4), 0, dp(4), 0) }
                setOnClickListener { tab = i; refresh() }
            }
        }
        tabs.forEach { tr.addView(it) }
        val search = EditText(this).apply {
            hint = "جستجو در پیامک‌ها…"; setHintTextColor(C.SUB); setTextColor(C.TEXT); textSize = 14f
            background = bg(C.SURF, 14); setPadding(dp(16), dp(10), dp(16), dp(10)); isSingleLine = true
            layoutParams = LinearLayout.LayoutParams(M, W).apply { setMargins(dp(16), 0, dp(16), dp(6)) }
            onText { query = it; show() }
        }
        val rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity); adapter = ad
            clipToPadding = false; setPadding(0, 0, 0, dp(96))
            layoutParams = LinearLayout.LayoutParams(M, 0, 1f)
        }
        col.addView(head); col.addView(banner); col.addView(tr); col.addView(search); col.addView(rv)
        empty = tv(this, "پیامی وجود ندارد", 15f, C.SUB).apply {
            layoutParams = FrameLayout.LayoutParams(W, W, Gravity.CENTER)
        }
        val fab = ExtendedFloatingActionButton(this).apply {
            text = "پیام جدید"; setTextColor(C.BG); backgroundTintList = ColorStateList.valueOf(C.AMBER)
            layoutParams = FrameLayout.LayoutParams(W, W, Gravity.BOTTOM or Gravity.END).apply { setMargins(dp(20), dp(20), dp(20), dp(24)) }
            setOnClickListener { startActivity(Intent(this@MainActivity, ConversationActivity::class.java)) }
        }
        root.addView(col, FrameLayout.LayoutParams(M, M)); root.addView(empty); root.addView(fab)
        setContentView(root)
        ensurePerms(this)
    }

    override fun onStart() {
        super.onStart(); contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs)
    }
    override fun onStop() { super.onStop(); contentResolver.unregisterContentObserver(obs) }
    override fun onResume() {
        super.onResume(); banner.visibility = if (isDefault(this)) View.GONE else View.VISIBLE; refresh()
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); refresh()
    }

    fun refresh() {
        Thread {
            val list: List<Msg> = when (tab) {
                0 -> {
                    val m = readSms(this, null, null, "date DESC")
                    val unreadT = m.filter { it.unread }.map { it.thread }.toSet()
                    val seen = HashSet<Long>()
                    val l = m.filter { seen.add(it.thread) }.map { it.copy(unread = it.thread in unreadT) }
                    if (prefs.showSpam) (l + db.all()).sortedByDescending { it.date } else l
                }
                1 -> readSms(this, "type=2", null, "date DESC")
                else -> db.all()
            }
            list.map { it.addr }.distinct().forEach { Names.get(this, it) }
            val sc = db.count()
            runOnUiThread { all = list; tabs[2].text = "مزاحم ($sc)"; show() }
        }.start()
    }

    fun show() {
        val q = norm(query)
        val l = if (q.isEmpty()) all else all.filter {
            norm(it.body).contains(q) || norm(Names.get(this, it.addr)).contains(q) || it.addr.contains(q)
        }
        ad.items = l; ad.mode = tab; ad.notifyDataSetChanged()
        empty.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
        tabs.forEachIndexed { i, t ->
            val on = i == tab
            t.background = bg(if (on) C.AMBER else C.SURF, 14); t.setTextColor(if (on) C.BG else C.TEXT)
        }
    }

    fun spamDialog(m: Msg) {
        AlertDialog.Builder(this).setTitle(m.addr).setMessage(m.body)
            .setPositiveButton("بازگردانی به ورودی") { _, _ ->
                if (restoreToInbox(this, m)) { db.delete(m.id); refresh() } else toast(this, "ابتدا برنامه را پیش‌فرض کنید")
            }
            .setNegativeButton("حذف") { _, _ -> db.delete(m.id); refresh() }
            .setNeutralButton("بستن", null).show()
    }

    fun confirmDelete(m: Msg) {
        AlertDialog.Builder(this).setTitle(if (tab == 0) "حذف گفتگو؟" else "حذف پیام؟")
            .setPositiveButton("حذف") { _, _ ->
                try {
                    contentResolver.delete(Uri.parse(if (tab == 0) "content://sms/conversations/${m.thread}" else "content://sms/${m.id}"), null, null)
                } catch (e: Exception) { toast(this, "ابتدا برنامه را پیش‌فرض کنید") }
                refresh()
            }.setNegativeButton("لغو", null).show()
    }
}
