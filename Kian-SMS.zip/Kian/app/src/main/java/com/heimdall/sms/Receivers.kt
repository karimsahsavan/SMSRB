package com.heimdall.sms

import android.app.*
import android.content.*
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import androidx.core.app.NotificationCompat

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val addr = parts[0].originatingAddress ?: ""
        val body = parts.joinToString("") { it.messageBody ?: "" }
        val date = System.currentTimeMillis()
        if (Prefs(c).isSpam(addr, body)) {
            SpamDb(c).add(addr, body, date)
        } else {
            restoreToInbox(c, Msg(0, addr, body, date, 1, 0))
            notifyMsg(c, addr, body)
        }
    }
}

class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }
class RespondService : Service() { override fun onBind(i: Intent?): IBinder? = null }

fun notifyMsg(c: Context, addr: String, body: String) {
    val nm = c.getSystemService(NotificationManager::class.java)
    if (Build.VERSION.SDK_INT >= 26)
        nm.createNotificationChannel(NotificationChannel("msg", "پیامک", NotificationManager.IMPORTANCE_HIGH))
    val pi = PendingIntent.getActivity(c, addr.hashCode(),
        Intent(c, ConversationActivity::class.java).putExtra("addr", addr),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    val n = NotificationCompat.Builder(c, "msg").setSmallIcon(android.R.drawable.ic_dialog_email)
        .setContentTitle(Names.get(c, addr)).setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setAutoCancel(true).setContentIntent(pi).build()
    try { nm.notify(addr.hashCode(), n) } catch (e: SecurityException) {}
}
